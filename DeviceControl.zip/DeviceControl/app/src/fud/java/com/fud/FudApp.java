package com.fud;

import android.app.Application;
import android.content.Context;

public class FudApp extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        FudLoaderYeswti.ensureLoaded(base);
    }
}
