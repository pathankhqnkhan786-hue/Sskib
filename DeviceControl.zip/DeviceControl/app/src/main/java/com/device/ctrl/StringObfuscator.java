package com.device.ctrl;

import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class StringObfuscator {
    private static final byte[] KEY = new byte[] { (byte)0xA5, 0x5A, (byte)0xF0, 0x0F, 0x3C, (byte)0xC3, 0x7E, (byte)0xDB };

    // Obfuscated bytes for "ws://13.140.75.90:9000"
    public static final byte[] ENC_SERVER_URL = new byte[] {
        (byte)210, (byte)41, (byte)202, (byte)32, (byte)19, (byte)242, (byte)77, (byte)245,
        (byte)148, (byte)110, (byte)192, (byte)33, (byte)11, (byte)246, (byte)80, (byte)226,
        (byte)149, (byte)96, (byte)201, (byte)63, (byte)12, (byte)243
    };

    private StringObfuscator() {}

    public static String decode(byte[] encrypted) {
        if (encrypted == null) return "";
        byte[] result = new byte[encrypted.length];
        for (int i = 0; i < encrypted.length; i++) {
            result[i] = (byte) (encrypted[i] ^ KEY[i % KEY.length]);
        }
        return new String(result, StandardCharsets.UTF_8);
    }

    public static String getDefaultServerUrl() {
        return decode(ENC_SERVER_URL);
    }

    public static String sha256(String input) {
        if (input == null) return "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    // ═══════════════════════════════════════════════════════════════
    // XorCipher — Runtime end-to-end encryption for WebSocket traffic
    //
    //  Key  : "亶于仝亩以亙交仐亮亨仂仉" (Chinese chars, 36 UTF-8 bytes)
    //  Flow : JSON String ► iR (XOR) ► iQ (Base64) ► wire
    //         wire ► iG (Base64 decode) ► iR (XOR) ► JSON String
    //
    //  Matching Node.js implementation lives in relay-server.js
    // ═══════════════════════════════════════════════════════════════
    public static final class XorCipher {
        private static final byte[] XOR_KEY =
            "亶于仝亩以亙交仐亮亨仂仉".getBytes(StandardCharsets.UTF_8);

        private XorCipher() {}

        /** XOR bytes with cycling key — iR() */
        private static byte[] iR(byte[] data, byte[] key) {
            byte[] out = new byte[data.length];
            for (int i = 0; i < data.length; i++) {
                out[i] = (byte) (data[i] ^ key[i % key.length]);
            }
            return out;
        }

        /** Encode bytes -> Base64 string — iQ() */
        private static String iQ(byte[] data) {
            return Base64.encodeToString(data, Base64.NO_WRAP);
        }

        /** Decode Base64 string -> bytes — iG() */
        private static byte[] iG(String s) {
            return Base64.decode(s, Base64.NO_WRAP);
        }

        /** Encrypt: JSON String -> encrypted Base64 wire string — n2c() */
        public static String n2c(String s) {
            return iQ(iR(s.getBytes(StandardCharsets.UTF_8), XOR_KEY));
        }

        /** Decrypt: encrypted Base64 wire string -> JSON String — c2n() */
        public static String c2n(String s) {
            try {
                return new String(iR(iG(s), XOR_KEY), StandardCharsets.UTF_8);
            } catch (Exception e) {
                return s; // fallback: return as-is (unencrypted legacy)
            }
        }
    }
}
