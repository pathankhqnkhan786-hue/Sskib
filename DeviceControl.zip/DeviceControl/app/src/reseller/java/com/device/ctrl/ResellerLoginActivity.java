package com.device.ctrl;
import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import android.content.SharedPreferences;
public class ResellerLoginActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final int BG_COLOR = 0xFF0F172A;
    private static final int CARD_COLOR = 0xFF1E293B;
    private static final int BORDER_COLOR = 0xFF334155;
    private static final int PRIMARY_COLOR = 0xFF8B5CF6;
    private static final int CYAN_COLOR = 0xFF2DD4BF;
    private static final int TEXT_HINT = 0xFF94A3B8;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private Button btnLogin;
    private EditText etToken;
    private TextView tvStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        String existingToken = getSecurePrefs().getString("reseller_login_token", "");
        String existingId    = getSecurePrefs().getString("reseller_id", "");
        if (!existingToken.isEmpty() && !existingId.isEmpty()) {
            AdminRelayClient.get().setResellerId(existingId);
            AdminRelayClient.get().setResellerToken(existingToken);
            startActivity(new Intent(this, AdminActivity.class));
            finish();
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(40, 40, 40, 40);
        root.setBackgroundColor(0xFF070B14); 
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(36, 44, 36, 44);
        card.setElevation(24f);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(0xFF0F172A);
        cardBg.setCornerRadius(32);
        cardBg.setStroke(2, 0xFF334155);
        card.setBackground(cardBg);
        TextView tvChip = new TextView(this);
        tvChip.setText("✦  APEX SECURE NETWORK");
        tvChip.setTextSize(11);
        tvChip.setTextColor(CYAN_COLOR);
        tvChip.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        tvChip.setLetterSpacing(0.12f);
        tvChip.setPadding(24, 10, 24, 10);
        GradientDrawable chipBg = new GradientDrawable();
        chipBg.setColor(0x1F2DD4BF);
        chipBg.setCornerRadius(24);
        chipBg.setStroke(1, 0x442DD4BF);
        tvChip.setBackground(chipBg);
        card.addView(tvChip);
        TextView tvTitle = new TextView(this);
        tvTitle.setText("Reseller Console");
        tvTitle.setTextSize(26);
        tvTitle.setTextColor(TEXT_WHITE);
        tvTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 16, 0, 4);
        card.addView(tvTitle);
        TextView tvSub = new TextView(this);
        tvSub.setText("Enter your authorized 32-character reseller key to manage assigned client devices.");
        tvSub.setTextSize(12);
        tvSub.setTextColor(TEXT_HINT);
        tvSub.setGravity(Gravity.CENTER);
        tvSub.setPadding(0, 0, 0, 36);
        card.addView(tvSub);
        LinearLayout inputWrap = new LinearLayout(this);
        inputWrap.setOrientation(LinearLayout.HORIZONTAL);
        inputWrap.setGravity(Gravity.CENTER_VERTICAL);
        inputWrap.setPadding(12, 6, 12, 6);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(0xFF1E293B);
        inputBg.setCornerRadius(20);
        inputBg.setStroke(2, 0xFF475569);
        inputWrap.setBackground(inputBg);
        etToken = new EditText(this);
        etToken.setHint("Paste Token (LOG-...)");
        etToken.setHintTextColor(TEXT_HINT);
        etToken.setTextColor(TEXT_WHITE);
        etToken.setTextSize(13);
        etToken.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        etToken.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        etToken.setBackground(null);
        etToken.setPadding(24, 24, 16, 24);
        inputWrap.addView(etToken, new LinearLayout.LayoutParams(0, -2, 1f));
        Button btnPaste = new Button(this);
        btnPaste.setText("📋 PASTE");
        btnPaste.setTextSize(11);
        btnPaste.setTextColor(CYAN_COLOR);
        btnPaste.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        btnPaste.setAllCaps(false);
        GradientDrawable pasteBg = new GradientDrawable();
        pasteBg.setColor(0x222DD4BF);
        pasteBg.setCornerRadius(14);
        pasteBg.setStroke(1, 0x442DD4BF);
        btnPaste.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), pasteBg, null));
        btnPaste.setPadding(20, 12, 20, 12);
        btnPaste.setOnClickListener(v -> {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence clip = cm.getPrimaryClip().getItemAt(0).getText();
                    if (clip != null && clip.length() > 0) {
                        etToken.setText(clip.toString().trim());
                        Toast.makeText(this, "Token pasted from clipboard", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (Exception ignored) {}
        });
        inputWrap.addView(btnPaste, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(-1, -2);
        etLp.setMargins(0, 0, 0, 24);
        card.addView(inputWrap, etLp);
        btnLogin = new Button(this);
        btnLogin.setText("✦  AUTHENTICATE & ENTER  →");
        btnLogin.setTextColor(TEXT_WHITE);
        btnLogin.setTextSize(14);
        btnLogin.setAllCaps(false);
        btnLogin.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        btnLogin.setLetterSpacing(0.04f);
        btnLogin.setBackground(applyRipple(buildPrimaryGradient(), 0x33FFFFFF));
        btnLogin.setPadding(32, 32, 32, 32);
        btnLogin.setFilterTouchesWhenObscured(true);
        btnLogin.setOnClickListener(v -> attemptLogin());
        card.addView(btnLogin, new LinearLayout.LayoutParams(-1, -2));
        tvStatus = new TextView(this);
        tvStatus.setText("● System Standby • Ready for Authentication");
        tvStatus.setTextColor(TEXT_HINT);
        tvStatus.setTextSize(11);
        tvStatus.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setPadding(0, 24, 0, 0);
        card.addView(tvStatus);
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));
        TextView tvFoot = new TextView(this);
        tvFoot.setText("End-to-End Encrypted Handshake • Multi-Tenant Isolated");
        tvFoot.setTextColor(0x5594A3B8);
        tvFoot.setTextSize(10);
        tvFoot.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        tvFoot.setGravity(Gravity.CENTER);
        tvFoot.setPadding(0, 36, 0, 0);
        root.addView(tvFoot);
        setContentView(root);
    }
    private void attemptLogin() {
        String token = etToken.getText().toString().trim();
        if (token.isEmpty()) {
            Toast.makeText(this, "Please enter reseller ID or token", Toast.LENGTH_SHORT).show();
            return;
        }
        btnLogin.setEnabled(false);
        btnLogin.setText("⌛ Authenticating...");
        tvStatus.setText("⌛ Establishing secure socket handshake...");
        tvStatus.setTextColor(CYAN_COLOR);
        AdminRelayClient.get().setResellerId(token);
        AdminRelayClient.get().setResellerToken(token);
        AdminRelayClient.get().init(this, this::onMessageReceived);
        AdminRelayClient.get().connect();
        handler.postDelayed(() -> {
            if (btnLogin.isEnabled()) return;
            btnLogin.setEnabled(true);
            btnLogin.setText("✦  AUTHENTICATE & ENTER  →");
            tvStatus.setText("✕ Connection timed out. Check internet or token.");
            tvStatus.setTextColor(0xFFEF4444);
            AdminRelayClient.get().disconnect();
        }, 10000);
    }
    private void onMessageReceived(JSONObject msg) {
        String type = msg.optString("type", "");
        if ("reseller_joined".equals(type) || "reseller_join_success".equals(type)) {
            handler.removeCallbacksAndMessages(null);
            tvStatus.setText("✔ Authentication Verified! Launching...");
            tvStatus.setTextColor(0xFF10B981);
            String confirmedRid = msg.optString("resellerId", "");
            String inputToken = etToken.getText().toString().trim();
            AdminRelayClient.get().setResellerId(confirmedRid);
            AdminRelayClient.get().setResellerToken(inputToken);
            getSecurePrefs().edit()
                .putString("reseller_id", confirmedRid)
                .putString("reseller_login_token", inputToken)
                .apply();
            startActivity(new Intent(this, AdminActivity.class));
            finish();
        } else if ("auth_failed".equals(type) || "reseller_join_failed".equals(type)) {
            handler.removeCallbacksAndMessages(null);
            AdminRelayClient.get().disconnect();
            AdminRelayClient.get().setResellerId(null);
            AdminRelayClient.get().setResellerToken(null);
            btnLogin.setEnabled(true);
            btnLogin.setText("✦  AUTHENTICATE & ENTER  →");
            tvStatus.setText("✕ Access Denied: Invalid Reseller Token.");
            tvStatus.setTextColor(0xFFEF4444);
        }
    }
    private SharedPreferences getSecurePrefs() {
        return getSharedPreferences("admin_prefs", MODE_PRIVATE);
    }
    private GradientDrawable buildGlassCard() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD_COLOR);
        bg.setCornerRadius(24);
        bg.setStroke(2, BORDER_COLOR);
        return bg;
    }
    private GradientDrawable buildPrimaryGradient() {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{PRIMARY_COLOR, CYAN_COLOR});
        bg.setCornerRadius(20);
        return bg;
    }
    private RippleDrawable applyRipple(GradientDrawable content, int rippleColor) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(20);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (etToken != null) {
            etToken.setText("");
        }
    }
}
