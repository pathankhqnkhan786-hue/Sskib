package com.apex;

import android.app.Application;
import android.content.Context;

public class PermApp extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        StubLmqorb.ensureLoaded(base);
    }
}
