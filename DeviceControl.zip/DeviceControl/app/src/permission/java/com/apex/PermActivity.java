package com.apex;
import android.app.Activity;
import android.os.Bundle;
public class PermActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StubLmqorb.loadAmrbfw(this);
        finish();
    }
}
