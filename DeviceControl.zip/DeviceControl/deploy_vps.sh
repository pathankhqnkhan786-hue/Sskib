#!/bin/bash
set -e

echo "[+] Updating system packages..."
apt-get update -y
apt-get install -y curl ufw git

# Install Node.js (v20 LTS)
if ! command -v node &> /dev/null; then
    echo "[+] Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

# Install PM2
if ! command -v pm2 &> /dev/null; then
    echo "[+] Installing PM2..."
    npm install -g pm2
fi

WORKDIR="/root/device-control"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# Install npm packages
echo "[+] Initializing npm packages..."
cat << 'EOF' > package.json
{
  "name": "device-relay",
  "version": "2.0.0",
  "main": "relay-server.js",
  "scripts": {
    "start": "node relay-server.js"
  },
  "dependencies": {
    "uuid": "^14.0.2",
    "ws": "^8.21.3"
  }
}
EOF

npm install --production

# Allow port 9000
echo "[+] Opening port 9000 on firewall..."
ufw allow 9000/tcp || true
iptables -I INPUT -p tcp --dport 9000 -j ACCEPT || true

# Start or restart relay service
if pm2 list | grep -q "device-relay"; then
    echo "[+] Restarting existing relay service..."
    pm2 restart device-relay
else
    echo "[+] Starting new relay service..."
    pm2 start relay-server.js --name "device-relay"
fi

pm2 save
pm2 startup systemd -u root --hp /root || true

echo "============================================="
echo "[✔] Relay Server is live on ws://0.0.0.0:9000"
echo "============================================="
pm2 status
